﻿'use strict';

//Global variables
var month = ['Jan.', 'Feb.', 'Mar.', 'Apr.', 'May.', 'Jun.', 'Jul.', 'Aug.', 'Sep.', 'Oct.', 'Nov.', 'Dec.'];
var weekday = ['Sun.', 'Mon.', 'Tue.', 'Wed.', 'Thurs.', 'Fri.', 'Sat.'];
var allFlights = [];
var nonConfidentialReader = 1;  // boolean flag lowest security group

function getQueryStringParameter(param) {
    var params = document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == param) {
            return singleParam[1];
        }
    }
};

//Functions for displaying the current list of flights
function getFlights() {
    var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var currentcontext = new SP.ClientContext.get_current();
    var hostcontext = new SP.AppContextSite(currentcontext, hostUrl);
    var web = hostcontext.get_web();
    var lists = web.get_lists();
    var flightList;
    var nonConfidentialFlights;
    var confidentialFlights;
    var camlQuery = new SP.CamlQuery();
    var camlQString = "<View><Query>"
                    + "    <OrderBy>"
                    + "      <FieldRef Name='Date' />"
                    + "    </OrderBy>"
                    + "    <Where>"
                    + "      <Geq><FieldRef Name='Date' /><Value Type='DateTime'><Today/></Value></Geq>"
                    + "    </Where>"
                    + "    </Query></View>";

    camlQuery.set_viewXml(camlQString);

    // get nonConfidential flights
    flightList = lists.getByTitle('nonConfidentialFlights');
    nonConfidentialFlights = flightList.getItems(camlQuery);
    currentcontext.load(nonConfidentialFlights);

    // get confidential flights
    if (nonConfidentialReader == 0) {
        flightList = lists.getByTitle('ConfidentialFlights');
        confidentialFlights = flightList.getItems(camlQuery);
        currentcontext.load(confidentialFlights);
    }

    currentcontext.executeQueryAsync(function () { onGetFlightsSuccess(nonConfidentialFlights, confidentialFlights) }, onGetFlightsFail);
};


function onGetFlightsSuccess(nonConfidentialFlights, confidentialFlights) {
    var ncFlightEnumerator = nonConfidentialFlights.getEnumerator();
    if (!(confidentialFlights === undefined || confidentialFlights === null)) {
        var cFlightEnumerator = confidentialFlights.getEnumerator();
    }
    var currentFlight;
    var flightCnt = 0;
    var time;
    var timezone;
    
    // initialize allFlights Array
    allFlights.length = 0;

    while (ncFlightEnumerator.moveNext()) {
        currentFlight = ncFlightEnumerator.get_current();
        if (currentFlight.get_item('Time') != null) {
            time = currentFlight.get_item('Time')
        } else {
            time = ' ';
        }
        if (currentFlight.get_item('timezone') != null) {
            timezone = currentFlight.get_item('timezone')
        } else {
            timezone = ' ';
        }
        allFlights.push({
            ID: currentFlight.get_item('ID'),
            Date: currentFlight.get_item('Date'),
            Time: time,
            Timezone: timezone,
            From: currentFlight.get_item('from'),
            To: currentFlight.get_item('to'),
            Confidential: 0,
            ItineraryNotes: currentFlight.get_item('itineraryNotes'),
            FlightCrewNotes: currentFlight.get_item('flightCrewNotes'),
            Passengers: [
                        {
                            name: currentFlight.get_item('Passenger1'),
                            email: currentFlight.get_item('Passenger1email'),
                            phone: currentFlight.get_item('Passenger1phone'),
                            contact: currentFlight.get_item('Passenger1contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger2'),
                            email: currentFlight.get_item('Passenger2email'),
                            phone: currentFlight.get_item('Passenger2phone'),
                            contact: currentFlight.get_item('Passenger2contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger3'),
                            email: currentFlight.get_item('Passenger3email'),
                            phone: currentFlight.get_item('Passenger3phone'),
                            contact: currentFlight.get_item('Passenger3contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger4'),
                            email: currentFlight.get_item('Passenger4email'),
                            phone: currentFlight.get_item('Passenger4phone'),
                            contact: currentFlight.get_item('Passenger4contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger5'),
                            email: currentFlight.get_item('Passenger5email'),
                            phone: currentFlight.get_item('Passenger5phone'),
                            contact: currentFlight.get_item('Passenger5contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger6'),
                            email: currentFlight.get_item('Passenger6email'),
                            phone: currentFlight.get_item('Passenger6phone'),
                            contact: currentFlight.get_item('Passenger6contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger7'),
                            email: currentFlight.get_item('Passenger7email'),
                            phone: currentFlight.get_item('Passenger7phone'),
                            contact: currentFlight.get_item('Passenger7contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger8'),
                            email: currentFlight.get_item('Passenger8email'),
                            phone: currentFlight.get_item('Passenger8phone'),
                            contact: currentFlight.get_item('Passenger8contact')
                        }]
        });

        flightCnt++;
    }
    if (!(confidentialFlights === undefined || confidentialFlights === null)) {
        while (cFlightEnumerator.moveNext()) {
            currentFlight = cFlightEnumerator.get_current();
            if (currentFlight.get_item('Time') != null) {
                time = currentFlight.get_item('Time')
            } else {
                time = ' ';
            }
            if (currentFlight.get_item('timezone') != null) {
                timezone = currentFlight.get_item('timezone')
            } else {
                timezone = ' ';
            }
            allFlights.push({
                ID: currentFlight.get_item('ID'),
                Date: currentFlight.get_item('Date'),
                Time: time,
                Timezone: timezone,
                From: currentFlight.get_item('from'),
                To: currentFlight.get_item('to'),
                Confidential: 1,
                ItineraryNotes: currentFlight.get_item('itineraryNotes'),
                FlightCrewNotes: currentFlight.get_item('flightCrewNotes'),
                Passengers: [
                        {
                            name: currentFlight.get_item('Passenger1'),
                            email: currentFlight.get_item('Passenger1email'),
                            phone: currentFlight.get_item('Passenger1phone'),
                            contact: currentFlight.get_item('Passenger1contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger2'),
                            email: currentFlight.get_item('Passenger2email'),
                            phone: currentFlight.get_item('Passenger2phone'),
                            contact: currentFlight.get_item('Passenger2contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger3'),
                            email: currentFlight.get_item('Passenger3email'),
                            phone: currentFlight.get_item('Passenger3phone'),
                            contact: currentFlight.get_item('Passenger3contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger4'),
                            email: currentFlight.get_item('Passenger4email'),
                            phone: currentFlight.get_item('Passenger4phone'),
                            contact: currentFlight.get_item('Passenger4contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger5'),
                            email: currentFlight.get_item('Passenger5email'),
                            phone: currentFlight.get_item('Passenger5phone'),
                            contact: currentFlight.get_item('Passenger5contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger6'),
                            email: currentFlight.get_item('Passenger6email'),
                            phone: currentFlight.get_item('Passenger6phone'),
                            contact: currentFlight.get_item('Passenger6contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger7'),
                            email: currentFlight.get_item('Passenger7email'),
                            phone: currentFlight.get_item('Passenger7phone'),
                            contact: currentFlight.get_item('Passenger7contact')
                        },
                        {
                            name: currentFlight.get_item('Passenger8'),
                            email: currentFlight.get_item('Passenger8email'),
                            phone: currentFlight.get_item('Passenger8phone'),
                            contact: currentFlight.get_item('Passenger8contact')
                        }]
            });

            flightCnt++;
        }
    }
    displayFlightList();
};

function displayFlightList() {
    var flightCnt = allFlights.length;
    var htmlToRender = '';
    var Confidential = '';
    var strDate = '';
    var currdate = '';

    // sort allFlights array by flight date & time
    allFlights.sort(function (x, y) {
        var a = new Date(month[x.Date.getMonth()] + ' ' + x.Date.getDate() + ', ' + x.Date.getFullYear() + ' ' + x.Time + ' ' + x.Timezone);
        var b = new Date(month[y.Date.getMonth()] + ' ' + y.Date.getDate() + ', ' + y.Date.getFullYear() + ' ' + y.Time + ' ' + y.Timezone);
        return a < b ? -1 : a > b ? 1 : 0;
    });

    for (var i = 0; i < flightCnt; i++) {
        strDate = weekday[allFlights[i].Date.getDay()] + ' ' +
                  month[(allFlights[i].Date.getMonth())] + ' ' +
                  allFlights[i].Date.getDate() + ', ' +
                  allFlights[i].Date.getFullYear();

        if (allFlights[i].Confidential == 1) {
            Confidential = '&nbsp;&nbsp;&nbsp;<span class="confidentialFlight">&nbsp;&nbsp;**CONFIDENTIAL**</span>';
        } else {
            Confidential = '';
        }

        if (currdate !== strDate) {
            currdate = strDate;
            htmlToRender += '<div><h3>' + strDate + '</h3></div>';
        }
        htmlToRender += '<div class="displayFlightCol1">&nbsp;&nbsp;&nbsp;<b>' + allFlights[i].Time + '  ' + allFlights[i].Timezone + '</b></div>';
        htmlToRender += '<div class="displayFlightCol2"><b><a class="flightLink" onclick="displayFlight(' + i + ')"></b>';
        htmlToRender += allFlights[i].From + ' -> ' + allFlights[i].To + Confidential + '</a><br>';
        for (var j = 0; j < 8; j++) {
            allFlights[i].Passengers[j].name !== null ? htmlToRender += '<span style="margin-left:10px;">' + (j + 1) + ') ' + allFlights[i].Passengers[j].name + '</span><br>' : htmlToRender += '';
        }
        
        htmlToRender += '<br></div>';
    }

    $('#flights').html('');  // initalize the flights div to nothing
    $('#flights').html(htmlToRender);
    $('#Flights-list').show(500);
};

function onGetFlightsFail(sender, args) {
    alert('Failed to get flight list. Error: ' + args.get_message());
    $('#Flights-list').show(500);
};

//Functions for displaying a Flight's details
function displayFlight(FlightId) {
    var strPassengers = '';
    var strDate_display = weekday[allFlights[FlightId].Date.getDay()] + ' ' +
                 month[(allFlights[FlightId].Date.getMonth())] + ' ' +
                 allFlights[FlightId].Date.getDate() + ', ' +
                 allFlights[FlightId].Date.getFullYear();
    var strDate_data = allFlights[FlightId].Date.getFullYear() + '-' +
                       allFlights[FlightId].Date.getMonth() + '-' +
                       allFlights[FlightId].Date.getDate();

    $('#item-display-date').html(strDate_display);
    $('#item-display-time').html(allFlights[FlightId].Time + '  ' + allFlights[FlightId].Timezone);
    $('#item-display-to').html(allFlights[FlightId].To);
    $('#item-display-from').html(allFlights[FlightId].From);
    if (allFlights[FlightId].Confidential) {
        $('#item-display-cofidentialFlight').show();
    } else {
        $('#item-display-cofidentialFlight').hide();
    }
    $('#item-display-itineraryNotes').html(allFlights[FlightId].ItineraryNotes);
    $('#item-display-flightCrewNotes').html(allFlights[FlightId].FlightCrewNotes);
    for (var i = 0; i < 8; i++) {
        if (allFlights[FlightId].Passengers[i].name!==null) {
            strPassengers += addToPassengerList(allFlights[FlightId].Passengers[i].name,
                                                allFlights[FlightId].Passengers[i].phone,
                                                allFlights[FlightId].Passengers[i].email,
                                                allFlights[FlightId].Passengers[i].contact);
        }
    }
    $('#display-passengers').html(strPassengers)

    // add values to edit form
    var arr = strDate_data.split('-');
    var flightDate = new Date(arr[0], arr[1], arr[2]);
    $('#date-update-display').datepicker('setDate', flightDate);
    $('#time-update').val(allFlights[FlightId].Time);
    $('#timezone-update').val(allFlights[FlightId].Timezone);
    $('#to-update').val(allFlights[FlightId].To);
    $('#from-update').val(allFlights[FlightId].From);
    if (allFlights[FlightId].Confidential) {
      $('#confidential-update').prop("checked", true);
    } else {
      $('#confidential-update').prop("checked", false);
    }
    $('#itineraryNotes-update').val(allFlights[FlightId].ItineraryNotes);
    $('#flightCrewNotes-update').val(allFlights[FlightId].FlightCrewNotes);
    for (i = 0; i < 8; i++) {
        $('#passenger' + (i + 1) + '-update').val(allFlights[FlightId].Passengers[i].name);
        $('#passenger' + (i + 1) + 'email-update').val(allFlights[FlightId].Passengers[i].email);
        $('#passenger' + (i + 1) + 'phone-update').val(allFlights[FlightId].Passengers[i].phone);
        $('#passenger' + (i + 1) + 'contact-update').val(allFlights[FlightId].Passengers[i].contact);
    }
    $('#currentFlightID').val(FlightId);
    $('#Flights-list').hide();
    $('#showFlight').show(500);
};

function addToPassengerList(name, phone, email, contact) {
    var strReturn = '';
    strReturn = '<p><b>' + name + '</b>';
    if (phone != null) {
        if (formatPhone(phone, 'digits').length > 9) {
            strReturn += '&nbsp;&nbsp;' + '<a href="tel:+1' + formatPhone(phone, 'digits') + '">' + formatPhone(phone, 'full') + '</a><br>';
        } else {
            strReturn += '&nbsp;&nbsp;' + phone + '<br>';
        }
    } else {
        strReturn += '<br>';
    }
    if (email != null) {
        strReturn += '&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:' + email + '">' + email + '</a><br>';
    }
    if (contact != null) {
        strReturn += '&nbsp;&nbsp;&nbsp;&nbsp;West Fraser Contact: ' + contact + '<br>';
    }
    strReturn += '</p>';
    return strReturn;
};

// reset display div to blank
function resetDisplayFlight() {
    $('#display-passengers').html('');
    for (var i = 0; i < 8; i++) {
        $('#passenger' + (i + 1) + '-update').val('');
        $('#passenger' + (i + 1) + 'email-update').val('');
        $('#passenger' + (i + 1) + 'phone-update').val('');
        $('#passenger' + (i + 1) + 'contact-update').val('');
    }
}


// reset display div to blank
function resetNewFlightForm() {
    $('#date-input-display').val('');
    $('#date-input').val('');
    $('#time-input').val('');
    $('#to-input').val('');
    $('#from-input').val('');
    $('#confidential-input').prop('checked', false);
    for (var i = 0; i < 8; i++) {
        $('#passenger' + (i + 1) + '-input').val('');
        $('#passenger' + (i + 1) + 'email-input').val('');
        $('#passenger' + (i + 1) + 'phone-input').val('');
        $('#passenger' + (i + 1) + 'contact-input').val('');
    }
    validate('new');
}

//Functions for creating a new Flight
function createFlight() {
    var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var currentcontext = new SP.ClientContext.get_current();
    var hostcontext = new SP.AppContextSite(currentcontext, hostUrl);
    var web = hostcontext.get_web();
    var lists = web.get_lists();
    var flightList;
    var currentFlight;
    var newFlightConfidentialStatus = 1;
    if (!($('#confidential-input').prop('checked'))) { // not checked
        newFlightConfidentialStatus = 0;
    }

    if (newFlightConfidentialStatus == 0) {
        flightList = lists.getByTitle('nonConfidentialFlights');
    } else {
        flightList = lists.getByTitle('ConfidentialFlights');
    }

    var itemCreateInfo = SP.ListItemCreationInformation();
    currentFlight = flightList.addItem(itemCreateInfo);

    var data = $('#date-input').val().toString();
    var arr = data.split('-');
    //sets hour to 8am in timezone local to user's location. This allows for a timezone shift when written to list in PST or PDT
    var flightDate = new Date(arr[0], (arr[1] - 1), arr[2], 8);

    currentFlight.set_item('Date', flightDate);
    currentFlight.set_item('Time', $('#time-input').val().toString());
    currentFlight.set_item('timezone', $('#timezone-input').val());
    currentFlight.set_item('to', $('#to-input').val().toString());
    currentFlight.set_item('from', $('#from-input').val().toString());
    currentFlight.set_item('itineraryNotes', $('#itineraryNotes-input').val().toString());
    currentFlight.set_item('flightCrewNotes', $('#flightCrewNotes-input').val().toString());
    for (var i = 1; i < 9; i++) {
        if ($('#passenger' + i + '-input').val().toString() != 'Passenger' + i) currentFlight.set_item('Passenger' + i, $('#passenger' + i + '-input').val().toString());
        if ($('#passenger' + i + 'email-input').val().toString() != 'Email') currentFlight.set_item('Passenger' + i + 'email', $('#passenger' + i + 'email-input').val().toString());
        if ($('#passenger' + i + 'phone-input').val().toString() != 'Phone') currentFlight.set_item('Passenger' + i + 'phone', $('#passenger' + i + 'phone-input').val().toString());
        if ($('#passenger' + i + 'contact-input').val().toString() != 'contact') currentFlight.set_item('Passenger' + i + 'contact', $('#passenger' + i + 'contact-input').val().toString());
    }
    currentFlight.update();
    currentcontext.load(currentFlight);
    currentcontext.executeQueryAsync(onCreateFlightsuccess, onCreateFlightFail);
};

function onCreateFlightsuccess() {
    showMsgBox('create');
    getFlights();
    $('#addFlight').hide();
    $('#Flights-list').show(500);
    resetNewFlightForm();
};

function onCreateFlightFail(sender, args) {
    alert('Failed to create Flight. Error:' + args.get_message());
    $('#addFlight').hide();
    $('#Flights-list').show(500);
};

//Functions for editing a Flight
function updateFlight() {
    var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var currentcontext = new SP.ClientContext.get_current();
    var hostcontext = new SP.AppContextSite(currentcontext, hostUrl);
    var web = hostcontext.get_web();
    var lists = web.get_lists();
    var flightList;
    var currentFlight;
    var i = $('#currentFlightID').val().toString();
    var currentFlightID = allFlights[i].ID;
    var newFlightConfidentialStatus = 1;
    if (!($('#confidential-update').prop('checked'))) { // not checked
        newFlightConfidentialStatus = 0;
    }
    var currentFlightConfidentialStatus = allFlights[i].Confidential;

    if (currentFlightConfidentialStatus == 0) {
        flightList = lists.getByTitle('nonConfidentialFlights');
    } else {
        flightList = lists.getByTitle('ConfidentialFlights');
    }

    if (newFlightConfidentialStatus != currentFlightConfidentialStatus) {
        //delete from original list
        currentFlight = flightList.getItemById(currentFlightID);
        currentFlight.deleteObject();
        currentcontext.executeQueryAsync(function () { console.log('deleted from old list'); }, function () { console.log('failed to deleted from old list'); });

      //create the flight in the other list
        // change to other list
        if (currentFlightConfidentialStatus == 0) {
            flightList = lists.getByTitle('ConfidentialFlights');
        } else {
            flightList = lists.getByTitle('nonConfidentialFlights');
        }

        var itemCreateInfo = new SP.ListItemCreationInformation();
        currentFlight = flightList.addItem(itemCreateInfo);

        var data = $('#date-update').val().toString();
        var arr = data.split('-');
        //sets hour to 8am in timezone local to user's location. This allows for a timezone shift when written to list in PST or PDT
        var flightDate = new Date(arr[0], (arr[1] - 1), arr[2], 8);
        currentFlight.set_item('Date', flightDate);
        currentFlight.set_item('Time', $('#time-update').val().toString());
        currentFlight.set_item('timezone', $('#timezone-update').val());
        currentFlight.set_item('to', $('#to-update').val().toString());
        currentFlight.set_item('from', $('#from-update').val().toString());
        currentFlight.set_item('itineraryNotes', $('#itineraryNotes-update').val().toString());
        currentFlight.set_item('flightCrewNotes', $('#flightCrewNotes-update').val().toString());
        for (var i = 1; i < 9; i++) {
            if ($('#passenger' + i + '-update').val() != 'Passenger' + i) currentFlight.set_item('Passenger' + i, $('#passenger' + i + '-update').val().toString());
            if ($('#passenger' + i + 'email-update').val().toString() != 'Email') currentFlight.set_item('Passenger' + i + 'email', $('#passenger' + i + 'email-update').val().toString());
            if ($('#passenger' + i + 'phone-update').val().toString() != 'Phone') currentFlight.set_item('Passenger' + i + 'phone', $('#passenger' + i + 'phone-update').val().toString());
            if ($('#passenger' + i + 'contact-update').val().toString() != 'contact') currentFlight.set_item('Passenger' + i + 'contact', $('#passenger' + i + 'contact-update').val().toString());
        }
        currentFlight.update();
        currentcontext.load(currentFlight);
        currentcontext.executeQueryAsync(function () { onUpdateFlightsuccess(); }, function () { console.log('failed to create in new list'); });
    } else {
        // update record in original list
        currentFlight = flightList.getItemById(currentFlightID);

        var data = $('#date-update').val().toString();
        var arr = data.split('-');
      //sets hour to 8am in timezone local to user's location. This allows for a timezone shift when written to list in PST or PDT
        var flightDate = new Date(arr[0], (arr[1] - 1), arr[2], 8); 
        currentFlight.set_item('Date', flightDate);
        currentFlight.set_item('Time', $('#time-update').val().toString());
        currentFlight.set_item('timezone', $('#timezone-update').val());
        currentFlight.set_item('to', $('#to-update').val().toString());
        currentFlight.set_item('from', $('#from-update').val().toString());
        currentFlight.set_item('itineraryNotes', $('#itineraryNotes-update').val().toString());
        currentFlight.set_item('flightCrewNotes', $('#flightCrewNotes-update').val().toString());
        for (var i = 1; i < 9; i++) {
            if ($('#passenger' + i + '-update').val() != 'Passenger' + i) currentFlight.set_item('Passenger' + i, $('#passenger' + i + '-update').val().toString());
            if ($('#passenger' + i + 'email-update').val().toString() != 'Email') currentFlight.set_item('Passenger' + i + 'email', $('#passenger' + i + 'email-update').val().toString());
            if ($('#passenger' + i + 'phone-update').val().toString() != 'Phone') currentFlight.set_item('Passenger' + i + 'phone', $('#passenger' + i + 'phone-update').val().toString());
            if ($('#passenger' + i + 'contact-update').val().toString() != 'contact') currentFlight.set_item('Passenger' + i + 'contact', $('#passenger' + i + 'contact-update').val().toString());
        }
        currentFlight.update();
        currentcontext.load(currentFlight);
        currentcontext.executeQueryAsync(onUpdateFlightsuccess, onUpdateFlightFail);
    }
};

function onUpdateFlightsuccess() {
    showMsgBox('update');
    getFlights();
    $('#editFlight').hide();
    resetDisplayFlight();
    $('#Flights-list').show(500);
};

function onUpdateFlightFail(sender, args) {
    alert('Failed to edit Flight. Error: ' + args.get_message());
    $('#editFlight').hide();
    $('#Flights-list').show(500);
};

//Functions for deleting a Flight
function cancelFlight() {
    var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var currentcontext = new SP.ClientContext.get_current();
    var hostcontext = new SP.AppContextSite(currentcontext, hostUrl);
    var web = hostcontext.get_web();
    var lists = web.get_lists();
    var flightList;
    var currentFlight;
    var i = $('#currentFlightID').val().toString();
    var currentFlightID = allFlights[i].ID;
    var currentFlightConfidentialStatus = allFlights[i].Confidential;

    if (currentFlightConfidentialStatus == 0) {
        flightList = lists.getByTitle('nonConfidentialFlights');
    } else {
        flightList = lists.getByTitle('ConfidentialFlights');
    }

    //delete from original list
    currentFlight = flightList.getItemById(currentFlightID);
    currentFlight.deleteObject();
    currentcontext.executeQueryAsync(onCancelFlightsuccess, onCancelFlightFail);
};

function onCancelFlightsuccess() {
    showMsgBox('cancelled');
    resetDisplayFlight();
    getFlights();
    $('#showFlight').hide();
};

function onCancelFlightFail(sender, args) {
    alert('Failed to cancel this flight. Error:' + args.get_message());
    $('#showFlight').hide();
};

function copyFlight() {
    var FlightId = $('#currentFlightID').val();
    var strDate_display = weekday[allFlights[FlightId].Date.getDay()] + ' ' +
                 month[(allFlights[FlightId].Date.getMonth())] + ' ' +
                 allFlights[FlightId].Date.getDate() + ', ' +
                 allFlights[FlightId].Date.getFullYear();
    var strDate_data = allFlights[FlightId].Date.getFullYear() + '-' +
                       allFlights[FlightId].Date.getMonth() + '-' +
                       allFlights[FlightId].Date.getDate();
    var arr = strDate_data.split('-');
    var flightDate = new Date(arr[0], arr[1], arr[2]);
    $('#date-input-display').datepicker('setDate', flightDate);
    $('#time-input').val(allFlights[FlightId].Time);
    $('#timezone-input').val(allFlights[FlightId].Timezone);
    $('#to-input').val(allFlights[FlightId].To);
    $('#from-input').val(allFlights[FlightId].From);
    if (allFlights[FlightId].Confidential) {
        $('#confidential-input').prop("checked", true);
    } else {
        $('#confidential-input').prop("checked", false);
    }
    $('#itineraryNotes-input').val(allFlights[FlightId].ItineraryNotes);
    $('#flightCrewNotes-input').val(allFlights[FlightId].FlightCrewNotes);
    for (var i = 0; i < 8; i++) {
        $('#passenger' + (i + 1) + '-input').val(allFlights[FlightId].Passengers[i].name);
        $('#passenger' + (i + 1) + 'email-input').val(allFlights[FlightId].Passengers[i].email);
        $('#passenger' + (i + 1) + 'phone-input').val(allFlights[FlightId].Passengers[i].phone);
        $('#passenger' + (i + 1) + 'contact-input').val(allFlights[FlightId].Passengers[i].contact);
    }
    $('#showFlight').hide();
    validate('new');
    $('#addFlight').show(500);
};

    function getUserGroups() {
        var userGroups;
        var context = SP.ClientContext.get_current();
        var user = context.get_web().get_currentUser();
        userGroups = user.get_groups();
        context.load(userGroups);
        context.executeQueryAsync(function () {
            onGetUserGroupsSuccess(userGroups)
        }, onGetUserGroupsFail);
    };

    function onGetUserGroupsSuccess(userGroups) {
        var wfAirGrpName = "";
        var groupsEnumerator = userGroups.getEnumerator();
        while (groupsEnumerator.moveNext()) {
            wfAirGrpName = groupsEnumerator.get_current().get_title();
            if (wfAirGrpName.indexOf('WFAir') >= 0) {
                switch (wfAirGrpName) {
                    case "WFAir Reader":
                        nonConfidentialReader = 1;
                        break;
                    case "WFAir Confidential Reader":
                        nonConfidentialReader = 0;
                        break;
              //      case "WFAir Editor":
                    case "WFAir Flight Crew":
                        nonConfidentialReader = 0;
                        $('.showButtonEdit').show();
                        break;
                    case "WFAir Editor":
             //       case "WFAir Flight Crew":
                        nonConfidentialReader = 0;
                        $('.showButtonEdit').show();
                        $('.showButtonCopy').show();
                        $('.showButtonCancelAdd').show();
                        $('.showButtonReq').hide();
                        break;
                    default:
                        nonConfidentialReader = 1;
                }
            }
        }
        getFlights();
    };

    function onGetUserGroupsFail(sender, args) {
        alert('Failed to get user group names. Error: ' + args.get_message());
    };

    function validate(form) {
        if (form == 'new') {
            $('#saveNew').prop('disabled', true);
            if (($('#date-input').val().length > 0) && ($('#from-input').val().length > 0) && ($('#to-input').val().length > 0)) { $('#saveNew').prop('disabled', false); }
        }
        if (form == 'edit') {
            $('#saveUpdate').prop('disabled', true);
            if (($('#date-update').val().length > 0) && ($('#from-update').val().length > 0) && ($('#to-update').val().length > 0)) { $('#saveUpdate').prop('disabled', false); }
        }
        if (form == 'req') {
            if (($('#date-req').val().length > 0) && ($('#from-req').val().length > 0) && ($('#to-req').val().length > 0) && (validateEmail() == 1) && ($('#comment-req').val().length > 0)) {
                $('#requestFlight').hide();
                requestFlight();
                $('#Flights-list').show(500);
            } else {
                showMsgBox('requestFailed');
            }
        }
    };

    // Validate email
    function validateEmail() {
        var email = $.trim($("#requestedBy-email-req").val());
        var space = email.indexOf(' ');
        var atpos = email.indexOf('@');
        var dotpos = email.lastIndexOf(".");
        if (email.length > 0) {
            if ((atpos > 0) && (dotpos > (atpos + 1)) && (space == -1) && ((email.length - 1) > dotpos)) {
                $('#emailError').hide();
                return 1;
            } else {
                $('#emailError').show();
                return 0;
            }
        } else {
            $('#emailError').hide();
            return 0;
        }
    };

    function validatePhone(pField) {
        var filter = /^[0-9-+\s]+$/;
        var pNumber = $(pField).val();

        if (pNumber == 'Phone') return true;
        return filter.test(pNumber);
    };

    function formatPhone(pNum, type) {
        var formatted = '';
        var unformatted = pNum;

        if (unformatted == null) unformatted = '';

        unformatted = unformatted.replace(/-/g, '');
        unformatted = unformatted.replace(/\)/g, '');
        unformatted = unformatted.replace(/\(/g, '');

        if ((!isNaN(unformatted)) && (unformatted.length == 10)) {
            if (type == 'full') {
                formatted = unformatted.substr(0, 3) + '-' + unformatted.substr(3, 3) + '-' + unformatted.substr(6, 4)
            } else {
                formatted = unformatted;
            }
        }

        return formatted
    };

    function requestFlight() {
        var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
        var currentContext = new SP.ClientContext.get_current();
        var hostContext = new SP.AppContextSite(currentContext, hostUrl);
        var web = hostContext.get_web();
        var userGroups = web.get_siteGroups();
        var flightCrew = userGroups.getByName('WFAir Editor');
        var crewMembers = flightCrew.get_users();
        currentContext.load(crewMembers);
        currentContext.executeQueryAsync(function () { onRequestFlightSucceeded(crewMembers) }, onRequestFlightFailed)
    }

    function onRequestFlightSucceeded(crewMembers) {
        var from = $('#requestedBy-email-req').val().toString();
        var to = '';
        var body = '';
        var subject = 'Flight Request';
        var count = 0;

        // build body of email msg
        body = $('#requestedBy-name-req').val().toString() + ' (' + $('#requestedBy-email-req').val().toString() + ') has requested a flight\n';
        body += '<h3>Requested flight details:</h3>';
        body += 'Date - ' + $('#date-req').val() + '<br>';
        body += 'Time - ' + $('#time-req').val() + ' '  + $('#timezone-req').val() + '<br>';
        body += 'From - ' + $('#from-req').val() + '<br>';
        body += 'To - ' + $('#to-req').val() + '<br>';
        if ($('#confidential-req').prop('checked')) {
            body += 'This flight is confidential' + + '<br>';
        }
        body += '<h3>Reason for Request:</h3>';
        body += $('#comment-req').val() + '<br><br>';
//        body += 'Launch the <a href="https://westfraser4.sharepoint.com/sites/intranettest/Applications/Pages/JetSchedule.aspx">WF Air Scheduling</a> application to create this flight.'
        body += '*Launch the <a href="' + decodeURIComponent(getQueryStringParameter("SPHostUrl")) + '/Pages/JetSchedule.aspx">WF Air Scheduling</a> application to create this flight.';
        
        count = crewMembers.get_count();
        var crewMembersEnumerator = crewMembers.getEnumerator();
        while (crewMembersEnumerator.moveNext()) {
            var member = crewMembersEnumerator.get_current();
            to += member.get_email() + ',';
        }
        to = to.substring(0, to.length - 1);  // take out last char
        sendEmail(from, to, body, subject);
    };

    /**
    * Retrieves a valid form digest for web service calls
    * @returns {string} 
     */
    function getFormDigest() {
        var dfd = $.Deferred(function () {
            var appweburl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));
            $.ajax({
                url: appweburl + "/_api/contextinfo",
                type: "POST",
                headers: {
                    "accept": "application/json;odata=verbose",
                    "contentType": "text/xml"
                },
                success: function (data) {
                    var formDigest = data.d.GetContextWebInformation.FormDigestValue;
                    dfd.resolve(formDigest);
                },
                error: function (err) {
                    dfd.reject(args.get_message());
                }
            });
        });
        return dfd.promise();
    }

    function sendEmail(from, to, body, subject) {
        var appweburl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));
        var urlTemplate = appweburl + "/_api/SP.Utilities.Utility.SendEmail";
        var sendSuccess = 0;

        //get the form digest before sending the email
        getFormDigest().done(function(formDigest) {
            var addresses = to.split(",");

            for (var i = 0; i < addresses.length; i++) {
                $.ajax({
                    contentType: 'application/json',
                    url: urlTemplate,
                    type: "POST",
                    data: JSON.stringify({
                        'properties': {
                            '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                            'From': from,
                            'To': { 'results': [addresses[i]] },
                            'Body': body,
                            'Subject': subject
                        }
                    }),
                    headers: {
                        "Accept": "application/json;odata=verbose",
                        "content-type": "application/json;odata=verbose",
                        "X-RequestDigest": formDigest
                    },
                    success: function (data) {
                        sendSuccess = 1;
                    },
                    error: function (err) {
                        console.log(JSON.stringify(err));
                    }
                })
            }
            setTimeout(function () {
                if (sendSuccess == 0) {
                    showMsgBox('sendRequestFailed');
                } else {
                    showMsgBox('request');
                }
            }, 2000);
        });
    }

    function onRequestFlightFailed(sender, args) {
        alert('Failed to get list of flight editors\' email addresses. Error: ' + args.get_message());
    };

    function showMsgBox(msg) {
        switch (msg) {
            case 'cancel':
                $('#msgBoxContent').html('Are you sure you want to cancel this flight?<br>');
                $('#msgBoxButtons').html('<input type="button" id="delYES" value="Yes" onclick="$(\'#msgBox\').hide(500); cancelFlight();" />&nbsp;&nbsp;' +
                                         '<input type="button" id="delNO" value="No" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            case 'cancelled':
                $('#msgBoxContent').html('You have successfully cancelled this flight<br>');
                $('#msgBoxButtons').html('<input type="button" id="cancelledOK" value="OK" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            case 'create':
                $('#msgBoxContent').html('You have successfully created this flight.<br>');
                $('#msgBoxButtons').html('<input type="button" id="addOK" value="OK" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            case 'update':
                $('#msgBoxContent').html('You have successfully edited this flight<br>');
                $('#msgBoxButtons').html('<input type="button" id="editOK" value="OK" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            case 'request':
                $('#msgBoxContent').html('Your request has been sent<br>');
                $('#msgBoxButtons').html('<input type="button" id="reqOK" value="OK" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            case 'requestFailed':
                $('#msgBoxContent').html('Please ensure all required fields have been entered correctly<br>');
                $('#msgBoxButtons').html('<input type="button" id="reqOK" value="OK" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            case 'sendRequestFailed':
                $('#msgBoxContent').html('<b>Request Failed To Send</b><br>Please contact West Fraser IT helpdesk<br>');
                $('#msgBoxButtons').html('<input type="button" id="reqOK" value="OK" onclick="$(\'#msgBox\').hide(500);"/>');
                break;
            default: 
                break;
        }
        $('#msgBox').show(500);
    }

    function addTimeOptions (element) {
        $(element).append($('<option/>', { value: '12:00 am', text: '12:00 am' }));
        $(element).append($('<option/>', { value: '12:15 am', text: '12:15 am' }));
        $(element).append($('<option/>', { value: '12:30 am', text: '12:30 am' }));
        $(element).append($('<option/>', { value: '12:45 am', text: '12:45 am' }));
        for (var i = 1; i <= 11; i++) {
            $(element).append($('<option/>', { value: i + ':00 am', text: i + ':00 am' }));
            $(element).append($('<option/>', { value: i + ':15 am', text: i + ':15 am' }));
            $(element).append($('<option/>', { value: i + ':30 am', text: i + ':30 am' }));
            $(element).append($('<option/>', { value: i + ':45 am', text: i + ':45 am' }));
        }
        $(element).append($('<option/>', { value: '12:00 pm', text: '12:00 pm' }));
        $(element).append($('<option/>', { value: '12:15 pm', text: '12:15 pm' }));
        $(element).append($('<option/>', { value: '12:30 pm', text: '12:30 pm' }));
        $(element).append($('<option/>', { value: '12:45 pm', text: '12:45 pm' }));
        for (var i = 1; i <= 12; i++) {
            $(element).append($('<option/>', { value: i + ':00 pm', text: i + ':00 pm' }));
            $(element).append($('<option/>', { value: i + ':15 pm', text: i + ':15 pm' }));
            $(element).append($('<option/>', { value: i + ':30 pm', text: i + ':30 pm' }));
            $(element).append($('<option/>', { value: i + ':45 pm', text: i + ':45 pm' }));
        }
    }


        // This code runs when the DOM is ready
    $(document).ready(function () {
        getUserGroups();
        if (window.innerWidth > 675) {
            $('.overlay').css("width", "650px")
        } else {
            $('.overlay').css("width", "300px");
        }
        $(function () {
            $("#date-input-display").datepicker({
                dateFormat: "D, M d, yy",
                altField: "#date-input",
                altFormat: "yy-mm-dd"
            });
        });
        $(function () {
            $('#date-update-display').datepicker({
                dateFormat: "D, M d, yy",
                altField: "#date-update",
                altFormat: "yy-mm-dd"
            });
        });
        $(function () {
            $('#date-req-display').datepicker({
                dateFormat: "D, M d, yy",
                altField: "#date-req",
                altFormat: "yy-mm-dd"
            });
        });

        addTimeOptions ('#time-input');
        addTimeOptions ('#time-update');
        addTimeOptions ('#time-req');
    });