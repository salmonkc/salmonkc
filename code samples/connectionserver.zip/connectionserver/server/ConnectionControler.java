package com.tru.connectionserver.server;

/**
 * <p>Title: ConnectionControler</p>
 * <p>Description: directs in comming recuest for data to
 *                 appropriate DB driver</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: TRU</p>
 * @author sjohnson@tru.ca
 * @version 1.0
 */

import java.sql.*;
import java.io.*;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import com.tru.connectionserver.dbases.*;

public class ConnectionControler
{
  static Hashtable ht = new Hashtable();

  public ConnectionControler(String xmlFile) throws Exception
  {
    xmlParser p = new xmlParser();
    p.Parser(xmlFile);
  }

  public String getRecordSet(String apiCall)
  {
    String[] Query_S;
    String dbDriver;
    Query_S = apiCall.split("\\|");
    String returnStr = new String();

    API_CALL ConnElements;
    ConnElements=(API_CALL)ht.get(Query_S[0]);
    ConnElements.resetSQL();
    if (Query_S.length > 1)
    {
       for (int i=1; i <= (Query_S.length - 1); i++)
       {
         ConnElements.setSQL(Query_S[i]);
       }
    }

    dbDriver = ConnElements.getDBDriver();
    if (dbDriver.equals("oracle"))
    {
      OracleConnector Connector = new OracleConnector();
      try
      {
        returnStr = Connector.getResult(ConnElements);
      }
      catch (Exception e)
      {
        returnStr = e.getMessage();
      }
    }
    else if (dbDriver.equals("UniData"))
    {
      UniDataConnector Connector = new UniDataConnector();
      try
      {
        returnStr = Connector.getResult(ConnElements);
      }
      catch (Exception e)
      {
        returnStr = e.getMessage();
      }
    }
    else
    {
       returnStr ="not oracle or UniData";
    }
    return returnStr;
  }
}
