package com.tru.connectionserver.server;

/**
 * <p>Title: API_CALL</p>
 * <p>Description: Defines an API_CALL Object</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: TRU</p>
 * @author sjohnson@tru.ca
 * @version 1.0
 */

public class API_CALL
{
  private String DBDriver, Host, Port, User, Pass, SID, SQL, defaultSQL;
  private String[] Fields, Operators, Tables;

  public API_CALL(String dbD, String h, String pt, String sid,
                  String u, String p, String sql)
  {
    DBDriver = dbD;
    Host = h;
    Port = pt;
    SID = sid;
    User = u;
    Pass = p;
    SQL = sql;
    defaultSQL = sql;
    Operators = new String[]{""," = "," > "," < "," >= "," <= ",
                           " <> "," LIKE ", " IN ", " BETWEEN ",
                           " NOT IN ", " NOT BETWEEN "};
  }

  public API_CALL(String dbD, String h, String pt, String sid,
                  String u, String p, String sql, String flds)
  {
    DBDriver = dbD;
    Host = h;
    Port = pt;
    SID = sid;
    User = u;
    Pass = p;
    SQL = sql;
    defaultSQL = sql;
    flds = "|" + flds; // add pipe at start to make array 1 based
    Fields = flds.split("\\|");
    Operators = new String[]{""," = "," > "," < "," >= "," <= ",
                           " <> "," LIKE ", " IN ", " BETWEEN ",
                           " NOT IN ", " NOT BETWEEN "};
  }


  public API_CALL(String dbD, String h, String pt, String sid,
                  String u, String p, String sql, String flds, String tbls)
  {
    DBDriver = dbD;
    Host = h;
    Port = pt;
    SID = sid;
    User = u;
    Pass = p;
    SQL = sql;
    defaultSQL = sql;
    flds = "|" + flds; // add pipe at start to make array 1 based
    Fields = flds.split("\\|");
    Operators = new String[]{""," = "," > "," < "," >= "," <= ",
                           " <> "," LIKE ", " IN ", " BETWEEN ",
                           " NOT IN ", " NOT BETWEEN "};
    tbls = "|" + tbls; // add pipe at start to make array 1 based
    Tables = tbls.split("\\|");
  }

  public void resetSQL()
  {
    SQL = defaultSQL;
  }

  public void setSQL(String sql)
  {
     if (SQL.indexOf("{ call")== 0)  // Stored Procedure
      makeCallToStoredProcedure(sql);
     else  // query statement
      makeQuery(sql);
  }

  private void makeCallToStoredProcedure(String sql)
  {
    SQL = SQL + sql + "|";
  }

  private void makeQuery(String sql)
  {
    String[] appendParts, tblList;
    Integer Operator, Field, Compound;
    String Append;

    appendParts = sql.split("~");
    Append = appendParts[3];
    if (Append.indexOf("null")==0) Append = "";
    if (Append.indexOf( "FROM")==0)
    {
       tblList = Append.split(" ");
       Append = "FROM ";
       for (int I=1; I <= tblList.length-1; I++)
       {
         Integer tbl = new Integer(tblList[I]);
         Append = Append + Tables[tbl.intValue()] + ", ";
       }
       Append = Append.substring(0,(Append.length()-2));
    }
    Operator = new Integer(appendParts[2]);
    Field = new Integer(appendParts[1]);
    Append = Fields[Field.intValue()] +
               Operators[Operator.intValue()] + Append;
    if (appendParts[0].equals("1"))
    {
       Append = "OR " + Append;
    }
    if (appendParts[0].equals("2"))
    {
       Append = "AND " + Append;
    }

    SQL = SQL + " " + Append;    
  }

  public String getDBDriver()
  {
    return DBDriver;
  }

  public String getHost()
  {
    return Host;
  }

  public String getPort()
  {
    return Port;
  }

  public String getUser()
  {
    return User;
  }

  public String getPass()
  {
    return Pass;
  }

  public String getSID()
  {
    return SID;
  }

  public String getSQL()
  {
    return SQL;
  }
}
