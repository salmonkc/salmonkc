package com.tru.connectionserver.server;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: TRU</p>
 * @author not attributable
 * @version 1.0
 */


import java.io.FileReader;
import org.xml.sax.XMLReader;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;


public class xmlParser extends DefaultHandler
{
  String ElementName = new String();
  String name = new String();
  String dbDriver = new String();
  String host = new String();
  String port = new String();
  String sid = new String();
  String username = new String();
  String password = new String();
  String statementStart = new String();
  String fields = new String();
  String tables = new String();
  boolean ElementStart = false;

  public void Parser (String xmlFile) throws Exception
  {
    XMLReader xr = XMLReaderFactory.createXMLReader();
    xmlParser handler = new xmlParser();
    xr.setContentHandler(handler);
    xr.setErrorHandler(handler);
    FileReader r = new FileReader(xmlFile);
    xr.parse(new InputSource(r));
  }

  public xmlParser ()
  {
    super();
  }

  ////////////////////////////////////////////////////////////////////
  // Event handlers.
  ////////////////////////////////////////////////////////////////////

  public void startElement (String uri, String localname, String qName, Attributes atts)
  {
    ElementName = localname;
    ElementStart = true;
  }

  public void endElement (String uri, String localname, String qName)
  {
    if (localname.equals("tables"))
    {
      API_CALL api_call = new API_CALL(dbDriver.trim(),host.trim(), port.trim(),
                                       sid.trim(), username.trim(), password.trim(),
                                       statementStart.trim(), fields.trim(),
                                       tables.trim());
      String x = new String(name.trim());                                 
      ConnectionControler.ht.put(name.trim(), api_call);
    }
    ElementStart = false;
  }

  public void characters (char ch[], int start, int length)
  {
    if(ElementName.equals("name"))
    {
      for (int i = start; i < start + length; i++)
      {
        name = name + ch[i];
      }
    }
    else if(ElementName.equals("dbDriver"))
    {
      for (int i = start; i < start + length; i++)
      {
        dbDriver = dbDriver + ch[i];
      }
    }
    else if(ElementName.equals("host"))
    {
      for (int i = start; i < start + length; i++)
      {
        host = host + ch[i];
      }
    }
    else if(ElementName.equals("port"))
    {
      for (int i = start; i < start + length; i++)
      {
        port = port + ch[i];
      }
    }
    else if(ElementName.equals("sid"))
    {
      for (int i = start; i < start + length; i++)
      {
        sid = sid + ch[i];
      }
    }
    else if(ElementName.equals("username"))
    {
      for (int i = start; i < start + length; i++)
      {
        username = username + ch[i];
      }
    }
    else if(ElementName.equals("password"))
    {
      for (int i = start; i < start + length; i++)
      {
        password = password + ch[i];
      }
    }
    else if(ElementName.equals("statementStart"))
    {
      for (int i = start; i < start + length; i++)
      {
        statementStart = statementStart + ch[i];
      }
    }
    else if(ElementName.equals("fields"))
    {
      for (int i = start; i < start + length; i++)
      {
        fields = fields + ch[i];
      }
    }
    else if(ElementName.equals("tables"))
    {
      for (int i = start; i < start + length; i++)
      {
        tables = tables + ch[i];
      }
    }
    else if(ElementName.equals("method") && (ElementStart == true))
    {
      name = "";
      dbDriver = "";
      host = "";
      port = "";
      sid = "";
      username = "";
      password = "";
      statementStart = "";
      fields = "";
      tables = "";
    }
  }
}
