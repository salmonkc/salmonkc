package com.tru.connectionserver.dbases;

import java.sql.*;
import java.io.*;
import com.tru.connectionserver.server.*;

public class UniDataConnector 
{
  public UniDataConnector()
  {
  }

  public String getResult(API_CALL ConnElements) throws Exception
  {
    String outString = new String();
    outString = ConnElements.getSQL();
    if (ConnElements.getSQL().indexOf("{call ")== 0)  // Stored Procedure
      outString = callStoredProcedure(ConnElements);
    else  // query statement
      outString = runQuery(ConnElements);
      
    return outString;
  }
  
  private String runQuery(API_CALL ConnElements) throws Exception
  {
    //load driver
    try   
       { Class.forName("com.ibm.u2.jdbc.UniJDBCDriver"); }
    catch (Exception e)
       { return "Error Loading Database Driver\n" + e.getCause(); }
  
    String outString = new String("");

    // set up a connection
    String connString = "jdbc:ibm-u2://" + 
                         ConnElements.getHost() + "/" +
                         ConnElements.getPort() + ":" +
                         ConnElements.getSID(); 
    Connection conn = DriverManager.getConnection(connString, 
                                          ConnElements.getUser(), 
                                          ConnElements.getPass());
      // (jdbc:ibm-u2://host:port/account, user, pass);
    Statement stmt = conn.createStatement();
    
    if (ConnElements.getSQL().indexOf("SELECT")== 0)
    {
      try
      {
        ResultSet rs = stmt.executeQuery(ConnElements.getSQL());
        
        int columnCount = rs.getMetaData().getColumnCount();
   
        for (int I=1;I<=columnCount;I++) // rs is a 1 based array
        {
          outString = outString + rs.getMetaData().getColumnName(I) + "|";  
        }
        outString = outString.substring(0,(outString.length()-1));
        // length() - 1 remove '|' from end of line
        outString = outString + "\n";
    
        while (rs.next ()) // loop through result
        {
         // put each feild value int returning string
           for (int I=1;I<=columnCount;I++) // rs is a 1 based array
           {
               outString = outString + rs.getString(I) + "|";
           }   
           outString = outString.substring(0,(outString.length()-1));
        // length() - 1 remove '|' from end of line
           outString = outString + "\n";
        }
        stmt.close();
        rs.close();
      }
      catch (SQLException e)
      {
         outString = "Execution failed: " + e.getMessage() + 
                     "\"" + ConnElements.getSQL() + "\" ";
      }
    }  
    else  // else not 'SELECT'
    {
    
       try
       {
          int x = stmt.executeUpdate(ConnElements.getSQL());
          if (x==1) outString = "Execution was successful ";
          else outString = "Execution failed: " + 
                           "No changes have been made to database\n" + 
                           "\"" + ConnElements.getSQL() + "\" ";
      } 
      catch (SQLException e)
      {
         outString = "Execution failed: " + e.getMessage() + 
                     "\"" + ConnElements.getSQL() + "\" ";
      }
    }  
    
    stmt.close();
    conn.close();

    // length() - 1 remove new line from end of last line
    if (outString.length() > 0)
      outString.substring(0,(outString.length()-1));
    
    return outString;      
  }
  
  private String callStoredProcedure(API_CALL ConnElements) throws Exception
  {
     return "";
  }
}