package com.tru.connectionserver.dbases;

/**
 * <p>Title: OracleConnector</p>
 * <p>Description: connects to oracle databases</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: TRU</p>
 * @author sjohnson@tru.ca
 * @version 1.0
 */

import java.sql.*;
import com.tru.connectionserver.server.*;
import oracle.jdbc.*;

public class OracleConnector
{
  public OracleConnector()
  {
  }

  public String getResult(API_CALL ConnElements) throws Exception
  {
    String outString = new String();

    if (ConnElements.getSQL().indexOf("{ call ")== 0)  // Stored Procedure
      outString = callStoredProcedure(ConnElements);
    else  // query statement
      outString = runQuery(ConnElements);

    return outString;
  }

  private String runQuery(API_CALL ConnElements) throws Exception
  {
    DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver()); 
     
    String outString = new String("");

    // set up a connection
    String connString = "jdbc:oracle:thin:@" +
                         ConnElements.getHost() + ":" +
                         ConnElements.getPort() + ":" +
                         ConnElements.getSID();
    Connection conn = DriverManager.getConnection(connString,
                                          ConnElements.getUser(),
                                          ConnElements.getPass());
      // ("jdbc:oracle:thin:@machineName:port:SID, user, pass);
    Statement stmt = conn.createStatement();

    if (ConnElements.getSQL().indexOf("SELECT")== 0)
    {
      try
      {
outString = ConnElements.getSQL();
        ResultSet rs = stmt.executeQuery(ConnElements.getSQL());

        int columnCount = rs.getMetaData().getColumnCount();

        for (int I=1;I<=columnCount;I++) // rs is a 1 based array
        {
          outString = outString + rs.getMetaData().getColumnName(I) + "|";
        }
        outString = outString.substring(0,(outString.length()-1));
        // length() - 1 remove '|' from end of line
        outString = outString + "\n";

        while (rs.next ()) // loop through result
        {
         // put each feild value int returning string
           for (int I=1;I<=columnCount;I++) // rs is a 1 based array
           {
               outString = outString + rs.getString(I) + "|";
           }
           outString = outString.substring(0,(outString.length()-1));
        // length() - 1 remove '|' from end of line
           outString = outString + "\n";
        }
        stmt.close();
        rs.close();
        conn.close();
      }
      catch (SQLException e)
      {
         outString = "Execution failed: " + e.getMessage() +
                     "\"" + ConnElements.getSQL() + "\" ";
      }
    }
    else  // else not 'SELECT'
    {

       try
       {
          int x = stmt.executeUpdate(ConnElements.getSQL());
          if (x==1) outString = "Execution was successful ";
          else outString = "Execution failed: " +
                           "No changes have been made to database\n" +
                           "\"" + ConnElements.getSQL() + "\" ";
      }
      catch (SQLException e)
      {
         outString = "Execution failed: " + e.getMessage() +
                     "\"" + ConnElements.getSQL() + "\" ";
      }
    }

    stmt.close();
    conn.close();

    // length() - 1 remove new line from end of last line
    if (outString.length() > 0)
      outString.substring(0,(outString.length()-1));

    return outString;
  }

  private String callStoredProcedure(API_CALL ConnElements) throws Exception
  {
     String outString = new String("");

     Class.forName("oracle.jdbc.driver.OracleDriver");

     String[] inString, parts;
     inString = ConnElements.getSQL().split("\\|");
     // set up a connection
     String connString = "jdbc:oracle:thin:@" +
                          ConnElements.getHost() + ":" +
                          ConnElements.getPort() + ":" +
                          ConnElements.getSID();
     Connection conn = DriverManager.getConnection(connString,
                                           ConnElements.getUser(),
                                           ConnElements.getPass());
       // ("jdbc:oracle:thin:@machineName:port:SID, user, pass);
     String call = new String(inString[0]);
   //  {call p_highest_paid_emp(?,?,?,?)}
     CallableStatement pstmt = conn.prepareCall(call);
 //    pstmt.registerOutParameter(1, OracleTypes.VARCHAR);
 //    pstmt.executeUpdate();
 //    outString = pstmt.getString(1);
 //    int x=1; 
     
     for (int I = 1; I <=inString.length-1; I++)
     {
       parts = inString[I].split("~");
       String InValue;
       InValue = "" + parts[2];
       Integer Type = new Integer(parts[0]);
       if (parts[1].equals("1")) // value of 1 indicates an input var
       {
         switch (Type.intValue())
         {
           case 1:
             pstmt.setString(I, InValue);
             break;
           case 2:
             Integer Value_I = new Integer(InValue);
             pstmt.setInt(I, Value_I.intValue());
             break;
           case 3:
             Float Value_F = new Float(InValue);
             pstmt.setFloat(I, Value_F.floatValue());
             break;
         }
       }
       else
       {
         switch (Type.intValue())
         {
           case 1:
             pstmt.registerOutParameter(I, OracleTypes.VARCHAR);
             break;
           case 2:
             pstmt.registerOutParameter(I, Types.INTEGER);
             break;
           case 3:
             pstmt.registerOutParameter(I, OracleTypes.FLOAT);
             break;
           case 4:
             pstmt.registerOutParameter(I, OracleTypes.CURSOR);
             break;
         }
       }
     }
     try
     {
       pstmt.executeUpdate();
       
       outString = pstmt.getString(1);
   /*    
       outString = "Execution Complete: \n";

       for (int I = 1; I <=inString.length-1; I++)
       {
         parts = inString[I].split("~");
         String x = parts[0];
         if (parts[0].equals("0"))
         {
           outString = outString + pstmt.getObject(I).toString() + "|";
         }
       }
// */
       pstmt.close();
       conn.close();
     }
     catch (SQLException e)
     {
       outString = "Execution failed: " + e.getMessage() +
                   "\"" + ConnElements.getSQL() + "\" ";
     }
// */
     return outString;
  }
}
