package mypackage;

import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.MenuItem;
import net.rim.device.api.ui.container.MainScreen;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.component.BasicEditField;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.Menu;
import net.rim.device.api.ui.component.ObjectChoiceField;
import net.rim.device.api.ui.decor.BackgroundFactory;
import net.rim.device.api.util.StringProvider;

public class HelloBlackBerryScreen extends MainScreen {
    private BasicEditField calorieEditField;
    private BasicEditField fatEditField;
    private BasicEditField fibreEditField;
    private BasicEditField weightEditField;
    private BasicEditField durationEditField;
    private ObjectChoiceField levelChoiceField;
    String levels[] = {"low", "mod", "high" };

    public HelloBlackBerryScreen() {
        super( MainScreen.VERTICAL_SCROLL | MainScreen.VERTICAL_SCROLLBAR );
        setTitle( "Weight Watcher Points Plus Calculator" );
        getMainManager().setBackground(BackgroundFactory.createSolidBackground(10404569));
        
        LabelField foodLabel = new LabelField( "FOOD", LabelField.NON_FOCUSABLE );
        add( foodLabel );
        foodLabel.setMargin(30, 10, 5, 10);
        foodLabel.setBackground(BackgroundFactory.createSolidBackground(8299193));
        foodLabel.setPadding(5, 130, 5, 10);
        calorieEditField = new BasicEditField( "Enter Calories:", "", 5, BasicEditField.FILTER_REAL_NUMERIC );
        add( calorieEditField );
        calorieEditField.setMargin(15, 10, 5, 30);
        fatEditField = new BasicEditField( "Enter Fat:", "", 5, BasicEditField.FILTER_REAL_NUMERIC );
        add( fatEditField );
        fatEditField.setMargin(15, 10, 5, 30);
        fibreEditField = new BasicEditField( "Enter Fibre:", "", 5, BasicEditField.FILTER_REAL_NUMERIC );
        add( fibreEditField );
        fibreEditField.setMargin(15, 10, 0, 30);
        ButtonField buttonCalcFood = new ButtonField( "Calculate", ButtonField.CONSUME_CLICK | ButtonField.FIELD_RIGHT );
        add( buttonCalcFood );
        buttonCalcFood.setMargin(0, 30, 10, 0);
        buttonCalcFood.setChangeListener( new FieldChangeListener() {
            public void fieldChanged( Field arg0, int arg1 ) {
                calcFoodPoints();
            }
        } );
        
        
        LabelField activityLabel = new LabelField( "ACTIVITY", LabelField.FOCUSABLE );
        add( activityLabel );
        activityLabel.setMargin(20, 10, 5, 10);
        activityLabel.setBackground(BackgroundFactory.createSolidBackground(8299193));
        activityLabel.setPadding(5, 130, 5, 10);
        weightEditField = new BasicEditField( "Enter Weight:", "", 5, BasicEditField.FILTER_REAL_NUMERIC );
        add( weightEditField );
        weightEditField.setMargin(15, 10, 5, 30);
        durationEditField = new BasicEditField( "Enter Duration:", "", 5, BasicEditField.FILTER_REAL_NUMERIC );
        add( durationEditField );
        durationEditField.setMargin(15, 10, 5, 30);
        levelChoiceField = new ObjectChoiceField("Level",levels,0,ObjectChoiceField.FIELD_LEFT);
        add( levelChoiceField );
        levelChoiceField.setMargin(0, 10, 5, 30);
        ButtonField buttonCalcAct = new ButtonField( "Calculate", ButtonField.CONSUME_CLICK | ButtonField.FIELD_RIGHT );
        add( buttonCalcAct );
        buttonCalcAct.setMargin(0, 30, 10, 0);
        buttonCalcAct.setChangeListener( new FieldChangeListener() {
            public void fieldChanged( Field arg0, int arg1 ) {
                calcActPoints();
            }
        } );
    }

    protected void makeMenu( Menu menu, int instance ) {
    	super.makeMenu(menu, instance);
        MenuItem mntmSayHello = new NewMenuItem();
        menu.add( mntmSayHello );
    }

    private class NewMenuItem extends MenuItem {
        public NewMenuItem() {
            super( new StringProvider( "Calculate Points" ), 0, 0 );
        }

        public void run() {
            calcFoodPoints();
        }
    }

    private void calcFoodPoints() {
    	double points = 0.0;
    	double calorie = 0;
    	double fat = 0;
    	double fibre = 0;
    	
    	try {
           calorie = Double.parseDouble(calorieEditField.getText()) / 50;
    	   fat = Double.parseDouble(fatEditField.getText()) / 12;
    	   fibre = Double.parseDouble(fibreEditField.getText()) / 4;
    	   
    	   if (fibre > 4) { fibre = 4; }
    		
    	   points = (calorie + fat) - fibre;
    	   
    	   if ((points - ((int) points)) < 0.3)
       	   {
    		 points = Math.floor(points);
    	   } else if ((points - ((int) points)) < 0.7){
    		 points = Math.floor(points) + 0.5;
    	   } else {
    		 points = Math.ceil(points);
    	   }
    	   
    	   if (points < 0) { points = 0; }
    	   
           Dialog.inform("\n" + points + " Points" );
    	} catch (NumberFormatException e) {
    		Dialog.inform("\nAll food fields must have an entry." );
    	}
    }
    
    private void calcActPoints() {
    	  double weightInKG = 0;
    	  int weight=0;
    	  int duration=0;
    	  String level="";
    	  double factor=0;
    	  double points=0;
    	  try {
    		weightInKG = Double.parseDouble(weightEditField.getText())*0.453592;
    		weight = (int)weightInKG;
    	    duration = Integer.parseInt(durationEditField.getText());
    	    level = levels[levelChoiceField.getSelectedIndex()];     //levelEditField.getText();
    	  
    	    if (level=="low") {
    	      factor=0.051;
    	    } else if(level=="mod") {
    	      factor=0.0711;
    	    } else if(level=="high") {
    	      factor=0.1783;
    	    }
    	    
    	  points = (weight*duration*factor)/100;
    	  
    	  if ((points - ((int) points)) < 0.3)
      	  {
   		      points = Math.floor(points);
   	      } else if ((points - ((int) points)) < 0.6){
   		      points = Math.floor(points) + 0.5;
   	      } else {
   		      points = Math.ceil(points);
   	      }
   	   
   	      if (points < 0) {points = 0;}
   	   
          Dialog.inform("\n" + (int) points + " Points");
          
    	} catch (NumberFormatException e) {
      		Dialog.inform("\nAll activity fields must have an entry." );
      	}
    }
    
    public boolean onClose()
    {
        int response = Dialog.ask(Dialog.D_YES_NO,"Are you sure you want exit?");
        if (response == -1)
        {
            return false;
        }
        else
        {
            System.exit(0);
            return true;
        }
    }
}
