<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
  <!-- typeface -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei" rel="stylesheet">
	
  <!-- 3rd party css -->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- custom css -->
    <link rel="stylesheet" href="css/style.css">
	
  <!-- 3rd party javascript libraries -->
    <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <!-- custom javascript -->
    <script type="text/javascript" src="js/app.js"></script>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
	   <div id="title" class="col-sm-12">
	       <img src="images/headerPhoto.jpg" alt="Marissa Johnson and George Meyers">
	   </div>
	</div>
    <div class="row">
        <div class="menu col-sm-12">
            <a class="menuLink" href="/" id="homenav">The Couple</a>
            <a class="menuLink" href="/rsvp.php" id="rsvpnav">RSVP</a>
            <a class="menuLink" href="/details.php" id="detailsnav">Wedding Details</a>
  	        <a class="menuLink" href="/registry.php" id="registrynav">Registry</a>
        </div>
	</div>
    <div class="row">
	    <div class="col-sm-6 offset-sm-2">
          <p style="font-size:3em;">
            <strong>Here is some important information about our BIG day!</strong>
          </p>
		  <img src="images/fire.jpg">
        </div>
        <div id="countDown" class="col-sm-2"></div>
    </div>
    <div class="row">
      <div class="col-sm-8 offset-sm-2">
       <ul>
            <li>
                <p style="padding-top:15px;"><strong>The Ceremony:</strong></p>
                <p>
                  The ceremony will take place at 1:00pm at our church, New Life Church, at 2244 Ash Ave.
                </p>  
                  <span style="padding:15px;"><a href="maps.pdf" target="_blank"><img src="images/churchMap.jpg"></a></span>
            </li>
            <li>
                <p style="padding-top:15px;"><strong>The Reception:</strong></p>
                <p>
                  The reception is happening at the Meyer Ranch located at 6349 Pantage Lake Rd. It will take awhile to get 
                  out there since this address is almost 62 km from the church. Go over the bridge crossing the Fraser River (Moffet Bridge) and 
                  head up North Fraser Drive.  When you reach Bouchie Lake School, turn right onto Blackwater Road. We hope to start the reception around 
                  5:00pm so make sure you plan your trip to the ranch with this distance in mind.
                </p>
                <span style="padding:15px;"><a href="maps.pdf" target="_blank"><img src="images/receptionMap.jpg"></a></span>
                <p><strong>A couple more considerations for the reception:</strong></p>
                  <ul class="sublist">
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                        We would like this to be a dry event<strong> AKA no booze PLEASE!</strong>
                    </li>
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                        We respectfully request no children come to the reception.
                    </li>
                  </ul>
            </li>
            <li>
                <p style="padding-top:15px;"><strong>Maps:</strong></p>
                  <p>Click the link here to open a printable version of these maps</p>
                  <p style="font-size:1.4em padding:5px 0 20px 0;">&gt;&gt;&gt; <a href="maps.pdf" target="_blank">maps.pdf</a> &lt;&lt;&lt;</p>
            </li>
            <li>
                <p style="padding-top:15px;"><strong>Accomodations in Quesnel:</strong></p>
              <p>If you need a hotel in Quesnel, here is a list of a few we know of:</p>
                  <ul class="sublist">
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                      <strong>Sandman Hotel Quesnel</strong><br>
                      940 Chew Rd, Quesnel, BC V2J 6R8 • (250) 747-3511
                    </li>
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                      <strong>Ramada Limited Quesnel</strong><br>
                      383 St Laurent Ave, Quesnel, BC V2J 2E1 • (250) 992-5575
                    </li>
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                      <strong>Super 8 by Wyndham Quesnel BC</strong><br>
                      2010 Valhalla Rd, Quesnel, BC V2J 4C1 • (250) 747-1111
                    </li>
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                      <strong>Quality Inn</strong><br>
                      753 Front St, Quesnel, BC V2J 2L2 • (250) 992-7247
                    </li>
                    <li style="font-family: 'ZCOOL XiaoWei', serif; font-size: 1.3em;font-weight: 500;color: rgb(120,90,90);">
                      <strong>Tower Inn and Suites</strong><br>
                      500 Reid St, Quesnel, BC V2J 2M9 • (250) 992-2201</li>
                  </ul>
            </li>
          </ul>
        </div>
    </div>
    <div class="row" style="padding-top:20px;">
        <div class="menu col-sm-12">
            <a class="menuLink" href="/" id="homenav">The Couple</a>
            <a class="menuLink" href="/rsvp.php" id="rsvpnav">RSVP</a>
            <a class="menuLink" href="/details.php" id="detailsnav">Wedding Details</a>
  	        <a class="menuLink" href="/registry.php" id="registrynav">Registry</a>
        </div>
    </div>
  </div>
</body>
</html>