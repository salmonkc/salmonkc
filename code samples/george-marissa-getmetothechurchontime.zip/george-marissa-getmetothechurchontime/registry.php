<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
  <!-- typeface -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei" rel="stylesheet">
	
  <!-- 3rd party css -->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- custom css -->
    <link rel="stylesheet" href="css/style.css">
	
  <!-- 3rd party javascript libraries -->
    <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <!-- custom javascript -->
    <script type="text/javascript" src="js/app.js"></script>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
	   <div id="title" class="col-sm-12">
	       <img src="images/headerPhoto.jpg" alt="Marissa Johnson and George Meyers">
	   </div>
	</div>
	<div class="row">
        <div id="menu" class="col-sm-12">
            <a href="/" id="homenav">The Couple</a>
            <a href="/rsvp.php" id="rsvpnav">RSVP</a>
            <a href="/details.php" id="detailsnav">Wedding Details</a>
  	        <a href="/registry.php" id="registrynav">Registry</a>
        </div>
	</div>
	<div class="row">
	    <div class="col-sm-6 offset-sm-2">
	        <p>Hi Friends and Family!</p>
            <p>Welcome to our wedding website! Thank you for visiting. We are very excited to be getting married on May 18, 
			   2019 and we hope you can join us for our wedding. Our ceremony will take plave at New Life Church in Quesnel, 
			   BC with a reception to follow at the Meyer Ranch. <a href="/rsvp.php">Don't forget to RSVP</a>!</p>
        </div>
	    <div id="countDown" class="col-sm-2"></div>
    </div>
	<div class="row">
	    <div class="col-sm-6 offset-sm-2">
  </div>
</body>
</html>