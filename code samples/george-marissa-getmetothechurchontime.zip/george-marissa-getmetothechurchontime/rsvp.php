<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
  <!-- typeface -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei" rel="stylesheet">
	
  <!-- 3rd party css -->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- custom css -->
    <link rel="stylesheet" href="css/style.css">
	
  <!-- 3rd party javascript libraries -->
    <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <!-- custom javascript -->
    <script type="text/javascript" src="js/app.js"></script>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
	   <div id="title" class="col-sm-12">
	       <img src="images/headerPhoto.jpg" alt="Marissa Johnson and George Meyers">
	   </div>
	</div>    
    <div class="row">
        <div class="menu col-sm-12">
            <a class="menuLink" href="/" id="homenav">The Couple</a>
            <a class="menuLink" href="/rsvp.php" id="rsvpnav">RSVP</a>
            <a class="menuLink" href="/details.html" id="detailsnav">Wedding Details</a>
  	        <a class="menuLink" href="/registry.php" id="registrynav">Registry</a>
        </div>
    </div>
    <div class="row">
<?php
  $date = new DateTime("04/16/2019");
  $now = new DateTime();
// define variables and set to empty values
$firstname = "";
$lastname = "";
$fromEmail = "";
$attending = true;
$partyCount = 1;
$name1 = "";
$name2 = "";
$name3 = "";
$partyNames = [];
$comment = "";
$passcode = "";
$firstnameErr = "";
$lastnameErr = "";
$fromEmailErr = "";
$passcodeErr = "";
$err = false;

  if($date < $now) {
    echo '  <div class="col-sm-5 offset-sm-2" style="font-size:1.8em;padding-right:20px;padding-top:50px;">
                <p>Sorry,<br>
                   The RSVP was closed April 14</p></div>
            <div class="col-sm-5" style="padding-bottom:50px;"><img src="images/wedding.jpg" width="60%"></div>
          </div>';
  } else {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      if (empty($_POST["firstname"])) {
        $firstnameErr = "Your first name is required";
	    $err = true;
      } else {
        $firstname = test_input($_POST["firstname"]);
        array_push($partyNames,$firstname);
      }
      if (empty($_POST["lastname"])) {
        $lastnameErr = "Your last name is required";
	    $err = true;
      } else {
        $lastname = test_input($_POST["lastname"]);
      }
      if (empty($_POST["fromEmail"])) {
        $fromEmailErr = "Your email address is required";
	    $err = true;
      } else {
        $fromEmail = test_input($_POST["fromEmail"]);
      }
      if (empty($_POST["passcode"])) {
        $passcodeErr = "passcode is required";
        $err = true;
      } else {
        if ($_POST["passcode"] !== 'gettinhitched') {
          $err = true;
          $passcodeErr = "passcode is incorrect - please see your invitation";
		} else {
          $passcode = test_input($_POST["passcode"]);
	    }
	  }	
      if(isset($_POST["attending"])) {
        $attending = ($_POST["attending"]);
      }
      if(isset($_POST["comment"])) {
        $comment = $_POST["comment"];
      }
      if(isset($_POST["name1"])) {
        if(!empty($_POST["name1"])) {
          $name1 = test_input($_POST["name1"]);
          array_push($partyNames,$name1);
        }
      }
      if(isset($_POST["name2"])) {
        if(!empty($_POST["name2"])) {
          $name2 = test_input($_POST["name2"]);
          array_push($partyNames,$name2);
        }
      }
      if(isset($_POST["name3"])) {
        if(!empty($_POST["name3"])) {
          $name3 = test_input($_POST["name3"]);
          array_push($partyNames,$name3);
        }
      }  
      $partyCount = sizeof($partyNames);
    } else {
      $err = true;
    }

    if ($err) {
?>
	    <div class="col-sm-6 offset-sm-2">
            <h1>R.S.V.P.</h1><hr>
	        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" autocomplete="off">
                <div class="form-group row" style="margin-left:0;margin-right:0;">
                    <span style="margin-right:20px;">
                        <label for="firstname">First Name: *</label>
					    <input type="text" class="form-control col-sm-12" id="firstname" name="firstname" placeholder="first name" value="<?php echo $firstname;?>">
                        <span class="error"><?php echo $firstnameErr;?></span>
                  </span>
                  <span>
                    <label for="lastname">Last Name: *</label>
					<input type="text" class="form-control col-sm-12" id="lastname" name="lastname" placeholder="last name" value="<?php echo $lastname;?>">
					<span class="error"><?php echo $lastnameErr;?></span>
                  </span>
				</div>
                <div class="form-group">
			        <label for="fromEmail">Email: *</label>
					<input type="email" class="form-control" id="fromEmail" name="fromEmail" placeholder="Email" value="<?php echo $fromEmail;?>">
					<div class="error"><?php echo $fromEmailErr;?></div>
				</div>
                <div class="form-group">
                    Will you be able to attend?
				    <div class="form-check">
					    <input class="form-check-input" type="radio" name="attending" id="attending" value=1 checked>
					    <label class="form-check-label" for="attending">Absolutely! Wild horses couldn't keep me away.</label>
				    </div>
				    <div class="form-check">
					    <input class="form-check-input" type="radio" name="attending" id="attending" value=0>
					    <label class="form-check-label" for="attending">Sorry, I won't be able to make it.</label>
				    </div>
                </div>
                <div class="form-group">
                    Please add the names of all people your RSVPing for, including yourself. Because the reception is by invitation only, We kindly ask 
                       that you only include the names listed on the invitation, thank you.<br>
                    <div id="Names" style="padding-left:25px;padding-top:15px;"> 
                        <span class="form-text text-muted" style="padding-left:-10px;padding-bottom:15px;">
                            Please keep in mind the reception is by invitation only, also no children please.
                       </span>
                       <label for="name1">Name 1:</label>
					   <input type="text" class="form-control col-sm-4" id="name1" name="name1" placeholder="name 1" value="<?php echo $name1;?>">
                       <label for="name2">Name 2:</label>
					   <input type="text" class="form-control col-sm-4" id="name2" name="name2" placeholder="name 2" value="<?php echo $name2;?>">
                       <label for="name3">Name 3:</label>
					   <input type="text" class="form-control col-sm-4" id="name3" name="name3" placeholder="name 3" value="<?php echo $name3;?>">
                    </div>
                </div>
				<div class="form-group">	
				    <label for="comment">Comments:</label>
                    <textarea class="form-control" id="comment" name="comment" placeholder="comment"></textarea>
                </div>
                <div class="form-group row" style="margin-left:0;margin-right:0;">
                    <span class="col-sm-4" style="padding-left:0;">
                        <label for="passcode">Passcode: *</label>
					    <input type="password" class="form-control" id="passcode" name="passcode" placeholder="passcode">
					    <span class="error"><?php echo $passcodeErr;?></span>
                    </span>
                    <span class="col-sm-2" style="margin-left:200px;float:right;bottom:0;" >
				        <input class="btn btn-primary" type="submit" value="Submit">
                  </span>
				</div>	
            </form>
        </div>
<?php
    } else {
        $servername = "db771227465.hosting-data.io";
        $username = 'dbo771227465';
        $password = "Ph1rehose!";
        $dbname = "db771227465";
      
        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // set the PDO error mode to exception
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO `rsvp` (`firstname`, `lastname`, `email`, `attending`, `partycount`, `partnames`, `comment`) " .
			       "VALUES ('$firstname','$lastname','$fromEmail',$attending,$partyCount,'". implode(",",$partyNames)."','$comment')";
			// use exec() because no results are returned
			$conn->exec($sql);
			
			// email
			$msg = "$firstname $lastname has RSVP'd:\r\n";
			if ($attending) {
				if ($partyCount > 1) {
					$i = 1;
					foreach($partyNames as $name) { 
						if($i<($partyCount)) {
							$partyNamesStr .= $name.", ";
							$i++;
						} else {
							$partyNamesStr = rtrim($partyNamesStr,", ")." and ".$name;
						}
					}
					$msg .= "We are happy to attend.\r\n\r\n" .
					        "Counting me, we have " . $partyCount . " including: " . $partyNamesStr . "\r\n\r\n" .
							"Comment:\r\n$comment";
				} else {
					$msg .= "I'd be happy to attend\r\n" .
					        "Comment:\r\n$comment";
				}
			} else {
				$msg .= "Unfortunatly I will not able to attend\r\n\r\n" .
				        "Comment:\r\n$comment";
			}
			
			// send email
            $subject = "George and Marissa - RSVP";
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
              $headers = null; 
            } else {
              $headers = "From:$fromEmail";
            }
          
			$ourEmails = ["salmonkc95@gmail.com",
			              "fabulousfish41@gmail.com",
						  "Meyermarissa.0112@gmail.com"];
            foreach($ourEmails as $to) {
				if (empty($headers)) {
                  mail($to,$subject,$msg);
                } else {
                  mail($to,$subject,$msg,$headers);
                  mail($fromEmail,$subject,"Thank you for your RSVP! We are looking forward to seeing you on the 18th of May");
                }
			}
			
			echo "<div class='col-sm-6 offset-sm-2'>
                      <h1>Thank you for your RSVP!</h1><hr>
  	                  <p>We are looking forward to seeing you<br>on the 18th of May</p></div>";
		}
		catch(PDOException $e)
		{
			echo $sql . "<br>" . $e->getMessage();
		}

		$conn = null;
    }
?>	
	    <div id="countDown" class="col-sm-2">
        </div>
    </div>
<?php
  }
      
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>
    <div class="row">
        <div class="menu col-sm-12">
            <a class="menuLink" href="/" id="homenav">The Couple</a>
            <a class="menuLink" href="/rsvp.php" id="rsvpnav">RSVP</a>
            <a class="menuLink" href="/details.html" id="detailsnav">Wedding Details</a>
  	        <a class="menuLink" href="/registry.php" id="registrynav">Registry</a>
        </div>
    </div>
  </div>
</body>
</html>