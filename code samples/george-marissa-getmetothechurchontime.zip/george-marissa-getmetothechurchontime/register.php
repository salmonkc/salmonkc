<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
  <!-- typeface -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei" rel="stylesheet">
	
  <!-- 3rd party css -->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- custom css -->
    <link rel="stylesheet" href="css/style.css">
	
  <!-- 3rd party javascript libraries -->
    <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <!-- custom javascript -->
    <script type="text/javascript" src="js/app.js"></script>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
	   <div id="title" class="col-sm-12">
	       <img src="images/headerPhoto.jpg" alt="Marissa Johnson and George Meyers">
	   </div>
	</div>
    <div class="row">
        <div id="menu" class="col-sm-12">
            <a href="/" id="homenav">The Couple</a>
            <a href="/rsvp.html" id="rsvpnav">RSVP</a>
            <a href="/details.php" id="detailsnav">Wedding Details</a>
  	        <a href="/registry.php" id="registrynav">Registry</a>
        </div>
	</div>
    <div class="row">
	    <div class="col-sm-6 offset-sm-2">
	        <h1>Thank you for your RSVP!</h1>
			<p>We are looking forward to seeing you on the 18th of May</p>
	    <div id="countDown" class="col-sm-2">
	        
        </div>
    </div>  
  </div>
</body>
</html>