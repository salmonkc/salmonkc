﻿/******************************************************************************
* App.js
* Author: Sam Johnson
* 
* This file contains the program flow of the Action Tracking System 
* The Action Tracking System is designed to capture issues or findings 
* identified from a variety of sources, and see that they are resolved 
* through either a corrective or preventative action. The new system 
* will be utilized by all WFM pulp operations, as a replacement to legacy 
* systems in place as of mid-2016. The system is a key component of the 
* new corporate management systems being developed to meet ISO 14001:2015, 
* and 9001:2015 compliance.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
var appUrl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
var currentContext = SP.ClientContext.get_current();
var hostContext = new SP.AppContextSite(currentContext, hostUrl);
var currentUser = currentContext.get_web().get_currentUser();
var userGrps = ['noSite'];
var test = '';
var app = angular.module('actionTrackerApp', ['ngRoute']);
var permissionLevel = 'Viewer'; // level of permission
var POMUser = false;

// when a refresh happens view (data-ng-view) angularJS appends the templateUrl
// to the app web url. this removes the appended string giving the true app url
if (appUrl.indexOf('#') > 0) {
    appUrl = appUrl.substr(0, appUrl.indexOf('#'));
}

// see if we are in dev environment. when we are set a string to append to emails so
// people receiving notifications know it is just a test
if (appUrl.indexOf('developer') > 0) {
    test = '**TEST** - ';
}
/******************************
 *
 * angularjs app initialize
 * 
 ******************************/
app.config(function ($routeProvider) {
    ;
    //Used for configuring routes to the views
    $routeProvider
        .when("/", {
            templateUrl: "views/search.html",
            controller: "search",
            id: "search"
        })
        .when("/new", {
            templateUrl: "views/new.html",
            controller: "new",
            id: "new"
        })
        .when("/finding", {
            templateUrl: "views/finding.html",
            controller: "finding",
            id: "finding"
        })
        .when("/action", {
            templateUrl: "views/action.html",
            controller: "action",
            id: "action"
        })
        .when("/report", {
            templateUrl: "views/report.html",
            controller: "report",
            id: "report"
        })
        .when("/kpi", {
            templateUrl: "views/kpi.html",
            controller: "kpi",
            id: "kpi"
        })
        .when("/admin", {
            templateUrl: "views/admin.html",
            controller: "admin",
            id: "admin"
        });
    ;
});

/******************************
 *
 * sharepoint initialize
 * 
 ******************************/

// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(document).ready(function () {
    getTopBarNavLinks();
    currentUser.retrieve();
    currentContext.load(currentContext.get_web());
    currentContext.executeQueryAsync(
        function () { //On success function
            getUserRole(currentUser.get_id()).done(function () {
                if (POMUser) {
                    $("#mn-links").append('<li><a href="#/admin">Admin</a></li>');
                }
                $('#searchBtn').click();
            });
        },
        function () {
            console.log("Error getting current user role");
        });
});

function getUserRole(uID) {
    var dfd = $.Deferred();
    var web = hostContext.get_web();
    var lists = web.get_lists();
    var userList;
    var currentUserRole;
    var camlQuery = new SP.CamlQuery();
    var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>" +
        "<Where><Eq><FieldRef Name='person' LookupId='TRUE'/>" +
        "<Value Type='Integer'>" + uID + "</Value>" +
        "</Eq></Where></Query></View>";

    camlQuery.set_viewXml(camlQString);
    userList = lists.getByTitle('actionTrackerAdmin');
    currentUserRole = userList.getItems(camlQuery);
    currentContext.load(currentUserRole);
    currentContext.executeQueryAsync(
        function () {
            var enumerator = currentUserRole.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                if (currentListItem.get_item('PermissionLevel') == 'POM') {
                    POMUser = true;
                } else {
                    if (permissionLevel != 'Editor') {
                        permissionLevel = currentListItem.get_item('PermissionLevel');
                    }
                }
                userGrps = currentListItem.get_item('SiteID');
                console.log(userGrps);
            }

            if (userGrps[0] == 'noSite') {
                var userGroups;
                userGroups = currentUser.get_groups();
                currentContext.load(userGroups);
                currentContext.executeQueryAsync(
                    function () {
                        var groupsEnumerator = userGroups.getEnumerator();
                        var title = "";
                        //populate usrGrps array with the sites this user is a part of
                        // the user must be in the sharepoint group for this to work. IT IS NOT SUFFICIENT TO ADD THEM TO THE AD GROUP
                        while (groupsEnumerator.moveNext()) {
                            title = groupsEnumerator.get_current().get_title();
                            if (title.indexOf('-EVERYONE') > 0) {
                                userGrps[0] = title.substring(0, title.indexOf('-EVERYONE'));
                            }
                        }
                    },
                    function () {
                        alert('Failed to get user group names. Error: ' + args.get_message());
                    });
            }
            dfd.resolve();
        },
        function () {
            console.log("Error getting current user role");
            dfd.reject();
        });
    return dfd.promise();
}

// Function to retrieve a query string value.
function getQueryStringParameter(paramToRetrieve) {
    var params = document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}

/******************************
 *
 * global
 * 
 ******************************/

function getTopBarNavLinks() {
    for (var i = 0; i < topBarNavLinks.length; i++) {
        $("#treelineLinksBox").append('<li><a class="treelineLinks" href="' + topBarNavLinks[i].url + '">' + topBarNavLinks[i].name + '</a></li>');
    }
}
/*
function getUserInformation(listTitle, camlQString) {
        // make a promise
        var deferred = $q.defer();
        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // add filters
        var query = new SP.CamlQuery(); //The Query object. This is used to query for data in the List
        query.set_viewXml(camlQString);

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle);
        var items = list.getItems(query);
        currentContext.load(items);

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success 
            Function.createDelegate(this, function () {
                deferred.resolve(items);
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
}
*/
$(window).resize(function () {
    var height = window.innerHeight;
    var adjust = 300;
    var view = $('#view').val();
    if ((view != 'search') && (view != 'kpi') && (view != 'admin')) {
        adjust = 420;
    }
    $('.content').css('height', height - adjust + 'px');
    var width = window.innerWidth;
    if ((width < 920) && (width > 767)) {
        $("#treelineLogoBox").css('left', width - 350);
    } else {
        $("#treelineLogoBox").css('left', 0);
    }
});

//    because the buttons to remove related findings are dynamically created they 
//      are not part of the finding controller's $scope. this function passes the 
//      function call from the onClick event of these buttons to the controllers 
//      scoped function 
function removeRelatedFinding(toRemove) {
    var scope = angular.element(document.getElementById("main")).scope();
    scope.$apply(function () {
        scope.removeRelatedFinding(toRemove);
    });
}

//    because the buttons to remove attachments are dynamically created they 
//      are not part of any controller's $scope. this function passes the 
//      function call from the onClick event of these buttons to the controllers 
//      scoped function 
function removeAttachment(toRemove) {
    var scope = angular.element(document.getElementById("main")).scope();
    scope.$apply(function () {
        scope.removeAttachment(toRemove);
    });
}

var checkedRows = [];

$('#addRelatedTable').on('check.bs.table', function (e, row) {
    checkedRows.push({ id: row.id, FNo: row.finding });
    console.log(checkedRows);
});

$('#addRelatedTable').on('uncheck.bs.table', function (e, row) {
    $.each(checkedRows, function (index, value) {
        if (value.id === row.id) {
            checkedRows.splice(index, 1);
        }
    });
    console.log(checkedRows);
});

/**
   * Retrieves a valid form digest for web service calls
   * @returns {string} 
    */

function getFormDigest() {
    var dfd = $.Deferred(function () {
        $.ajax({
            url: appUrl + "/_api/contextinfo",
            type: "POST",
            headers: {
                "accept": "application/json;odata=verbose",
                "contentType": "text/xml"
            },
            success: function (data) {
                var requestdigest = data;
                var formDigest = requestdigest.d.GetContextWebInformation.FormDigestValue;
                dfd.resolve(formDigest);
            },
            error: function (err) {
                console.log(JSON.stringify(err));
            }
        });
    });
    return dfd.promise();
}

function sendEmail(from, to, body, subject) {
    var urlTemplate = appUrl + "/_api/SP.Utilities.Utility.SendEmail";
    var sendSuccess = 0;

    //get the form digest before sending the email
    getFormDigest().done(function (formDigest) {
        var addresses = to.split(",");

        for (var i = 0; i < addresses.length; i++) {
            $.ajax({
                contentType: 'application/json',
                url: urlTemplate,
                type: "POST",
                data: JSON.stringify({
                    'properties': {
                        '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                        'From': from,
                        'To': { 'results': [addresses[i]] },
                        'Body': body,
                        'Subject': subject
                    }
                }),
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": formDigest
                },
                success: function (data) {
                    sendSuccess = 1;
                },
                error: function (err) {
                    console.log(JSON.stringify(err));
                }
            })
        }
        setTimeout(function () {
            if (sendSuccess == 0) {
                console.log('An error has occured in sending an email notification to the person responsible for this finding');
            }
        }, 8000);
    });
}

