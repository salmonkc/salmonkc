﻿app.service('crudSvr', function ($q) {

    //Read records from a list
    //   parameters are:
    //    [0] String to identify the name of the list
    //    [1] String used to filter returned records - should be a CAML Query 
    this.get = function (listTitle, camlQString) {
        // make a promise
        var deferred = $q.defer();
        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // add filters
        var query = new SP.CamlQuery(); //The Query object. This is used to query for data in the List
        query.set_viewXml(camlQString);

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle);
        var items = list.getItems(query);
        currentContext.load(items);

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
        // success 
            Function.createDelegate(this, function () {
                deferred.resolve(items);
            }),
        // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

    //Add the new record in the List - parameters are:
    //   [0] String to identify the name of the list
    //   [1 . . n] initializing value required for a new record
    this.add = function (listTitle, recordData) {
        // make a promise
        var deferred = $q.defer();

        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle);

        // Object for creating Item in the List
        var listCreationInformation = new SP.ListItemCreationInformation();
        var listItem = list.addItem(listCreationInformation);

        // initial values for new finding record
        if (listTitle == 'actionTrackerFindings') {
            var finding = recordData;
            listItem.set_item("FindingNumber", finding.FindingNumber);
            listItem.set_item('Title', finding.FindingNumber);
            listItem.set_item("EnteredDate", finding.EnteredDate);
            listItem.set_item("FindingStatus", finding.FindingStatus);
            listItem.set_item("Operation", finding.Operation);
            listItem.set_item("Originator", finding.Originator);
            listItem.set_item("FindingOriginDue", new Date(finding.FindingOriginDue));
            listItem.set_item('Significance', finding.Significance);
            listItem.set_item("DateOccured", finding.DateOccured);
            listItem.set_item("Multisite", finding.Multisite);
        }

        if (listTitle == 'actionTrackerActions') {
            var action = recordData;
            listItem.set_item('ActionFindingNumber', action.ActionFindingNumber);
            listItem.set_item('ActionType', action.ActionType);
            listItem.set_item('ActionShortDescription', action.ActionShortDescription);
            listItem.set_item('ActionLongDescription', action.ActionLongDescription);
            listItem.set_item('ActionApproved', action.ActionApproved);
            listItem.set_item('ActionApprover', action.ActionApprover);
            listItem.set_item('ActionResult', action.ActionResult);
            listItem.set_item('ActionDueDate', new Date(action.ActionDueDate));
            listItem.set_item('ActionAssignedTo', action.ActionAssignedTo);
            listItem.set_item('ActionStatus', action.ActionStatus);
        }

        if (listTitle == 'actionTrackerReports') {
            var report = recordData;
            listItem.set_item('ReportFindingNumber', report.ReportFindingNumber);
            listItem.set_item('ReportAudience', report.ReportAudience);
            listItem.set_item('ReportDueDate', new Date(report.ReportDueDate));
            listItem.set_item('ReportAssignedTo', report.ReportAssignedTo);
            listItem.set_item('ReportStatus', report.ReportStatus);
            listItem.set_item('ReportComment', report.ReportComment);
        }
        if (listTitle == 'actionTrackerAdmin') {
            var admin = recordData
            var email = admin.Person.get_lookupValue();
            listItem.set_item('Title', email);
            listItem.set_item('person', admin.Person);
            listItem.set_item('SiteID', admin.SiteID);
            listItem.set_item('PermissionLevel', admin.permissionLevel);
        }
        // Update the List Item
        listItem.update();
        currentContext.load(listItem);

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                deferred.resolve(listItem);
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
           );

        return deferred.promise;
    };
 
    // Update a record in a list
    //   parameters are:
    //    [0] String to identify the name of the list
    //    [1] Java object that encasulates fields of a single record 
    this.update = function (listTitle, recordData, recordID) {
        // make a promise
        var deferred = $q.defer();

        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle);
        currentContext.load(list);

        // Get item to be updated from SharePoint
        var listItemToUpdate = list.getItemById(recordID);
        currentContext.load(listItemToUpdate);

        // update all fields in the finding record and send it back to SharePoint
        if (listTitle == 'actionTrackerFindings') {
            var finding = recordData;
            listItemToUpdate.set_item('FindingAssignedTo', finding.FindingAssignedTo);
            listItemToUpdate.set_item('Notify', finding.Notify);
            listItemToUpdate.set_item('ReportTo', finding.ReportTo);
            listItemToUpdate.set_item('Title', finding.FindingNumber);
            listItemToUpdate.set_item("FindingStatus", finding.FindingStatus);
            if (finding.FindingStatus == 'Complete') {
                listItemToUpdate.set_item('FindingCompletionDate', new Date());
                listItemToUpdate.set_item('ResultsApprover', currentUser.get_email());
            }
            if (finding.FindingCategory) {
                listItemToUpdate.set_item('FindingCategory', finding.FindingCategory.join());
            }
            listItemToUpdate.set_item('FindingType', finding.FindingType);
            listItemToUpdate.set_item('Operation', finding.Operation);
            listItemToUpdate.set_item('FindingDept', finding.FindingDept);
            listItemToUpdate.set_item('Originator', finding.Originator);
            listItemToUpdate.set_item('FindingOriginDue', new Date(finding.FindingOriginDue));
            listItemToUpdate.set_item('NonConfDescription', finding.NonConfDescription);
            listItemToUpdate.set_item('NonConfCause', finding.NonConfCause);
            listItemToUpdate.set_item('SimilarNonConf', finding.RelatedNonConf);
            listItemToUpdate.set_item('NonConfInvestigation', finding.NonConfInvestigation);
            if (finding.FindingCompleteDue) {
                listItemToUpdate.set_item('FindingCompleteDue', new Date(finding.FindingCompleteDue));
            }
            listItemToUpdate.set_item('Significance', finding.Significance);
            if (finding.DateOccured) {
                listItemToUpdate.set_item('DateOccured', new Date(finding.DateOccured));
            }
            listItemToUpdate.set_item("CompletionRemarks", finding.CompletionRemarks);
            listItemToUpdate.set_item("Multisite", finding.Multisite);
        }

        // update all fields in the action record and send it back to SharePoint
        if (listTitle == 'actionTrackerActions') {
            var action = recordData;
            listItemToUpdate.set_item('ActionFindingNumber', action.ActionFindingNumber);
            listItemToUpdate.set_item('ActionType', action.ActionType);
            listItemToUpdate.set_item('ActionShortDescription', action.ActionShortDescription);
            listItemToUpdate.set_item('ActionLongDescription', action.ActionLongDescription);
            listItemToUpdate.set_item('ActionApproved', action.ActionApproved);
            listItemToUpdate.set_item('ActionApprover', action.ActionApprover);
            listItemToUpdate.set_item('ActionResult', action.ActionResult);
            listItemToUpdate.set_item('ActionDueDate', new Date(action.ActionDueDate));
            listItemToUpdate.set_item('ActionAssignedTo', action.ActionAssignedTo);
            if (action.ActionCompletionDate) {
                listItemToUpdate.set_item('ActionCompletionDate', action.ActionCompletionDate);
            }
            listItemToUpdate.set_item('ActionStatus', action.ActionStatus);
        }

        // update all fields in the report record and send it back to SharePoint
        if (listTitle == 'actionTrackerReports') {
            var report = recordData;
            listItemToUpdate.set_item('ReportFindingNumber', report.ReportFindingNumber);
            listItemToUpdate.set_item('ReportAudience', report.ReportAudience);
            listItemToUpdate.set_item('ReportDueDate', new Date(report.ReportDueDate));
            listItemToUpdate.set_item('ReportAssignedTo', report.ReportAssignedTo);
            listItemToUpdate.set_item('ReportStatus', report.ReportStatus);
            listItemToUpdate.set_item('ReportComment', report.ReportComment);
        }
        if (listTitle == 'actionTrackerAdmin') {
            var admin = recordData;
            listItemToUpdate.set_item('SiteID', admin.SiteID);
            listItemToUpdate.set_item('PermissionLevel', admin.permissionLevel);
        }
        listItemToUpdate.update();

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                deferred.resolve(listItemToUpdate);
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

    this.remove = function (listTitle, recordID) {
        // make a promise
        var deferred = $q.defer();

        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle); 
        currentContext.load(list);

        // Get item to be updated from SharePoint
        var listItemToRemove = list.getItemById(recordID);
        currentContext.load(listItemToRemove);
        listItemToRemove.deleteObject();
        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                deferred.resolve();
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

    this.approveChildren = function (listTitle, camlQString) {
        // make a promise
        var deferred = $q.defer();
        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // add filters
        var query = new SP.CamlQuery(); //The Query object. This is used to query for data in the List
        query.set_viewXml(camlQString);

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle);
        var items = list.getItems(query);
        currentContext.load(items);
        
        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                var childrenEnumerator = items.getEnumerator();
                while (childrenEnumerator.moveNext()) {
                    var currentListItem = childrenEnumerator.get_current();
                    
                    var recID = currentListItem.get_item('ID');
                    updateStatus(listTitle, 'In Progress', recID);
                    if (listTitle === 'actionTrackerActions') {
                        sendTo = currentListItem.get_item('ActionAssignedTo').get_email();
                        subject = test + "Action Tracker: Action Assignment on Finding " + currentListItem.get_item('ActionFindingNumber');
                        body = test + "<p>An Action attached to finding " + currentListItem.get_item('ActionFindingNumber') + " has been moved to 'In Progress' status. This Action has been assigned to you.</p>" +
                            "<b>Action Details:</b><br>" +
                            "<b> Title:</b> " + currentListItem.get_item('ActionShortDescription') + "<br>" +
                            "<b> Description:</b> " + currentListItem.get_item('ActionLongDescription') + "<br>" +
                            "<b> Finding Number:</b> " + currentListItem.get_item('ActionFindingNumber') + "<br>" +
                            "<b> Status:</b> In Progress<br>" +
                            "<p>Please do not reply to this email as this address is not monitored.</p>" +
                            "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + currentListItem.get_item('ActionFindingNumber') + "</p>";
                    } else {
                        sendTo = currentListItem.get_item('ReportAssignedTo').get_email();
                        subject = test + "Action Tracker: Report Assignment on Finding " + currentListItem.get_item('ReportFindingNumber');
                        body = test + "<p>A Report attached to finding " + currentListItem.get_item('ReportFindingNumber') + " has been moved to 'In Progress' status. This Report has been assigned to you.</p>" +
                            "<b>Report Details:</b><br>" +
                            "<b> Audience:</b> " + currentListItem.get_item('ReportAudience') + "<br>" +
                            "<b> Finding Number:</b> " + currentListItem.get_item('ReportFindingNumber') + "<br>" +
                            "<b> Status:</b> In Progress<br>" +
                            "<p>Please do not reply to this email as this address is not monitored.</p>" +
                            "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + currentListItem.get_item('ReportFindingNumber') + "</p>";
                    }

                    if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                        sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                    }
                }
                
                deferred.resolve();
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

    function updateStatus(listTitle, status, recordID) {
        // make a promise
        var deferred = $q.defer();

        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // Get the List based upon the listTitle
        var list = lists.getByTitle(listTitle);
        currentContext.load(list);

        // Get item to be updated from SharePoint
        var listItemToUpdate = list.getItemById(recordID);
        currentContext.load(listItemToUpdate);

        // update all fields in the action record and send it back to SharePoint
        if (listTitle == 'actionTrackerActions') {
            var approved = true;
            var approver = SP.FieldUserValue.fromUser(currentUser.get_email());
            listItemToUpdate.set_item('ActionApproved', approved);
            listItemToUpdate.set_item('ActionApprover', approver);
            listItemToUpdate.set_item('ActionStatus', status);
        }

        // update all fields in the report record and send it back to SharePoint
        if (listTitle == 'actionTrackerReports') {
            listItemToUpdate.set_item('ReportStatus', status);
        }
        listItemToUpdate.update();

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                deferred.resolve(listItemToUpdate);
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

    this.updateCompDueDate = function updateCompDueDate(newCompDate, recordID) {
        // make a promise
        var deferred = $q.defer();

        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // Get the List based upon the listTitle
        var list = lists.getByTitle('actionTrackerFindings');
        currentContext.load(list);

        // Get item to be updated from SharePoint
        var listItemToUpdate = list.getItemById(recordID);
        currentContext.load(listItemToUpdate);

        // update findingCompleteDue field in the finding record and send it back to SharePoint
        listItemToUpdate.set_item('FindingCompleteDue', newCompDate);

        listItemToUpdate.update();

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                deferred.resolve(listItemToUpdate);
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

    this.verify = function verify(recordID) {
        // make a promise
        var deferred = $q.defer();

        // Get the SharePoint Context object based upon the URL
        var web = hostContext.get_web();
        var lists = web.get_lists();

        // Get the List based upon the listTitle
        var list = lists.getByTitle('actionTrackerFindings');
        currentContext.load(list);

        // Get item to be updated from SharePoint
        var listItemToUpdate = list.getItemById(recordID);
        currentContext.load(listItemToUpdate);

        // update findingStatus field in the finding record and send it back to SharePoint
        listItemToUpdate.set_item('FindingStatus', 'Verified');

        listItemToUpdate.update();

        // Execute the Query Asynchronously
        currentContext.executeQueryAsync(
            // success
            Function.createDelegate(this, function () {
                deferred.resolve(listItemToUpdate);
            }),
            // fail
            Function.createDelegate(this, function (sender, args) {
                deferred.reject('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            })
        );
        return deferred.promise;
    };

});