﻿app.service('fileUploadSvr', function ($q) {

   var file;
   var contents;
   var attachListTitle;
   var attachItemId;

   //  Read files
   this.addAttachment = function attachDocument(fileId, attachmentsListId, listTitle, itemId) {
       var deferred = $q.defer();
       var i = 0;
       attachListTitle = listTitle;
       attachItemId = itemId;
       var fileInput = $('#' + fileId);
       var files = fileInput[0].files;

       if (files.length > 0) {
           file = files[0];

           var reader = new window.FileReader();
           reader.onload = function (event) {
               contents = event.target.result;
               
               var contents2 = arrayBufferToBase64(contents);
               //  Initialize RequestExecutor with app web url
               var requestExecutor = new SP.RequestExecutor(appUrl);

               var url = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/GetByTitle('" +
                         attachListTitle +
                         "')/items(" +
                         attachItemId +
                         ")/AttachmentFiles/add(FileName='" +
                         file.name +
                         "')?@target='" + hostUrl + "'";

               requestExecutor.executeAsync({
                   url: url,
                   method: "POST",
                   binaryStringRequestBody: true,
                   body: contents2,
                   success: requestExecutorSuccess,
                   error: requestExecutorFail,
                   state: "Update"
               });

               function requestExecutorSuccess(data) {
                   console.log("Document successfully uploaded and attached to item");
                   deferred.resolve();
               }

               function requestExecutorFail(data, errorCode, errorMessage) {
                   console.log(data.body);
                   deferred.reject(errorCode + " - " + errorMessage + "\n" + data.body);
               }
               
           }
           reader.onerror = function (event) {
               console.error("File reading error " + event.target.error.code);
           };
           reader.readAsArrayBuffer(file);
       }
       return deferred.promise;
   }

   this.removeAttachment = function deleteFileAttachment(listTitle, itemId, toDeleteFileName) {
       var deferred = $q.defer();
       //Get the clientcontext and web object   
       var web = hostContext.get_web();
       var lists = web.get_lists();

       //Get attachment folder for the list item  
       var attachmentFolder = web.getFolderByServerRelativeUrl('Lists/' + listTitle + '/Attachments/' + itemId);
       attachmentFiles = attachmentFolder.get_files();

       //Load clientcontext and execute the batch  
       currentContext.load(attachmentFiles);

       // Execute the Query Asynchronously
       currentContext.executeQueryAsync(
           // success
           function (sender, args) {
               var attachmentEnumerator = attachmentFiles.getEnumerator();
               while (attachmentEnumerator.moveNext()) {
                   var currentFileName = attachmentEnumerator.get_current().get_name();
                   if (currentFileName == toDeleteFileName) {
                       deleteAttachment = attachmentEnumerator.get_current();
                   }
               }
               deleteAttachment.deleteObject();
               deferred.resolve();
           },
           // fail
           function (sender, args) {
               console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
               deferred.reject();
           })
       return deferred.promise;
   };

   this.listAttachment = function listAttachment(listTitle, itemId) {
       var deferred = $q.defer();
       var fileList = [];
       //Get the clientcontext and web object   
       var web = hostContext.get_web();
       var lists = web.get_lists();

       //Get attachment folder for the list item  
       var attachmentFolder = web.getFolderByServerRelativeUrl('Lists/' + listTitle + '/Attachments/' + itemId);
       attachmentFiles = attachmentFolder.get_files();

       //Load clientcontext and execute the batch  
       currentContext.load(attachmentFiles);

       // Execute the Query Asynchronously
       currentContext.executeQueryAsync(
           // success
           function () {
               var attachmentEnumerator = attachmentFiles.getEnumerator();
               while (attachmentEnumerator.moveNext()) {
                   fileList.push(attachmentEnumerator.get_current().get_name());
               }
               deferred.resolve(fileList);
           },
           // fail
           function (sender, args) {
               deferred.reject(args.get_message());
           })
       return deferred.promise;
   };

   //  Converts an array buffer to a base64-encoded string for form post
   function arrayBufferToBase64(buffer) {
        var binary = '';
        var bytes = new window.Uint8Array(buffer);
        var len = bytes.byteLength;
        for (var i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return binary;
   }

});