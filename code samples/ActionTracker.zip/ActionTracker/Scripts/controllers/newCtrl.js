﻿/******************************************************************************
* newCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* new finding page of the The Action Tracking app.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('new', function ($scope, $location, crudSvr) {
    // properties
    $scope.finding = {
        FindingNumber: 0,
        EnteredDate: "",
        FindingStatus: "",
        Operation: "",
        Originator: "",
        FindingOriginDue: "",
    };
    $scope.showDlgBox = false;
    $scope.dlgContent = '';

    // initialize
    getFindingNumber();

    // methods
    // Get next Finding Number
    function getFindingNumber() {
        if (permissionLevel != 'Viewer') {
            $('#newContent').html("<h1>Creating new Finding . . .  Please wait</h1>");
            var camlQString = "<View><Query><OrderBy><FieldRef Name='FindingNumber' Ascending='False' /></OrderBy></Query><RowLimit>1</RowLimit></View>";
            var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
            var currentMax = 500;
            promiseGet.then(function (resp) {
                var enumerator = resp.getEnumerator();
                while (enumerator.moveNext()) {
                    var currentListItem = enumerator.get_current();
                    currentMax = currentListItem.get_item('FindingNumber');
                }
                $scope.finding.FindingNumber = parseInt(currentMax) + 1;
                // create the new finding using the incrimented Finding Number
                create();
            }, function (err) {
                $scope.showDlgBox = "error";
                $scope.dlgContent = "An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.";
                console.log("Error getting new finding number: " + err);
            });
        } else {
            $('#newContent').html("<h1>Sorry, a new Action Tracker Finding could not be created.</h1><b>To be able to create a Finding you must have appropriate security group membership.</b>");

        }
    }

    // create the new finding using the incrimented Finding Number
    function create() {
        // Object for creating Item in the List
        var enteredDate = new Date();
        var originDue = new Date();
        originDue.setDate(originDue.getDate() + 30);
        var originator = currentUser.get_title();

        $scope.finding.EnteredDate = enteredDate;
        $scope.finding.FindingStatus = "New";
        $scope.finding.Operation = userGrps[0];;
        $scope.finding.Originator = originator;
        $scope.finding.FindingOriginDue = originDue;
        var promiseAdd = crudSvr.add('actionTrackerFindings', $scope.finding);
        promiseAdd.then(function () {
            // redirect browser to edit page so user can add information to the new finding
            $location.path('finding').search({ INo: $scope.finding.FindingNumber });
        }, function (err) {
            $scope.showDlgBox = "error";
            $scope.dlgContent = "An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.";
            console.log("Error creating new finding: " + err);
        });  
    }
});