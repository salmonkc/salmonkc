﻿/******************************************************************************
* reportCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* report page of the The Action Tracking app. This page is used to enter new or 
* edit the details of an report associated with an finding.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('report', function ($scope, $location, crudSvr, fileUploadSvr) {
    // properties
    $scope.report = {
        ReportSPID: null,
        ReportFindingNumber: "",
        ReportFindingID: "",
        ReportAudience: "Customer",
        ReportAssignedTo: "",
        ReportStatus: "New",
        ReportDueDate: "",
        ReportComment: ""
    };
    $scope.showDlgBox = '';
    $scope.saveBtnEnabled = true;
    $scope.reportSPID = $location.search().RId;
    $scope.findingNo = $location.search().FId;
    $scope.findingEditor = ($location.search().IEditor == 'true');
    if ($location.search().dueDate) {
        $scope.compDate = $location.search().dueDate;
    } else {
        $scope.compDate = new Date("Jan 1, 2000"); // set default date to past date
    }
    $scope.canApprove = false;
    $scope.canComplete = false;
    $scope.canCancel = false;
    $scope.newStatus = false;
    $scope.newStatus = false;
    $scope.initRadio = 1;
    $scope.AttachedFileNames = [];
    $scope.removeAttachedFileName = "";
    $scope.updateAttachedFileName = "";
    $scope.otherReportAudience = "";
    $scope.$watch("report.ReportAudience", function (newValue) {
        switch (newValue) {
            case 'Customer':
                $scope.initRadio = 1;
                $scope.otherReportAudience = "";
                break;
            case 'Environment Canada':
                $scope.initRadio = 2;
                $scope.otherReportAudience = "";
                break;
            case 'Ministry of Environment':
                $scope.initRadio = 3;
                $scope.otherReportAudience = "";
                break;
            case 'Provincial Emergency Plan':
                $scope.initRadio = 4;
                $scope.otherReportAudience = "";
                break;
            default:
                $scope.initRadio = 5;
                if (newValue != "Other") {
                    $scope.otherReportAudience = newValue;
                }
                break;
        }
    });

    // set scroll bar height
    var height = window.innerHeight;
    $('.content').css('height', height - 420 + 'px');
    // load the finding into form
    load();

    // methods
    //Load an Finding
    function load() {
        // set up datepickers
        $("#reportDueDateField").datepicker({
            autoclose: true,
            dateFormat: 'm/d/yyyy'
        });
        // set up peoplepickers
        // Render and initialize the client-side People Picker.
        var schema = {};
        var width = '73%';
        schema['PrincipalAccountType'] = 'User,DL,SecGroup,SPGroup';
        schema['SearchPrincipalSource'] = 15;
        schema['ResolvePrincipalSource'] = 15;
        schema['AllowMultipleValues'] = false;
        schema['MaximumEntitySuggestions'] = 50;

        // Render and initialize the picker. 
        SPClientPeoplePicker_InitStandaloneControlWrapper('reportAssignedToDiv', null, schema);
        $('#reportAssignedToDiv_TopSpan').width(width);

        if ($scope.reportSPID) {
            var camlQString = "<View><Query><Where>"
                            + "      <Eq><FieldRef Name='ID' /><Value Type='Text'>" + $scope.reportSPID + "</Value></Eq>"
                            + "</Where></Query></View>";

            var promiseGet = crudSvr.get('actionTrackerReports', camlQString);
            promiseGet.then(function (resp) {
                var enumerator = resp.getEnumerator();

                while (enumerator.moveNext()) {
                    var currentListItem = enumerator.get_current();
                    $scope.report.ReportSPID = currentListItem.get_item('ID');
                    $scope.report.ReportFindingNumber = currentListItem.get_item('ReportFindingNumber');
                    $scope.report.ReportAudience = currentListItem.get_item('ReportAudience');
                    $scope.report.ReportAssignedTo = currentListItem.get_item('ReportAssignedTo');
                    $scope.report.ReportStatus = currentListItem.get_item('ReportStatus');
                    var dueDate = currentListItem.get_item('ReportDueDate');
                    if (dueDate) {
                        $scope.report.ReportDueDate = (dueDate.getMonth() + 1) + "/" + dueDate.getDate() + "/" + dueDate.getFullYear();
                    }
                    $scope.report.ReportComment = currentListItem.get_item('ReportComment');
                }
                $scope.findingNo = $scope.report.ReportFindingNumber;

                // populate AssignedTo field
                if ($scope.report.ReportAssignedTo) {
                    var reportAssignedToPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict.reportAssignedToDiv_TopSpan;
                    var reportAssignedTo = $scope.report.ReportAssignedTo;
                    var reportAssignedToObj = { 'Key': reportAssignedTo.get_email() };
                    reportAssignedToPeoplePicker.AddUnresolvedUser(reportAssignedToObj, true);
                    // only assign to and originator can make changes
                    if ((reportAssignedTo.get_email() == currentUser.get_email()) || ($scope.findingEditor)) {
                        $scope.saveBtnEnabled = true;
                    } else {
                        $scope.saveBtnEnabled = false;
                    }
                }

                // if this report has a complete status then remove save button
                if ($scope.report.ReportStatus == 'Complete') {
                    $scope.saveBtnEnabled = false;
                    $scope.findingEditor = false;
                    $scope.canCancel = false;
                }

                if ($scope.saveBtnEnabled) {
                    if ($scope.report.ReportStatus == 'New') {
                        $scope.canCancel = true;
                    }
                    if ($scope.report.ReportStatus == 'Waiting Approval') {
                        $scope.canApprove = true;
                        $scope.canCancel = true;
                    }
                    if ($scope.report.ReportStatus == 'In Progress') {
                        $scope.canComplete = true;
                        $scope.canCancel = true;
                    }
                }
                $scope.deleteButtonTitle = "Delete";
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error getting this report: " + err);
            });
        } else {
            $scope.report.ReportFindingNumber = $scope.findingNo;
            $scope.deleteButtonTitle = "Cancel";
        }
        getFindingID();
    }

    function getFindingID() {
        var camlQString = "<View><Query><Where>"
                     + "      <Eq><FieldRef Name='FindingNumber' /><Value Type='Text'>" + $scope.findingNo + "</Value></Eq>"
                     + "</Where></Query></View>";
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            var enumerator = resp.getEnumerator();
            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                $scope.report.ReportFindingID = currentListItem.get_item('ID');
            }
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error loading this finding ID: " + err);
        });
    }

    $scope.save = function save() {
        if (invalid()) {
            if ($scope.showDlgBox != "error") {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html('This Report is missing required information. Please correct and resubmit');
            }
            return;
        }
        if ($scope.report.ReportStatus == "New") {
            $scope.report.ReportStatus = "Waiting Approval";
            $scope.newStatus = true;
        }
        $scope.deleteButtonTitle = "Delete";
        update();
    }

    $scope.complete = function complete() {
        if (invalid()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Report is missing required information. Please correct and resubmit');
            return;
        }
        $scope.report.ReportStatus = 'Complete';
        $scope.newStatus = true;
        update();
        $scope.findingEditor = false;
        $scope.canComplete = false;
    }

    $scope.approve = function approve() {
        if (invalid()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Report is missing required information. Please correct and resubmit');
            return;
        }
        $scope.report.ReportStatus = 'In Progress';
        $scope.newStatus = true;
        update();
        findingEditor = false;
    }

    //  cancel new report
    $scope.cancel = function cancel() {
        if ($scope.report.ReportStatus == "New") {
            $('.modal-backdrop').remove();
            window.location.href = "#/finding?INo=" + $scope.findingNo;
            return;
        }
        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.remove('actionTrackerReports', $scope.report.ReportSPID);
        promiseGet.then(function () {
            // inform user of successful update
            $scope.showDlgBox = "canceled";
            $("#canceledDlgContent").html('The report has been removed');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error cancelling this report: " + err);
        });
    }

    function update() {
        // call sharepoint for data through crudSvr
        var promiseGet = "";
        if ($scope.report.ReportSPID) {
            promiseGet = crudSvr.update('actionTrackerReports', $scope.report, $scope.report.ReportSPID);
        } else {
            promiseGet = crudSvr.add('actionTrackerReports', $scope.report);
        }
        promiseGet.then(function (resp) {
            $scope.report.ReportSPID = resp.get_item('ID');
            // inform user of successful update
            $scope.showDlgBox = "saved";
            $("#savedDlgContent").html('This report was succesfully saved');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error updating this report: " + err);
        });
        var rDueDate = new Date($scope.report.ReportDueDate);
        var fDueDate = new Date($scope.compDate);
        if (rDueDate.getTime() > fDueDate.getTime()) {
            promiseGet = crudSvr.updateCompDueDate(rDueDate, $scope.report.ReportFindingID);
            promiseGet.then(function (resp) {
                return;
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error updating this finding Complete By: " + err);
            });
        }
    }

    //  close dlgbox
    $scope.close = function close() {
        if ($scope.showDlgBox == "error") {
            $scope.showDlgBox == "";
            return;
        }

        if ($scope.showDlgBox == "canceled") {
            if ($scope.report.ReportStatus == 'In Progress') {
                notify("cancel");
            }
            $('.modal-backdrop').remove();
            window.location.href = "#/finding?INo=" + $scope.findingNo;
            return;
        }

        if ($scope.showDlgBox == "saved") {
            if (($scope.report.ReportAssignedTo.get_email() == currentUser.get_email()) || ($scope.findingEditor)) {
                $scope.saveBtnEnabled = true;
            } else {
                $scope.saveBtnEnabled = false;
            }
            if ($scope.saveBtnEnabled) {
                if ($scope.report.ReportStatus == 'In Progress') {
                    $scope.canApprove = false;
                    $scope.canComplete = true;
                    $scope.canCancel = true;
                }
                if ($scope.report.ReportStatus == 'Complete') {
                    $scope.canCancel = false;
                    $scope.canApprove = false;
                    $scope.canComplete = false;
                    $scope.saveBtnEnabled = false;
                }
            }
        }
        if ($scope.newStatus) {
            $scope.newStatus = false;
            
            if ($scope.report.ReportStatus == 'Waiting Approval') {
                notify("new");
            } else {
                notify("statusUpdate");
            }
            if ($scope.report.ReportStatus != 'Waiting Approval') {
                notify("statusUpdate");
            }
        }
        $scope.showDlgBox = '';
    }

    function invalid() {
        var invalid = false;
        // reset fields
        $('div').removeClass("has-error");
        $('label').removeClass("has-error");

        if ($scope.initRadio == 5) {
            if (!$scope.otherReportAudience) {
                $('#otherReportAudienceFieldLabel').addClass("has-error");
                $('#otherReportAudienceFieldDiv').addClass("has-error");
                invalid = true;
            } else {
                $scope.report.ReportAudience = $scope.otherReportAudience;
            }
        }
        if (!$scope.report.ReportDueDate) {
            $('#reportDueDateFieldLabel').addClass("has-error");
            $('#reportDueDateFieldDiv').addClass("has-error");
            invalid = true;
        }
        // invalid if report due date is after finding due date
        var rDueDate = new Date($scope.report.ReportDueDate);
        var currentDate = new Date();

        //     if ((rDueDate.getTime() > fDueDate.getTime()) || (rDueDate.getTime() < currentDate.getTime())) {
        if (rDueDate.getTime() < currentDate.getTime()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("Report Due Date must be a future date");
            $scope.report.ReportDueDate = "";
            $('#reportDueDateFieldLabel').addClass("has-error");
            $('#reportDueDateFieldDiv').addClass("has-error");
            invalid = true;
        }
        var assignedToUserInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.reportAssignedToDiv_TopSpan.GetAllUserInfo();
        if (assignedToUserInfo.length > 0) {
            $scope.report.ReportAssignedTo = SP.FieldUserValue.fromUser(assignedToUserInfo[0]['Description']);
        } else {
            $('#reportAssignedToFieldLabel').addClass("has-error");
            invalid = true;
        }
        return invalid;
    }

    $scope.removeAttachment = function removeAttachment(fileName) {
        $scope.removeAttachedFileName = fileName;
        $scope.showDlgBox = 'removeAttachment';
        $('#myModal').modal('show');
    }

    $scope.removeAttached = function () {
        var promiseGet = fileUploadSvr.removeAttachment('actionTrackerReports', $scope.report.ReportSPID, $scope.removeAttachedFileName);
        promiseGet.then(function () {
            var idx = $scope.AttachedFileNames.indexOf($scope.removeAttachedFileName);
            if (idx > -1) {
                $scope.AttachedFileNames.splice(idx, 1);
            }
            showAttachments();
        });
    }

    $scope.uploadAttachment = function () {
        var alreadyAttached = false;
        var fileInput = $('#attachmentsField');
        var files = fileInput[0].files;
        var fileName = files[0].name;

        for (var i = 0; i < $scope.AttachedFileNames.length; i++) {
            if ($scope.AttachedFileNames[i] == fileName) {
                alreadyAttached = true
            }
        }

        if (alreadyAttached) {
            $scope.removeAttachedFileName = fileName
            $scope.showDlgBox = 'updateAttachment';
            $('#myModal').modal('show');
        } else {
            var promiseGet = fileUploadSvr.addAttachment('attachmentsField', 'attachmentsList', 'actionTrackerReports', $scope.report.ReportSPID);
            promiseGet.then(function () {
                showAttachments();
            });
        }
        $('#attachmentsField').val("");
    }

    function showAttachments() {
        var attachmentLink = "";
        var fileIcon = "";
        var promiseGet = fileUploadSvr.listAttachment('actionTrackerReports', $scope.report.ReportSPID);
        promiseGet.then(function (attachments) {
            if (attachments.length > 0) {
                $scope.AttachedFileNames = attachments;
                $('#attachmentsList').html("");
                for (var i = 0; i < attachments.length; i++) {
                    switch (true) {
                        case (attachments[i].indexOf(".doc") != -1):
                            fileIcon = "doc.png"; break;
                        case (attachments[i].indexOf(".xls") != -1):
                            fileIcon = "xls.png"; break;
                        case (attachments[i].indexOf(".ppt") != -1):
                            fileIcon = "ppt.png"; break;
                        case (attachments[i].indexOf(".pdf") != -1):
                            fileIcon = "pdf.png"; break;
                        case (attachments[i].indexOf(".txt") != -1):
                            fileIcon = "txt.png"; break;
                        case (attachments[i].indexOf(".zip") != -1):
                            fileIcon = "zip.png"; break;
                        default:
                            fileIcon = "unknown.png"; break;
                    }
                    attachmentLink = '<span class="col-sm-3 text-center"><a href="' + hostUrl + '/Lists/actionTrackerReports/Attachments/' + $scope.report.ReportSPID + '/' + attachments[i] + '" target="_blank">' +
                        '<img src="../Images/fileIcons/' + fileIcon + '" width="75px"><br />' + attachments[i] + '</a>';
                    if ($scope.saveBtnEnabled) {
                        attachmentLink += '<br /><button class="linkButton" onclick="removeAttachment(\'' + attachments[i] + '\');">Remove</button></span>';
                    }
                    $('#attachmentsList').append(attachmentLink);
                }
            } else {
                $('#attachmentsList').html("This action has no attachments.");
            }
        }, function (err) {
            if (err != 'File Not Found.') {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error getting attachment list: " + err);
            }
        });
    }

    // send a notification email to the report assigned to user and the finding assigned to user and everyone on the notify list
    function notify(notice) {
        var sendTo = "";
        var subject = "";
        var body = "";

        var camlQString = "<View><Query><Where>"
                        + "      <Eq><FieldRef Name='FindingNumber' /><Value Type='Text'>" + $scope.report.ReportFindingNumber + "</Value></Eq>"
                        + "</Where></Query></View>";

        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            var enumerator = resp.getEnumerator();

            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                var FindingNumber = currentListItem.get_item('FindingNumber');
                var FindingAssignedTo = currentListItem.get_item('FindingAssignedTo');
                var FindingNotify = currentListItem.get_item('Notify');
            }
            var assignedToUserInfo = $scope.report.ReportAssignedTo.get_email();
            if (assignedToUserInfo.length > 0) {
                sendTo = assignedToUserInfo;
                
                if (notice == "new") {
                    subject = test + "Action Tracker: New Report for Finding " + FindingNumber;
                    body = test + "<p>A new Report has been attached to finding " + FindingNumber + ". This Report has been assigned to you.</p>" +
                        "<p>Please do not reply to this email as this address is not monitored.</p>" +
                        "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                }
                
                // notify message that a new finding has been created
                if (notice == "statusUpdate") {
                    if ($scope.report.ReportStatus == 'In Progress') {
                        subject = test + " Action Tracker: Report Assignment";
                        body = test + "<p>An Report attached to finding " + FindingNumber + " has been moved to 'In Progress' status. This Report has been assigned to you.</p>" +
                            "<b>Report Details:</b><br>" +
                            "<b> Audience:</b> " + $scope.report.ReportAudience + "<br>" +
                            "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                            "<b> Status:</b> " + $scope.report.ReportStatus + "<br>" +
                            "<p>Please do not reply to this email as this address is not monitored.</p>" +
                            "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                        //     sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                    }
                    if ($scope.action.ActionStatus == 'Complete') {
                            subject = test + " Action Tracker: Report Assignment";
                            body = test + "<p>A Report attached to finding " + FindingNumber + " has been completed. This Report was assigned to you.</p>" +
                                "<b>Report Details:</b><br>" +
                                "<b> Audience:</b> " + $scope.report.ReportAudience + "<br>" +
                                "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                                "<b> Status:</b> " + $scope.report.ReportStatus + "<br>" +
                                "<p>Please do not reply to this email as this address is not monitored.</p>" +
                                "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                            //      sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                    }
                }
                // notify message for cancelling a report
                if (notice == "cancel") {
                    subject = test + "Action Tracker: Cancelled Report for Finding " + FindingNumber;
                    body = test + "<p>A Report attached to finding " + FindingNumber + " has been removed. This report was to be sent to " +
                            "<b>Report Details:</b><br>" +
                            "<b> Audience:</b> " + $scope.report.ReportAudience + "<br>" +
                            "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                            "<b> Status:</b> " + $scope.report.ReportStatus + "<br>" +
  					        "<b>" + $scope.otherReportAudience + "</b><br>You are receiving this notification because the report was assigned to you.</p>" +
                            "<p>Please do not reply to this email as this address is not monitored.</p>" +
                            "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                }
                // sendmail(from,to,body,subject) is defined in app.js
                if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                    sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                }
                sendTo = "";
            }

            if (FindingAssignedTo) {
                if ($scope.report.ReportAssignedTo.get_lookupValue() != FindingAssignedTo.get_lookupValue()) {
                    sendTo = FindingAssignedTo.get_email();
                }
            }

            if (FindingNotify) {
                for (var i = 0; i < FindingNotify.length; i++) {
                    if (sendTo.indexOf(FindingNotify[i].get_email()) < 0) {
                        sendTo += "," + FindingNotify[i].get_email();
                    }
                }
            }
            /*
            if (notice == "new") {
                subject = test + "Action Tracker: New Report for Finding " + FindingNumber;
                body = test + "<p>A new Report has been attached to finding " + FindingNumber + ". You have been identified as a person to be notified regarding changes to this finding.</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p>" +
                    "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
            }
            */
            // notify message for status updates
            if (notice == "statusUpdate") {
                subject = test + "Action Tracker: Report Status Change - " + FindingNumber;
                body = test + "<p>Status for an Report attached to Action Tracker Finding " + FindingNumber + " has been changed to <b>" + $scope.report.ReportStatus + "</b></p>" +
                  "<p>Please do not reply to this email as this address is not monitored.</p>" +
                  "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
            }
            // notify message for cancelling a report
            if (notice == "cancel") {
                subject = test + "Action Tracker: Cancelled Report for Finding " + FindingNumber;
                body = test + "<p>An Report attached to finding " + FindingNumber + " has been removed. This report was to be sent to " +
				    "<b>" + $scope.otherReportAudience + "</b><br>You have been identified as a person to be notified regarding changes to this finding.</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p>" +
                    "<p>To view the details of this report request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
            }
            // sendmail(from,to,body,subject) is defined in app.js
            if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
            }

        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error loading this finding to prepare email notification: " + err);
        });
    }
});

