﻿/******************************************************************************
* kpiCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* performance reports page of the Action Tracking app. This page is used to 
* view reports about the Action tracker performance.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('kpi', function ($scope, crudSvr) {
 // properties
    $scope.showDlgBox = '';
    $scope.rptList = ['Findings', 'Actions', 'Reports'];
    $scope.months = ['Jan', 'feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $scope.years = [];
    var currentYear = new Date().getFullYear();
    var currentMonth = new Date().getMonth();
    for (var i = 2017; i <= currentYear+1; i++) {
        $scope.years.push("" + i);
    }

    $scope.startMonth = 0;
    $scope.startMonthName = $scope.months[$scope.startMonth];
    $scope.endMonth = currentMonth;
    $scope.endMonthName = $scope.months[$scope.endMonth];
    $scope.startYear = "" + currentYear;
    $scope.endYear = "" + currentYear;
    $scope.currentRpt = "";


    // list of finding numbers at current users site.  only findings newer than 7 years old
    $scope.findingNos = [];
    getApplicableFindingNos();

 // initialize
    // set scroll bar height
    var height = window.innerHeight;
    $('.content').css('height', height - 300 + 'px');

// methods
    $scope.findingsRpt = function findingsRpt() {
        // reset findings to accept new search result
        var findings = [];
        var parsedDueDate = '';
        var parsedOccuredDate = '';
        var parsedCloseDate = '';
        var searchResults = "";
        var assignedTo = '';

        $('#reportOutput').html("");
        $('#hiddenRptOutput').html("");

        var sitesFilter = "<In><FieldRef Name='Operation' LookupId='True' /><Values>";
        for (var i = 0; i < userGrps.length; i++) {
            sitesFilter += "<Value Type='Text'>" + userGrps[i] + "</Value>";
        }
        sitesFilter += "</Values></In>";

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='FindingNumber' Ascending='FALSE'/></OrderBy><Where>" + sitesFilter + "</Where></Query></View>";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then ( function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;

            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                if (currentListItem.get_item('DateOccured')) {
                  parsedOccuredDate = (currentListItem.get_item('DateOccured').getMonth() + 1) + '/';
                  parsedOccuredDate += currentListItem.get_item('DateOccured').getDate() + '/';
                  parsedOccuredDate += currentListItem.get_item('DateOccured').getFullYear();
                } else {
                    parsedOccuredDate = 'OPEN';
                }
                if (currentListItem.get_item('FindingCompletionDate')) {
                    parsedCloseDate = (currentListItem.get_item('FindingCompletionDate').getMonth() + 1) + '/';
                    parsedCloseDate += currentListItem.get_item('FindingCompletionDate').getDate() + '/';
                    parsedCloseDate += currentListItem.get_item('FindingCompletionDate').getFullYear();
                } else {
                    parsedCloseDate = 'OPEN';
                }
                if (currentListItem.get_item('FindingAssignedTo')) {
                    assignedTo = currentListItem.get_item('FindingAssignedTo');
                    assignedTo = assignedTo.get_lookupValue();
                } else {
                    assignedTo = 'UNASSIGNED';
                }
                if (currentListItem.get_item('FindingOriginDue')) {
                    parsedDueDate = (currentListItem.get_item('FindingOriginDue').getMonth() + 1) + '/';
                    parsedDueDate += currentListItem.get_item('FindingOriginDue').getDate() + '/';
                    parsedDueDate += currentListItem.get_item('FindingOriginDue').getFullYear();
                } else {
                    parsedDueDate = 'OPEN';
                }
                findings.push({
                    FindingNumber: currentListItem.get_item('FindingNumber'),
                    FindingStatus: currentListItem.get_item('FindingStatus'),
                    enteredDate: parsedOccuredDate,
                    dueDate: parsedDueDate,
                    FindingAssignedTo: assignedTo,
                    NonConfDescription: currentListItem.get_item('NonConfDescription'), //title
                    NonConfCause: currentListItem.get_item('NonConfCause'),  //description
                    Type: currentListItem.get_item('FindingType'),  // source
                    FindingCategory: currentListItem.get_item('FindingCategory'),  // Category
                    closeDate: parsedCloseDate
                });
            }
            // display the results
            for (var i = 0; i < findings.length; i++) {
                if (!findings[i].FindingCategory) {
                    findings[i].FindingCategory = "";
                }
              searchResults += '<tr>' +
                  '<td>' + findings[i].FindingNumber + '</td>' +
                  '<td>' + findings[i].FindingStatus + '</td>' +
                  '<td>' + findings[i].enteredDate + '</td>' +
                  '<td>' + findings[i].dueDate + '</td>' +
                  '<td>' + findings[i].FindingAssignedTo + '</td>' +
                  '<td>' + findings[i].NonConfDescription + '</td>' +
                  '<td>' + findings[i].NonConfCause + '</td>' +
                  '<td>' + findings[i].Type + '</td>' +
                  '<td>' + findings[i].FindingCategory + '</td>' +
                  '<td>' + findings[i].closeDate + '</td>' +
                  '</tr>';
                }
            $('#reportOutput').html('<h3>Action Tracker - Findings</h3>' +
                '<table id="findingsTable" class="table table-striped">' +
                    '<thead><tr>' +
                    '   <th data-sortable="true">Finding No.</th>' +
                    '   <th data-sortable="true">Status</th>' +
                    '   <th data-sortable="true">Date Occured</th>' +
                    '   <th>Info Due Date</th>' +
                    '   <th>Assigned To</th>' +
                    '   <th>Title</th>' +
                    '   <th>Description</th>' +
                    '   <th>Source</th>' +
                    '   <th>Category</th>' +
                    '   <th>Close Date</th>' +
                '</tr></thead><tbody>' + searchResults + '</tbody></table>');
            $('#findingsTable').DataTable({
                searching: true,
                pageLength: -1,
                paging: false,
                dom: 'Bfrtip',
                buttons: [
                    'excelHtml5', 'print'
                ]
            });
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting findings list: " + err);
        });
    };
    
    $scope.actionsRpt = function () {
        var actionList = [];
        var parsedDueDate = '';
        var parsedCloseDate = '';
        var searchResults = "";

        $('#reportOutput').html("");
        $('#hiddenRptOutput').html("");

        // current user's site filter
        var findingNoFilter = "<In><FieldRef Name='ActionFindingNumber' LookupId='True' /><Values>";
        for (var i = 0; i < $scope.findingNos.length; i++) {
            findingNoFilter += "<Value Type='Text'>" + $scope.findingNos[i] + "</Value>";
        }
        findingNoFilter += "</Values></In>";

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ActionFindingNumber' Ascending='FALSE'/></OrderBy><Where>" + findingNoFilter + "</Where></Query></View>";
        var promiseGet = crudSvr.get('actionTrackerActions', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                parsedDueDate = (currentListItem.get_item('ActionDueDate').getMonth() + 1) + '/';
                parsedDueDate += currentListItem.get_item('ActionDueDate').getDate() + '/';
                parsedDueDate += currentListItem.get_item('ActionDueDate').getFullYear();
                if (currentListItem.get_item('ActionCompletionDate')) {
                    parsedCloseDate = (currentListItem.get_item('ActionCompletionDate').getMonth() + 1) + '/';
                    parsedCloseDate += currentListItem.get_item('ActionCompletionDate').getDate() + '/';
                    parsedCloseDate += currentListItem.get_item('ActionCompletionDate').getFullYear();
                } else {
                    parsedCloseDate = 'OPEN';
                }
                actionList.push({
                    ActionFindingNumber: currentListItem.get_item('ActionFindingNumber'),
                    ActionShortDescription: currentListItem.get_item('ActionShortDescription'),
                    ActionDueDate: parsedDueDate,
                    ActionAssignedTo: currentListItem.get_item('ActionAssignedTo'),
                    ActionStatus: currentListItem.get_item('ActionStatus'),
                    ActionCloseDate: parsedCloseDate
                });
            }
            for (var i = 0; i < actionList.length; i++) {
                searchResults += '<tr><td>' + actionList[i].ActionFindingNumber + '</td>' +
                    '<td>' + actionList[i].ActionShortDescription + '</td>' +
                    '<td>' + actionList[i].ActionDueDate + '</td>' +
                    '<td>' + actionList[i].ActionAssignedTo.get_lookupValue() + '</td>' +
                    '<td>' + actionList[i].ActionStatus + '</td>' +
                    '<td>' + actionList[i].ActionCloseDate + '</td></tr>';
            }
            if (searchResults) {
                $('#reportOutput').html('<h3>Action Tracker - Actions</h3>' +
                    '<table id="actionsTable" class="table table-striped" data-toggle="table">' +
                    '  <thead><tr>' +
                    '    <th>Finding Number</th>' +
                    '    <th>Action Title</th>' +
                    '    <th>Due Date</th>' +
                    '    <th>Assigned To</th>' +
                    '    <th>Status</th>' +
                    '    <th>Closed Date</th>' +
                    ' </tr></thead><tbody>' + searchResults + '</tbody></table>');
                $('#actionsTable').DataTable({
                    searching: true,
                    pageLength: -1,
                    paging: false,
                    dom: 'Bfrtip',
                    buttons: [
                        'excelHtml5', 'print'
                    ]
                });
            }

        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting actions list: " + err);
        });
    };

    $scope.reportsRpt = function () {
        var reportList = [];
        var parsedDueDate = '';
        var searchResults = "";

        $('#reportOutput').html("");
        $('#hiddenRptOutput').html("");

        // current user's site filter
        var findingNoFilter = "<In><FieldRef Name='ReportFindingNumber' LookupId='True' /><Values>";
        for (var i = 0; i < $scope.findingNos.length; i++) {
            findingNoFilter += "<Value Type='Text'>" + $scope.findingNos[i] + "</Value>";
        }
        findingNoFilter += "</Values></In>";

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ReportFindingNumber' Ascending='FALSE'/></OrderBy><Where>" + findingNoFilter + "</Where></Query></View>";
        var promiseGet = crudSvr.get('actionTrackerReports', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                parsedDueDate = (currentListItem.get_item('ReportDueDate').getMonth() + 1) + '/';
                parsedDueDate += currentListItem.get_item('ReportDueDate').getDate() + '/';
                parsedDueDate += currentListItem.get_item('ReportDueDate').getFullYear();
                reportList.push({
                    ReportFindingNumber: currentListItem.get_item('ReportFindingNumber'),
                    ReportAudience: currentListItem.get_item('ReportAudience'),
                    ReportComment: currentListItem.get_item('ReportComment'),
                    ReportDueDate: parsedDueDate,
                    ReportAssignedTo: currentListItem.get_item('ReportAssignedTo'),
                    ReportStatus: currentListItem.get_item('ReportStatus')
                });
            }
            for (var i = 0; i < reportList.length; i++) {
                searchResults += '<tr><td>' + reportList[i].ReportFindingNumber + '</td>' +
                    '<td>' + reportList[i].ReportAudience + '</td>' +
                    '<td>' + reportList[i].ReportComment + '</td>' +
                    '<td>' + reportList[i].ReportDueDate + '</td>' +
                    '<td>' + reportList[i].ReportAssignedTo.get_lookupValue() + '</td>' +
                    '<td>' + reportList[i].ReportStatus + '</td></tr>';
            }
            if (searchResults) {
                $('#reportOutput').html('<h3>Action Tracker - Reports</h3>' +
                    '<table id="reportsTable" class="table table-striped" data-toggle="table">' +
                    '  <thead><tr>' +
                    '    <th>Finding Number</th>' +
                    '    <th>Audience</th>' +
                    '    <th>Comment</th>' +
                    '    <th>Due Date</th>' +
                    '    <th>Assigned To</th>' +
                    '    <th>Status</th>' +
                    ' </tr></thead><tbody>' + searchResults + '</tbody></table>');
                    $('#reportsTable').DataTable({
                        searching: true,
                        pageLength: -1,
                        paging: false,
                        dom: 'Bfrtip',
                        buttons: [
                            'excelHtml5', 'print'
                        ]
                    });
            }
            
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting actions list: " + err);
        });
    };

    $scope.updateDateRange = function updateDateRange() {
        getApplicableFindingNos()
    };

    function getApplicableFindingNos() {
        var fNos = [];

        var a = $scope.months.indexOf($scope.endMonthName);

        var startDate = $scope.startYear + "-" + ($scope.months.indexOf($scope.startMonthName) + 1) + "-1T00:00:01Z";
        var endDate = $scope.endYear + "-" + ($scope.months.indexOf($scope.endMonthName) + 1) + "-1T00:00:01Z";

        var sitesFilter = "<In><FieldRef Name='Operation' LookupId='True' /><Values>";
        for (var i = 0; i < userGrps.length; i++) {
            sitesFilter += "<Value Type='Text'>" + userGrps[i] + "</Value>";
        }
        sitesFilter += "</Values></In>";

        var dateRange = '<And><Geq><FieldRef Name="EnteredDate" />' +
            '        <Value IncludeTimeValue="TRUE" Type="DateTime">' + startDate + '</Value>' +
            '     </Geq>' +
            '     <Leq><FieldRef Name="EnteredDate" />' +
            '       <Value IncludeTimeValue="TRUE" Type="DateTime">' + endDate + '</Value>' +
            '     </Leq></And>';

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy><Where><And>";
        camlQString += sitesFilter;
        camlQString += dateRange;
        camlQString += "</And></Where></Query><ViewFields><FieldRef Name='FindingNumber' /></ViewFields></View>";
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                fNos.push(currentListItem.get_item('FindingNumber'));
            }
            $scope.findingNos = fNos;

            if ($scope.currentRpt === 'Findings') { $scope.findingsRpt(); }
            if ($scope.currentRpt === 'Actions') { $scope.actionsRpt(); }
            if ($scope.currentRpt === 'Reports') { $scope.reportsRpt(); }

        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting Finding Numbers list: " + err);
        });

    }

    $scope.runRpt = function runRpt() {
        if ($scope.currentRpt === 'Findings') { $scope.findingsRpt(); }
        if ($scope.currentRpt === 'Actions') { $scope.actionsRpt(); }
        if ($scope.currentRpt === 'Reports') { $scope.reportsRpt(); }
    };

});