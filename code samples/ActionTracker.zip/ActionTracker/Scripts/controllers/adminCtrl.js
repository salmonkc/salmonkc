﻿/******************************************************************************
* adminCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* performance reports page of the Action Tracking app. This page is used to 
* view reports about the Action tracker performance.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('admin', function ($scope, crudSvr) {
    // properties
    $scope.showDlgBox = '';
    $scope.adding = false;
    $scope.permissionLevels = ['Contribute', 'Editor', 'POM'];
    $scope.sites = ['CPP', 'HIP', 'QRP', 'SLP'];
    var users = [];
    // initialize
    // set scroll bar height
    var height = window.innerHeight;
    $('.content').css('height', height - 300 + 'px');

    load();

    // methods
    function load() {
        // reset findings to accept new search result
        
        var personObj = '';
        var personName = '';
        var searchResults = "";

        $('#userList').html("");

        var sitesFilter = "<In><FieldRef Name='SiteID' LookupId='True' /><Values>";
        for (var i = 0; i < userGrps.length; i++) {
           sitesFilter += "<Value Type='Text'>" + userGrps[i] + "</Value>";
        }
        sitesFilter += "</Values></In>";

        //build query
        var camlQString = "<View><Query>" +
            "<OrderBy><FieldRef Name='person' Ascending='TRUE'/></OrderBy>" + 
            //"<Where>" + sitesFilter + "</Where>" +
            "</Query></View > ";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerAdmin', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;

            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                if (currentListItem.get_item('person')) {
                    personObj = currentListItem.get_item('person');
                    personName = personObj.get_lookupValue();
                }

                users.push({
                    ID: currentListItem.get_item('ID'),
                    Person: personObj,
                    PersonName: personName,
                    SiteID: currentListItem.get_item('SiteID'),
                    permissionLevel: currentListItem.get_item('PermissionLevel')
                });
            }
            // display the results
            for (var i = 0; i < users.length; i++) {
                if (!users[i].SiteID) {
                    users[i].SiteID = "";
                }
                searchResults += '<tr id="user_' + users[i].ID + '">' +
                    '<td>' + users[i].PersonName + '</td>' +
                    '<td>' + users[i].SiteID + '</td>' +
                    '<td>' + users[i].permissionLevel + '</td>' +
                    '<td><button type="button" class="btn btn-link" onclick="angular.element(this).scope().editUser(' + users[i].ID + ')">update</button>' +
                    '<button type="button" class="btn btn-link" onclick="angular.element(this).scope().removeUser(' + users[i].ID + ')">remove</button></td> ' +
                    '</tr>';
            }
            $('#userList').html('<h3>Action Tracker - Users List</h3>' +
                '<table id="usersTable" class="table table-striped display">' +
                '<thead><tr>' +
                '   <th data-sortable="true">Person Name</th>' +
                '   <th data-sortable="true">Sites</th>' +
                '   <th data-sortable="true">Permission Level</th>' +
                '   <th data-sortable="true"></th>' +
                '</tr></thead><tbody>' + searchResults + '</tbody></table>');
            $('#usersTable').DataTable({
                "iDisplayLength": 15,
                "searching": false,
                "lengthChange": false,
                "ordering": false
            });

            initializePeoplePicker('personFieldDiv', false);

        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting findings list: " + err);
        });
    };

    function updateView(action, userID) {
        var userIndex = users.map(function (e) { return e.ID; }).indexOf(parseInt(userID));
        if (action == 'update') {
            $('#user_' + users[userIndex].ID).html('<td>' + users[userIndex].PersonName + '</td>' +
                '<td>' + users[userIndex].SiteID + '</td>' +
                '<td>' + users[userIndex].permissionLevel + '</td>' +
                '<td><button type="button" class="btn btn-link" onclick="angular.element(this).scope().editUser(' + users[userIndex].ID + ')">update</button>' +
                '<button type="button" class="btn btn-link" onclick="angular.element(this).scope().removeUser(' + users[userIndex].ID + ')">remove</button></td > ');
        }
        if (action == 'remove') { 
            // remove table row
            var y = $('#user_' + users[userIndex].ID).remove();
            $('#user_' + users[userIndex].ID).remove();
            //remove from array
            users.splice(userIndex, 1);
        }
        if (action == 'adding') {
            users = []; //reset users array
            $('#userList').html(""); //clear users table
            load();  // reload users table with new user
        }
    }

    $scope.close = function close() {
        $scope.showDlgBox = "";
        $('#saved').addClass("ng-hide");
        $('#canceled').addClass("ng-hide");
        $('#error').addClass("ng-hide");
        $('#deleteUser').addClass("ng-hide");
        $('#addUpdateAdmin').addClass("ng-hide");
    }

    $scope.removeUser = function removeUser(userID) {
        $("#myModal").modal("toggle");
        $('#idField_remove').val(userID);
        $scope.showDlgBox = "deleteUser";
        $('#deleteUser').removeClass("ng-hide");
    }

    $scope.deleteUser = function deleteUser() {
        var userID = $('#idField_remove').val();
        var promiseGet = crudSvr.remove('actionTrackerAdmin', userID);
        promiseGet.then(function () {
            updateView('remove', userID)
            // inform user of successful update
        //    $('#deleteUser').addClass("ng-hide");
            $scope.showDlgBox = "canceled";
            $("#canceledDlgContent").html('These permission levels have been removed for this  person');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error cancelling this action: " + err);
        });
        
    }

    $scope.editUser = function editUser(userID) {
        $("#myModal").modal("toggle");
        $scope.showDlgBox = "userChange";
        $('#addUpdateAdmin').removeClass("ng-hide");
        $('#addBtn').hide();
        $('#updateBtn').show();
        var userIndex = users.map(function (e) { return e.ID; }).indexOf(userID);
        $('#userDiv').hide();
        $('#personName').show();
        $('#idField').val(users[userIndex].ID);
        $('#personName').html('<sapn class="personName">' + users[userIndex].PersonName + '</span>');
        $('#permissionLevelField').val(users[userIndex].permissionLevel);
        $('#siteIDField').val(users[userIndex].SiteID);
    }

    $scope.clearForm = function clearForm() {
        clearFields();
    };

    function clearFields() {
        var userPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict.personFieldDiv_TopSpan;
        userPeoplePicker.DeleteProcessedUser();
        $('#personName').html('');
        $('#permissionLevelField').val("");
        $('#siteIDField').val("");
    }

    $scope.updateUser = function updateUser() {
        // call sharepoint for data through crudSvr
        var promiseUpdate = "";
        var userID = $('#idField').val();
        var userIndex = users.map(function (e) { return e.ID; }).indexOf(parseInt(userID));

        if (($('#permissionLevelField').val() == null) || ($('#siteIDField').val() == null)) {
           alert('Please make sure to add a value for both site and permission level.');
        } else {
            users[userIndex].permissionLevel = $('#permissionLevelField').val();
            users[userIndex].SiteID = $('#siteIDField').val();
            promiseUpdate = crudSvr.update('actionTrackerAdmin', users[userIndex], users[userIndex].ID);
            promiseUpdate.then(function (resp) {
                clearFields();
                updateView('update', userID)
                // inform user of successful update
                $("#myModal").modal("toggle");
                $scope.showDlgBox = "saved";
                $("#savedDlgContent").html('This person\'s permission level was succesfully saved');
                $('#saved').removeClass("ng-hide");
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error updating this action: " + err);
            });
        }
    }

    $scope.setupAdd = function setupAdd() {
        $('#userDiv').show();
        $('#personName').hide();
        $('#addBtn').show();
        $('#updateBtn').hide();
    }

    $scope.addUser = function addUser() {
        var promiseAdd = "";
        var newUser = { ID: "", Person: "", PersonName: "", SiteID: "", permissionLevel: "" };
        var UserInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.personFieldDiv_TopSpan.GetAllUserInfo();
        if (($('#permissionLevelField').val() == null) || ($('#siteIDField').val() == null) || (UserInfo[0] == null)) {
            alert('Please make sure to add a value to person, site and permission level.');
        } else {
            newUser.Person = SP.FieldUserValue.fromUser(UserInfo[0]['Description']);
            newUser.permissionLevel = $('#permissionLevelField').val();
            newUser.SiteID = $('#siteIDField').val();
            promiseAdd = crudSvr.add('actionTrackerAdmin', newUser);
            promiseAdd.then(function (resp) {
                updateView('adding');
                clearFields();
                // inform user of successful update
                $("#myModal").modal("toggle");
                $scope.showDlgBox = "saved";
                $("#savedDlgContent").html('This person\'s permission level was succesfully saved');
                $('#saved').removeClass("ng-hide");
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error updating this action: " + err);
            });
        }
    }

    // Render and initialize the client-side People Picker.
    function initializePeoplePicker(peoplePickerElementId, allowMultiple) {
        // Create a schema to store picker properties, and set the properties.
        var schema = {};
        var width = '73%';
        schema['PrincipalAccountType'] = 'User,DL,SecGroup,SPGroup';
        schema['SearchPrincipalSource'] = 15;
        schema['ResolvePrincipalSource'] = 15;
        schema['AllowMultipleValues'] = allowMultiple;
        schema['MaximumEntitySuggestions'] = 50;

        // Render and initialize the picker. 
        //   Pass the ID of the DOM element that contains the picker, an array of initial
        //     PickerEntity objects to set the picker value, and a schema that defines
        //     picker properties.
        SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);
        $('#' + peoplePickerElementId + '_TopSpan').width(width);
    }

});