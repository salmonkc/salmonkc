﻿/******************************************************************************
* searchCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* search page of the The Action Tracking app.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('search', function ($scope, $location, crudSvr) {
    
    // properties
    $scope.searchCriteria = {
        FindingNumber: null,
        findingStatus: 'All',
        findingCategory: 'All',
        originator: '',
        enteredDate: '',
        FindingStatus: '',
        FindingAssignedTo: "",
        NonConfDescription: ""
    };
    $scope.showDlgBox = false;
    $scope.dlgBoxName = "";
    $scope.dlgContent = '';
    $scope.findings = [];
    $scope.statuses = ['All', 'New', 'In Progress', 'Waiting Approval', 'Complete', 'Verified'];
    // category selection options
    $scope.categories = ['All', 'Environment', 'FSC Audit', 'ISO Audit', 'Quality', 'Railway Audit', 'Safety', 'WF Corporate Audit'];

    // initialize
    if (userGrps[0] !== 'noSite') {
        load();
    }

    $scope.searchBtn = function searchBtn() {
        load();
    };

    // set scroll bar height
    var height = window.innerHeight;
    $('.content').css('height', height - 300 + 'px');

    // methods
    //Function to load all categories
    $scope.search = function search() {
        loadGeneralResults();
    };

    function load() {
        var actionList = [];
        var searchResults = "";
        var parsedDate = '';
        $('#myActionsResult').html = '';

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy><Where>" +
            "<And><Eq><FieldRef Name='ActionAssignedTo' LookupId='TRUE'/><Value Type='Integer'>" + currentUser.get_id() + "</Value></Eq>" +
            "<Neq><FieldRef Name='ActionStatus' /><Value Type='Text'>Complete</Value></Neq></And>" +
            "</Where></Query></View>";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerActions', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('ActionDueDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('ActionDueDate').getDate() + '/';
                parsedDate += currentListItem.get_item('ActionDueDate').getFullYear();
                actionList.push({
                    ActionSPID: currentListItem.get_item('ID'),
                    ActionFindingNumber: currentListItem.get_item('ActionFindingNumber'),
                    ActionType: currentListItem.get_item('ActionType'),
                    ActionApproved: currentListItem.get_item('ActionApproved'),
                    ActionShortDescription: currentListItem.get_item('ActionShortDescription'),
                    ActionAssignedTo: currentListItem.get_item('ActionAssignedTo'),
                    ActionDueDate: parsedDate,
                    ActionStatus: currentListItem.get_item('ActionStatus')
                });
            }
            // search returns 0 records  
            if (actionList.length === 0) {
                $('#myActionsResult').html('<hr><h3>There are currently no actions assigned to you</h3>');
            } else {
                for (var i = 0; i < actionList.length; i++) {
                    searchResults += '<tr><td><a href="#/action?AId=' + actionList[i].ActionSPID +
                                                              '&FId=' + actionList[i].ActionFindingNumber +
                                                              '&IEditor=true&dueDate=' + new Date("Jan 1, 2000") + '">' + actionList[i].ActionShortDescription + '</td>' +
                                             '<td>' + actionList[i].ActionFindingNumber + '</td>' +
                                             '<td>' + actionList[i].ActionAssignedTo.get_lookupValue() + '</td>' +
                                             '<td>' + actionList[i].ActionDueDate + '</td>' +
                                             '<td>' + actionList[i].ActionStatus + '</td></tr>';
                }
                if (searchResults) {
                    $('#myActionsResult').html('<table id="actionTable" class="table table-striped" data-toggle="table">' +
                                                '<thead><tr>' +
                                                '   <th data-sortable="true">Action Title</th>' +
                                                '   <th data-sortable="true">Finding No.</th>' +
                                                '   <th data-sortable="true">Assigned To</th>' +
                                                '   <th data-sortable="true">Due Date</th>' +
                                                '   <th data-sortable="true">Status</th>' +
                                                '</tr></thead><tbody>' + searchResults + '</tbody></table>');
                    $('#actionTable').DataTable({
                        "iDisplayLength": 10,
                        "searching": false
                    });
                }
            }
            loadMyReports();
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting actions list: " + err);
        });
    }

    function loadMyReports() {
        var reportList = [];
        var searchResults = "";
        var parsedDate = '';
        $('#reportsTable').html = '';

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy><Where>" +
            "<And><Eq><FieldRef Name='ReportAssignedTo' LookupId='TRUE'/><Value Type='Integer'>" + currentUser.get_id() + "</Value></Eq>" +
            "<Neq><FieldRef Name='ReportStatus' /><Value Type='Text'>Complete</Value></Neq></And>" +
            "</Where></Query></View>";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerReports', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('ReportDueDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('ReportDueDate').getDate() + '/';
                parsedDate += currentListItem.get_item('ReportDueDate').getFullYear();
                reportList.push({
                    ReportSPID: currentListItem.get_item('ID'),
                    ReportFindingNumber: currentListItem.get_item('ReportFindingNumber'),
                    ReportAudience: currentListItem.get_item('ReportAudience'),
                    ReportStatus: currentListItem.get_item('ReportStatus'),
                    ReportDueDate: parsedDate,
                    ReportAssignedTo: currentListItem.get_item('ReportAssignedTo')
                });
            }
            // search returns 0 records  
            if (reportList.length === 0) {
                $('#myReportsResult').html('<hr><h3>There are currently no reports assigned to you</h3>');
            } else {
                for (var i = 0; i < reportList.length; i++) {
                    searchResults += '<tr><td><a href="#/report?RId=' + reportList[i].ReportSPID +
                                                              '&FId=' + reportList[i].ReportFindingNumber +
                                                              '&IEditor=true&dueDate=' + new Date("Jan 1, 2000") + '">' + reportList[i].ReportAudience + '</td>' +
                                                 '<td>' + reportList[i].ReportFindingNumber + '</td>' +
                                                 '<td>' + reportList[i].ReportAssignedTo.get_lookupValue() + '</td>' +
                                                 '<td>' + reportList[i].ReportDueDate + '</td>' +
                                                 '<td>' + reportList[i].ReportStatus + '</td></tr>';
                }
                if (searchResults) {
                    $('#myReportsResult').html('<hr><table id="reportsTable" class="table table-striped" data-toggle="table">' +
                                                '<thead><tr>' +
                                                '   <th data-sortable="true">Report Audience</th>' +
                                                '   <th data-sortable="true">Finding No.</th>' +
                                                '   <th data-sortable="true">Assigned To</th>' +
                                                '   <th data-sortable="true">Due Date</th>' +
                                                '   <th data-sortable="true">Status</th>' +
                                                '</tr></thead><tbody>' + searchResults + '</tbody></table>');
                    $('#reportsTable').DataTable({
                        "iDisplayLength": 10,
                        "searching": false
                    });
                }
            }
            loadMyFindings();
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting reports list: " + err);
        });
    }

    function loadMyFindings() {
        // reset findings to accept new search result
        $scope.findings = [];
        var searchResults = "";

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy><Where>" + 
            "<And><Eq><FieldRef Name='FindingAssignedTo' LookupId='TRUE'/><Value Type='Integer'>" + currentUser.get_id() + "</Value></Eq>" +
            "<Neq><FieldRef Name='FindingStatus' /><Value Type='Text'>Verified</Value></Neq></And>" + 
            "</Where></Query></View>";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var parsedDate = '';
            var desc = "";
            var assignedToName = "";
            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('EnteredDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('EnteredDate').getDate() + '/';
                parsedDate += currentListItem.get_item('EnteredDate').getFullYear();
                $scope.findings.push({
                    FindingNumber: currentListItem.get_item('FindingNumber'),
                    findingStatus: currentListItem.get_item('FindingStatus'),
                    originator: currentListItem.get_item('Originator'),
                    enteredDate: parsedDate,
                    FindingAssignedTo: currentListItem.get_item('FindingAssignedTo'),
                    NonConfDescription: currentListItem.get_item('NonConfDescription')
                });
            }
            // search returns 0 records  
            if ($scope.findings.length === 0) {
                $('#myFindingsResult').html('<hr><h3>There are currently no findings assigned to you</h3>');
            } else {
                // display the results
                for (var i = 0; i < $scope.findings.length; i++) {
                    if ($scope.findings[i].NonConfDescription) {
                        desc = $scope.findings[i].NonConfDescription;
                    }
                    if ($scope.findings[i].FindingAssignedTo) {
                        assignedToName = $scope.findings[i].FindingAssignedTo.get_lookupValue();
                    }
                    searchResults += '<tr>' +
                                             '<td><a href="#/finding?INo=' + $scope.findings[i].FindingNumber + '">' + $scope.findings[i].FindingNumber + '</a></td>' +
                                             '<td>' + desc + '</td>' +
                                             '<td>' + $scope.findings[i].findingStatus + '</td>' +
                                             '<td>' + assignedToName + '</td>' +
                                             '<td>' + $scope.findings[i].enteredDate + '</td>' +
                                        '</tr>';
                    desc = "";
                    assignedToName = "";
                }
                $('#myFindingsResult').html('<hr><table id="myFindingsResultTable" class="table table-striped">' +
                                             '<thead><tr>' +
                                             '   <th data-sortable="true">Finding No.</th>' +
                                             '   <th data-sortable="true">Description</th>' +
                                             '   <th data-sortable="true">Status</th>' +
                                             '   <th data-sortable="true">Assigned To</th>' +
                                             '   <th>Entered Date</th>' +
                                             '</tr></thead><tbody>' + searchResults + '</tbody></table>');
                $('#myFindingsResultTable').DataTable({
                    "searching": false,
                    "order": [[0, "desc"]]
                });
            }
            loadGeneralResults();
        }, function (err) {
            $scope.showDlgBox = "error";
            $scope.dlgContent = "An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.";
            console.log("Error getting findings list: " + err);
        });
    }

    function loadGeneralResults() {
        // reset findings to accept new search result
        $scope.findings = []; 
        var searchResults = "";

        // set up query
        var queryConditions = []; // add filters to caml query
        
        // current user's site filter
        var sitesFilter = "<In><FieldRef Name='Operation' LookupId='True' /><Values>";
        for (var i=0; i<userGrps.length; i++) {
            sitesFilter += "<Value Type='Text'>" + userGrps[i] + "</Value>";
        }
        sitesFilter += "</Values></In>";
        queryConditions.push(sitesFilter);
        //filter for finding number (or group of numbers)
        if ($scope.searchCriteria.FindingNumber) {
            var IncNo = '';
            for (i = 0; i <= $scope.searchCriteria.FindingNumber.length; i++) {
                if (!isNaN($scope.searchCriteria.FindingNumber.charAt(i))) {
                    IncNo += $scope.searchCriteria.FindingNumber.charAt(i);
                }
            }
            queryConditions.push("<Contains><FieldRef Name='FindingNumber' /><Value Type='Text'>" + IncNo + "</Value></Contains>");
        }
        if ($scope.searchCriteria.findingStatus !== 'All') {
            queryConditions.push("<Eq><FieldRef Name='FindingStatus' /><Value Type='Text'>" + $scope.searchCriteria.findingStatus + "</Value></Eq>");
        }
        if ($scope.searchCriteria.findingCategory !== 'All') {
            queryConditions.push("<Contains><FieldRef Name='FindingCategory' /><Value Type='Text'>" + $scope.searchCriteria.findingCategory + "</Value></Contains>");
        }
        if ($scope.searchCriteria.Originator) {
            queryConditions.push("<Contains><FieldRef Name='Originator' /><Value Type='Text'>" + $scope.searchCriteria.Originator + "</Value></Contains>");
        }
        if (!POMUser) {
            queryConditions.push("<Neq><FieldRef Name='Multisite' /><Value Type='Boolean'>1</Value></Value></Neq>");
        }
        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy><Where>";
        
        // add filters
        if (queryConditions.length === 1) {
            camlQString += queryConditions[0];
        } else {
            for (var j = 0; j < queryConditions.length-1; j++) {
                camlQString += "<And>" + queryConditions[j];
            }
            camlQString += queryConditions[j] + "</And>";
            for (j = 0; j < queryConditions.length-2; j++) {
                camlQString += "</And>";
            }
        }
        camlQString += "</Where></Query></View>";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var parsedDate = '';
            var desc = "";
            var assignedToName = "";
            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('EnteredDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('EnteredDate').getDate() + '/';
                parsedDate += currentListItem.get_item('EnteredDate').getFullYear();
                $scope.findings.push({
                    FindingNumber: currentListItem.get_item('FindingNumber'),
                    findingStatus: currentListItem.get_item('FindingStatus'),
                    originator: currentListItem.get_item('Originator'),
                    enteredDate: parsedDate,
                    FindingAssignedTo: currentListItem.get_item('FindingAssignedTo'),
                    NonConfDescription: currentListItem.get_item('NonConfDescription')
                });
            }
            // search returns 0 records  
            if ($scope.findings.length === 0) {
                $scope.showDlgBox = "none";
                $scope.dlgContent = "Your search has returnd zero findings. Please change your search criteria and try again.";
            }
            if ($scope.findings.length > 300) {
                $scope.showDlgBox = "tooMany";
                $scope.dlgContent = "Your search has returnd over 300 findings. Please filter your search and try again.";
            } else {
                // display the results
                for (var i = 0; i < $scope.findings.length; i++) {
                    if ($scope.findings[i].NonConfDescription) {
                        desc = $scope.findings[i].NonConfDescription;
                    } 
                    if ($scope.findings[i].FindingAssignedTo) {
                        assignedToName = $scope.findings[i].FindingAssignedTo.get_lookupValue();
                    }
                    searchResults += '<tr>' +
                                             '<td><a href="#/finding?INo=' + $scope.findings[i].FindingNumber + '">' + $scope.findings[i].FindingNumber + '</a></td>' +
                                             '<td>' + desc + '</td>' +
                                             '<td>' + $scope.findings[i].findingStatus + '</td>' +
                                             '<td>' + assignedToName + '</td>' +
                                             '<td>' + $scope.findings[i].enteredDate + '</td>' +
                                        '</tr>';
                    desc = "";
                    assignedToName = "";
                }
                $('#generalResult').html('<table id="generalResultTable" class="table table-striped">' +
                                             '<thead><tr>' +
                                             '   <th data-sortable="true">Finding No.</th>' +
                                             '   <th data-sortable="true">Description</th>' +
                                             '   <th data-sortable="true">Status</th>' +
                                             '   <th data-sortable="true">Assigned To</th>' +
                                             '   <th>Entered Date</th>' +
                                             '</tr></thead><tbody>' + searchResults + '</tbody></table>');
                $('#generalResultTable').DataTable({
                    "searching": false,
                    "order": [[0, "desc"]]
                });
            }
        }, function (err) {
            $scope.showDlgBox = "error";
            $scope.dlgContent = "An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.";
            console.log("Error getting findings list: " + err);
        });
    };

    //  close dlgbox
    $scope.close = function close() {
        $scope.showDlgBox = '';
    };
});