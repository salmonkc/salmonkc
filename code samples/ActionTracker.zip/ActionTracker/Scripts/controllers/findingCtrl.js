﻿/******************************************************************************
* findingCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* finding page of the Action Tracking app. This page is used to enter new or 
* edit the details of an finding.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('finding', function ($scope, $location, crudSvr, fileUploadSvr) {

    // properties
    $scope.finding = {
        SPID: null,
        FindingNumber: 0,
        EnteredDate: "", // this is the date the form began to be filled
        FindingStatus: "",
        FindingCategory: "",
        FindingType: "",  // aligns with the source field on the finding form
        Operation: "",   // aligns with the site field on the finding form
        FindingDept: "",
        Originator: "",
        FindingAssignedTo: "",
        Notify: "",
        FindingOriginDue: "",   // this is the date the form must be completly filled and ready to route
        ReportTo: "",
        NonConfDescription: "",  //title
        NonConfCause: "",
        RelatedNonConf: "",
        NonConfInvestigation: "",
        ResultsApprover: "",
        FindingCompleteDue: "",  // this is the date the finding is due to be completed
        FindingCompletionDate: "",  // this is the date the finding actually was completed
        CompletionRemarks: "",
        Significance: "",
        DateOccured: "",   // this is the date the insident occured
        Multisite: ""
    };

    $scope.showDlgBox = "";
    $scope.addRelated = '';
    var arr = [];
    $scope.saveBtnEnabled = false;
    $scope.verifyBtnEnabled = false;
    $scope.canApprove = false;
    $scope.canComplete = false;
    // category selection options
    $scope.categories = ['Environment', 'FSC Audit', 'ISO Audit', 'PEIMS', 'Quality', 'Railway Audit', 'Safety', 'WF Corporate Audit'];  //Source field
    // type selection options
    $scope.types = ['Customer Complaint', 'Discharge/Spill', 'Equipment Malfunction', 'External Audit', 'Inspection', 'Internal Audit', 'Internal Observation', 'Internal Quality Event',
        'Vendor Compliance', 'Personal Observation', 'Process Data', 'Product Testing', 'Public Complaint', 'Register Audit', 'Service Report',]; //Category
    // FindingDept selection options
    $scope.departments = ['Accounting', 'Admin', 'Electrical & Instrumentation', 'Engineering', 'Information Systems', 'Mechanical Maintenance', 'Mill General', 'Production',
        'Purchasing Stores', 'Sales', 'Technical', 'Training', 'Warehouse & Transportation'];
    // significance selection options
    $scope.significanceLevels = ['Minor Non-Conformance', 'Major Non-Conformance', 'Opportunity for Improvement'];
    // operation selection options
    $scope.operations = userGrps;
    // status selection options
    $scope.statuses = ['New', 'In Progress', 'Waiting Approval', 'Complete', 'Verified'];
    $scope.fileToUpload = null;
    $scope.readOnly = false;
    $scope.newStatus = false;
    $scope.AttachedFileNames = []
    $scope.removeAttachedFileName = "";
    $scope.updateAttachedFileName = "";
    $scope.relatedFindingNumber = null;
    $scope.relatedFindingCategory = '';
    $scope.AssociatedActionCount = 0;
    $scope.AssociatedReportCount = 0;
    $scope.canSeeCompRemarks = false;

    // initialize
    // set scroll bar height
    var height = window.innerHeight;
    $('.content').css('height', height - 420 + 'px');
    // load the finding into form
    load();

    // methods
    //Load an Finding
    function load() {
        var compDate = null;
        var findingNum = $location.search().INo;

        // set up datepickers
        $("#findingOriginDueField").datepicker({
            autoclose: true,
            dateFormat: 'm/d/yyyy'
        });
        $("#dateOccuredField").datepicker({
            autoclose: true,
            dateFormat: 'm/d/yyyy'
        });

        // set up peoplepickers
        initializePeoplePicker('assignedToDiv', false);
        initializePeoplePicker('notifyDiv', true);

        if (findingNum == null) {
            $("#errorDlgContent").html('There was a missing URL parameter: Finding Number');
            $scope.showDlgBox = "error";
            return;
        } else {
            var camlQString = "<View><Query><Where>"
                + "      <Eq><FieldRef Name='FindingNumber' /><Value Type='Text'>" + findingNum + "</Value></Eq>"
                + "</Where></Query></View>";
        }
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            var enumerator = resp.getEnumerator();

            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                $scope.finding.SPID = currentListItem.get_item('ID');
                $scope.finding.FindingNumber = currentListItem.get_item('FindingNumber');
                $scope.finding.EnteredDate = currentListItem.get_item('EnteredDate');
                $scope.finding.FindingStatus = currentListItem.get_item('FindingStatus');
                if (currentListItem.get_item('FindingCategory')) {
                    $scope.finding.FindingCategory = currentListItem.get_item('FindingCategory').split(",");
                }
                $scope.finding.FindingType = currentListItem.get_item('FindingType');
                $scope.finding.Operation = currentListItem.get_item('Operation');
                $scope.finding.FindingDept = currentListItem.get_item('FindingDept');
                $scope.finding.Originator = currentListItem.get_item('Originator');
                $scope.finding.FindingAssignedTo = currentListItem.get_item('FindingAssignedTo');
                $scope.finding.Notify = currentListItem.get_item('Notify');
                $('#findingOriginDueField').datepicker('setDate', currentListItem.get_item('FindingOriginDue'));
                $scope.finding.ReportTo = currentListItem.get_item('ReportTo');
                $scope.finding.NonConfDescription = currentListItem.get_item('NonConfDescription');
                $scope.finding.NonConfCause = currentListItem.get_item('NonConfCause');
                $scope.finding.RelatedNonConf = currentListItem.get_item('SimilarNonConf');
                $scope.finding.NonConfInvestigation = currentListItem.get_item('NonConfInvestigation');
                $scope.finding.ResultsApprover = currentListItem.get_item('ResultsApprover');
                if (currentListItem.get_item('FindingCompleteDue')) {
                    compDate = currentListItem.get_item('FindingCompleteDue');
                } else {
                    compDate = new Date();
                    compDate.setDate(compDate.getDate() + 45);
                }
                if (compDate) {
                    $scope.finding.FindingCompleteDue = (compDate.getMonth() + 1) + "/" + compDate.getDate() + "/" + compDate.getFullYear();
                }
                compDate = currentListItem.get_item('FindingCompletionDate');
                if (compDate) {
                    $scope.finding.FindingCompletionDate = (compDate.getMonth() + 1) + "/" + compDate.getDate() + "/" + compDate.getFullYear();
                }
                $scope.finding.Significance = currentListItem.get_item('Significance');
                $('#dateOccuredField').datepicker('setDate', currentListItem.get_item('DateOccured'));
                $scope.finding.CompletionRemarks = currentListItem.get_item('CompletionRemarks');
                $scope.finding.Multisite = (currentListItem.get_item("Multisite") == true);
            }
            // populate related findings table
            if ($scope.finding.RelatedNonConf) {
                relatedFindings();
            } else {
                $scope.finding.RelatedNonConf = "";
            }

            // list all associated action and report records
            if ($scope.finding.FindingStatus != "New") {
                actions();
                reports();
                showAttachments();
            }
            // populate AssignedTo field
            if ($scope.finding.FindingAssignedTo) {
                var assignedToPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict.assignedToDiv_TopSpan;
                var assignedTo = $scope.finding.FindingAssignedTo;
                var assignedToObj = { 'Key': assignedTo.get_email() };
                assignedToPeoplePicker.AddUnresolvedUser(assignedToObj, true);
                var assignedToEmail = assignedTo.get_email();
            }
            // populate notify field
            if ($scope.finding.Notify) {
                var notifyPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict.notifyDiv_TopSpan;
                var toBeNotified = $scope.finding.Notify;
                if (toBeNotified && toBeNotified.length > 0) {
                    // add all selected users
                    for (var i = 0; i < toBeNotified.length; i++) {
                        var notifyObj = { 'Key': toBeNotified[i].get_email() };
                        notifyPeoplePicker.AddUnresolvedUser(notifyObj, true);
                    }
                }
            }

            $scope.canCancel = (($scope.finding.FindingStatus == 'New') && (permissionLevel != 'Viewer'));

            // only assign to and originator can make changes when finding is new
            if (permissionLevel === 'Viewer') {
                $scope.saveBtnEnabled = false;
            }
            if (($scope.finding.FindingStatus != 'New') && (permissionLevel != 'Editor')) {
                $scope.saveBtnEnabled = false;
            }
            if ((assignedToEmail == currentUser.get_email()) || ($scope.finding.Originator == currentUser.get_title())) {
                $scope.saveBtnEnabled = true;
            }
            // if this finding is complete then remove save button
            if ($scope.finding.FindingStatus == 'Complete') {
                $scope.saveBtnEnabled = false;
                $scope.readOnly = true;
            }

            if (($scope.finding.Multisite) && (POMUser)) {
                $scope.saveBtnEnabled = true;
            }

            if ($scope.saveBtnEnabled) {
                // if this finding is Waiting Approval then show Approve button
                if ($scope.finding.FindingStatus == 'Waiting Approval') {
                    $scope.canApprove = true;
                }
                // if this finding is In Progress then show Complete button
                if ($scope.finding.FindingStatus == 'In Progress') { // && (permissionLevel === 'Editor')) {
                    $scope.canComplete = true;
                    $scope.saveBtnEnabled = false;
                }
            }


            // if this finding is In Progress then show Complete button
            if (($scope.finding.FindingStatus == 'Complete') && (POMUser)) {
                $scope.canComplete = false;
                $scope.saveBtnEnabled = false;
                $scope.verifyBtnEnabled = true;
                $scope.canSeeCompRemarks = true;
            }

            if ($scope.finding.FindingStatus === 'Verified') {
                $scope.canSeeCompRemarks = true;
                $scope.canApprove = false;
                $scope.verifyBtnEnabled = false;
                $scope.canComplete = false;
                $scope.saveBtnEnabled = false;
            }

            if (($scope.finding.FindingStatus == 'In Progress') ||
                ($scope.finding.FindingStatus == 'Complete') ||
                ($scope.finding.FindingStatus === 'Verified')) {
                $scope.readOnly = true;
            }

        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error loading this finding: " + err);
        });
    }

    //  Update existing finding
    $scope.save = function save() {
        if (invalid()) {
            if ($scope.showDlgBox != "error") {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html('This Finding is missing required information. Please correct and resubmit');
            }
            return;
        }
        // update status to waiting Approval for the first time an finding is saved
        // then flag that the status has been chenged
        if ($scope.finding.FindingStatus == "New") {
            $scope.finding.FindingStatus = "Waiting Approval";
            $scope.newStatus = true;
        }
        update();
    }

    $scope.complete = function complete() {
        var camlQString = "";
        // check that the required fields have values
        if (invalid()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Finding is missing required information. Please correct and resubmit');
            return;
        }

        // check that all actions and reports associated with the finding are complete
        //       if they are not do not allow the status to change

        // check actions for incomplete
        camlQString = "<View><Query><Where>"
            + "  <And><Eq><FieldRef Name='ActionFindingNumber' /><Value Type='Text'>" + $scope.finding.FindingNumber + "</Value></Eq>"
            + "       <Neq><FieldRef Name='ActionStatus' /><Value Type='Text'>Complete</Value></Neq></And>"
            + "</Where></Query></View>";
        var actionPromiseGet = crudSvr.get('actionTrackerActions', camlQString);
        actionPromiseGet.then(function (actionResp) {
            var actionEnumerator = actionResp.getEnumerator();
            if (actionEnumerator.$2I_0 > 0) { // $2I_0 is an SP List property that hold the number of items in the enumerator
                // inform user that the finding can't be complete with incomplete actions
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html('This Finding cannot be completed because there are incomplete Actions attached to it. Please correct and resubmit');
                return;
            }
            // check reports for incomplete
            camlQString = "<View><Query><Where>"
                + "  <And><Eq><FieldRef Name='ReportFindingNumber' /><Value Type='Text'>" + $scope.finding.FindingNumber + "</Value></Eq>"
                + "       <Neq><FieldRef Name='ReportStatus' /><Value Type='Text'>Complete</Value></Neq></And>"
                + "</Where></Query></View>";

            var reportPromiseGet = crudSvr.get('actionTrackerReports', camlQString);
            reportPromiseGet.then(function (reportResp) {
                var reportEnumerator = reportResp.getEnumerator();
                if (reportEnumerator.$2I_0 > 0) { // $2I_0 is an SP List property that hold the number of items in the enumerator
                    // inform user that the finding can't be complete with incomplete actions
                    $scope.showDlgBox = "error";
                    $("#errorDlgContent").html('This Finding cannot be completed because there are incomplete Reports attached to it. Please correct and resubmit');
                    return;
                }
                $scope.finding.FindingStatus = 'Complete';
                $scope.newStatus = true;
                update();
                if (POMUser) {
                    $scope.verifyBtnEnabled = true;
                    $scope.canSeeCompRemarks = true;
                }
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error checking attached report statuses: " + err);
            });
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error checking attached action statuses: " + err);
        });
    }

    $scope.approve = function approve() {
        if (invalid()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Finding is missing required information. Please correct and resubmit');
            return;
        }
        $scope.showDlgBox = "";
        if (($scope.AssociatedActionCount + $scope.AssociatedReportCount) > 0) {
            // update status to In Progress then flag that the status has been changed
            $scope.finding.FindingStatus = 'In Progress';
            $scope.readOnly = true;
            $scope.newStatus = true;
            update();
            actions();
            reports();
        } else {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Finding must have at least one action OR one report associated with it. Please add an action or report and resubmit');
            return;
        }
    }

    $scope.verify = function verify() {
        $('#completionRemarksFieldLabel').removeClass("has-error");
        $('#completionRemarksFieldDiv').removeClass("has-error");

        if (!$scope.finding.CompletionRemarks) {
            $('#completionRemarksFieldLabel').addClass("has-error");
            $('#completionRemarksFieldDiv').addClass("has-error");
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('Verification requires Completion Remarks. Please correct and resubmit');
            return;
        }
        var promiseGet = crudSvr.verify($scope.finding.SPID);
        promiseGet.then(function () {
            // inform user of successful update
            $scope.showDlgBox = "saved";
            $("#savedDlgContent").html('Finding ' + $scope.finding.FindingNumber + ' has been verified');
            $scope.verifyBtnEnabled = false;
            $scope.canSeeCompRemarks = true;
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error updating this finding: " + err);
        });
    }

    function invalid() {
        var invalid = false;
        // reset fields
        $('div').removeClass("has-error");
        $('label').removeClass("has-error");

        if (!$scope.finding.FindingDept) {
            $('#findingDeptFieldLabel').addClass("has-error");
            $('#findingDeptFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.finding.Originator) {
            $('#findingOriginatorFieldLabel').addClass("has-error");
            $('#findingOriginatorFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.finding.FindingType) {
            $('#findingTypeFieldLabel').addClass("has-error");
            $('#findingTypeFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.finding.FindingOriginDue) {
            $('#findingOriginDueFieldLabel').addClass("has-error");
            $('#findingOriginDueFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.finding.NonConfDescription) {
            $('#nonConfDescriptionFieldLabel').addClass("has-error");
            $('#nonConfDescriptionFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.finding.NonConfCause) {
            $('#nonConfCauseFieldLabel').addClass("has-error");
            $('#nonConfCauseFieldDiv').addClass("has-error");
            invalid = true;
        }
        if ($scope.finding.FindingStatus != "New") {
            if (($scope.showDlgBox == 'approveFinding') && (!$scope.finding.NonConfInvestigation)) {
                $('#nonConfInvestigationFieldLabel').addClass("has-error");
                $('#nonConfInvestigationFieldDiv').addClass("has-error");
                invalid = true;
            }
        }

        var assignedToUserInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.assignedToDiv_TopSpan.GetAllUserInfo();
        if (assignedToUserInfo.length > 0) {
            $scope.finding.FindingAssignedTo = SP.FieldUserValue.fromUser(assignedToUserInfo[0]['Description']);
        } else {
            $('#assignedToFieldLabel').addClass("has-error");
            invalid = true;
        }
        var notifyUsersInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.notifyDiv_TopSpan.GetAllUserInfo();
        if (notifyUsersInfo.length > 0) {
            var toNotify = [];
            for (var i = 0; i < notifyUsersInfo.length; i++) {
                toNotify.push(SP.FieldUserValue.fromUser(notifyUsersInfo[i]['Description']));
            }
            $scope.finding.Notify = toNotify;
        }
        return invalid;
    }

    function update() {
        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.update('actionTrackerFindings', $scope.finding, $scope.finding.SPID);
        promiseGet.then(function () {
            // inform user of successful update
            $scope.showDlgBox = "saved";
            $("#savedDlgContent").html('Finding ' + $scope.finding.FindingNumber + ' was succesfully updated');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error updating this finding: " + err);
        });
        if ($scope.finding.FindingStatus == 'In Progress') {
            var camlQString = "<View><Query><Where>"
                + "      <Eq><FieldRef Name='ActionFindingNumber' /><Value Type='Text'>" + $scope.finding.FindingNumber + "</Value></Eq>"
                + "    </Where></Query></View>";
            promiseGet = crudSvr.approveChildren('actionTrackerActions', camlQString);
            promiseGet.then(function () {
                console.log("updated actions status to approved");
                setTimeout(actions(), 5000);
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error updating this finding: " + err);
            });
            var camlQString = "<View><Query><Where>"
                + "      <Eq><FieldRef Name='ReportFindingNumber' /><Value Type='Text'>" + $scope.finding.FindingNumber + "</Value></Eq>"
                + "    </Where></Query></View>";
            promiseGet = crudSvr.approveChildren('actionTrackerReports', camlQString);
            promiseGet.then(function () {
                console.log("updated reports status to approved");
                setTimeout(reports(), 5000);
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error updating this finding: " + err);
            });
        }
    }

    //  cancel new finding
    $scope.cancel = function cancel() {
        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.remove("actionTrackerFindings", $scope.finding.SPID);
        promiseGet.then(function () {
            // inform user of successful update
            $scope.showDlgBox = "canceled";
            $("#canceledDlgContent").html('Canceled creating new finding.');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error cancelling this finding: " + err);
        });
    }

    //  close dlgbox
    $scope.close = function close() {
        if ($scope.showDlgBox == "error") {
            $scope.showDlgBox == "";
            return;
        }
        if ($scope.showDlgBox == "canceled") {
            $('.modal-backdrop').remove();
            window.location.href = "#/";
            //  notify("cancel");
        }
        if ($scope.showDlgBox == "saved") {
            // if the assigned to changed during the save then the save button  
            //    might need to be shown or hidden
            if ((permissionLevel === 'Editor') || (($scope.finding.Multisite) && (POMUser))) {
                $scope.saveBtnEnabled = true;
            } else {
                $scope.saveBtnEnabled = false;
                $scope.canApprove = false;
                $scope.canComplete = false;
            }
            // if the save button is still being shown the status might have change
            //    during the save so we need to hide/show the right button to move on 
            //    the the next stage
            if ($scope.saveBtnEnabled) {
                if ($scope.finding.FindingStatus == 'Waiting Approval') {
                    $scope.canApprove = true;
                    $scope.canComplete = false;
                }
                if ($scope.finding.FindingStatus == 'In Progress') {
                    $scope.canApprove = false;
                    $scope.canComplete = true;
                }
                if ($scope.finding.FindingStatus == 'Complete') {
                    $scope.canApprove = false;
                    $scope.canComplete = false;
                    $scope.saveBtnEnabled = false;
                }
            }
        }

        // if the status was changed then send a notification
        if ($scope.newStatus) {
            $scope.newStatus = false;
            if ($scope.finding.FindingStatus == 'Waiting Approval') {
                notify("new");
            } else {
                notify("statusUpdate");
            }
        }
        $scope.showDlgBox = '';
    }

    // Render and initialize the client-side People Picker.
    function initializePeoplePicker(peoplePickerElementId, allowMultiple) {
        // Create a schema to store picker properties, and set the properties.
        var schema = {};
        var width = '73%';
        schema['PrincipalAccountType'] = 'User,DL,SecGroup,SPGroup';
        schema['SearchPrincipalSource'] = 15;
        schema['ResolvePrincipalSource'] = 15;
        schema['AllowMultipleValues'] = allowMultiple;
        schema['MaximumEntitySuggestions'] = 50;

        // Render and initialize the picker. 
        //   Pass the ID of the DOM element that contains the picker, an array of initial
        //     PickerEntity objects to set the picker value, and a schema that defines
        //     picker properties.
        SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);
        $('#' + peoplePickerElementId + '_TopSpan').width(width);
    }

    // display a table of related findings
    function relatedFindings() {
        var findingList = $scope.finding.RelatedNonConf.split(';');

        // reset findings to accept new search result
        var relatedFindings = [];
        var searchResults = "";

        // set up query
        var queryConditions = []; // add filters to caml query

        // current user's site filter
        for (var i = 0; i < findingList.length; i++) {
            queryConditions.push("<Eq><FieldRef Name='FindingNumber' /><Value Type='Text'>" + findingList[i] + "</Value></Eq>");
        }

        //build query
        var camlQString = "<View><Query><Where>";

        // add filters
        if (queryConditions.length == 1) {
            camlQString += queryConditions[0];
        } else {
            for (var j = 0; j < queryConditions.length - 1; j++) {
                camlQString += "<Or>" + queryConditions[j];
            }
            camlQString += queryConditions[j] + "</Or>";
            for (j = 0; j < queryConditions.length - 2; j++) {
                camlQString += "</Or>";
            }
        }
        camlQString += "</Where></Query></View>";
        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var parsedDate = '';
            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('EnteredDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('EnteredDate').getDate() + '/';
                parsedDate += currentListItem.get_item('EnteredDate').getFullYear();
                relatedFindings.push({
                    FindingNumber: currentListItem.get_item('FindingNumber'),
                    findingStatus: currentListItem.get_item('FindingStatus'),
                    originator: currentListItem.get_item('Originator'),
                    enteredDate: parsedDate
                });
            }

            for (var i = 0; i < relatedFindings.length; i++) {
                searchResults += '<tr><td><a href="#/finding?INo=' + relatedFindings[i].FindingNumber +
                    '" onclick="window.open(\'#/finding?INo=' + relatedFindings[i].FindingNumber + '\', \'' +
                    relatedFindings[i].FindingNumber + '\', \'resizable,width=1000, height=800\'); return false;">' +
                    relatedFindings[i].FindingNumber + '</a></td>' +
                    '<td>' + relatedFindings[i].findingStatus + '</td>' +
                    '<td>' + relatedFindings[i].originator + '</td>' +
                    '<td>' + relatedFindings[i].enteredDate + '</td>' +
                    '<td><button onclick="removeRelatedFinding(\'' + relatedFindings[i].FindingNumber + '\');">remove</button></td></tr>';
            }
            $('#relatedNonConfTable').html('<table id="relatedTable" class="table table-striped" data-toggle="table">' +
                '<thead><tr>' +
                '   <th data-sortable="true">Finding No.</th>' +
                '   <th data-sortable="true">Status</th>' +
                '   <th data-sortable="true">Entered By</th>' +
                '   <th>Date</th><th></th>' +
                '</tr></thead><tbody>' + searchResults + '</tbody></table>');
            $('#relatedTable').DataTable({
                "iDisplayLength": 3,
                "searching": false,
                "lengthChange": false
            });
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting list of related findings: " + err);
        });
    }

    $scope.searchRelatedFindings = function () {
        // reset findings to accept new search result
        $scope.relatedFindings = [];
        var searchRelatedResults = "";
        var limit = true;
        var alreadyRelated = [];
        var i = 0;

        // set up query
        var queryConditions = []; // add filters to caml query

        // current user's site filter
        var sitesFilter = "<In><FieldRef Name='Operation' LookupId='True' /><Values>";
        for (i = 0; i < userGrps.length; i++) {
            sitesFilter += "<Value Type='Text'>" + userGrps[i] + "</Value>";
        }
        sitesFilter += "</Values></In>";
        queryConditions.push(sitesFilter);
        //filter for finding number (or group of numbers)
        if ($scope.relatedFindingNumber) {
            var IncNo = '';
            for (i = 0; i <= $scope.relatedFindingNumber.length; i++) {
                if (!isNaN($scope.relatedFindingNumber.charAt(i))) {
                    IncNo += $scope.relatedFindingNumber.charAt(i);
                }
            }
            queryConditions.push("<Contains><FieldRef Name='FindingNumber' /><Value Type='Text'>" + IncNo + "</Value></Contains>");
            limit = false;
        }
        if ($scope.relatedFindingCategory != '') {
            queryConditions.push("<Contains><FieldRef Name='FindingCategory' /><Value Type='Text'>" + $scope.relatedFindingCategory + "</Value></Contains>");
            limit = false;
        } else {
            if ($scope.finding.FindingCategory[0] != '') {
                queryConditions.push("<Contains><FieldRef Name='FindingCategory' /><Value Type='Text'>" + $scope.finding.FindingCategory[0] + "</Value></Contains>");
                limit = false;
            }
        }

        //build query
        var camlQString = "<View><Query><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy><Where>";

        // add filters
        if (queryConditions.length == 1) {
            camlQString += queryConditions[0];
        } else {
            for (var j = 0; j < queryConditions.length - 1; j++) {
                camlQString += "<And>" + queryConditions[j];
            }
            camlQString += queryConditions[j] + "</And>";
            for (j = 0; j < queryConditions.length - 2; j++) {
                camlQString += "</And>";
            }
        }
        camlQString += "</Where></Query>";
        if (limit) {
            camlQString += "<RowLimit>10</RowLimit>"
        }
        camlQString += "</View>";

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var desc = "";
            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                if ($scope.finding.FindingNumber != currentListItem.get_item('FindingNumber')) { // can't relate finding to itself
                    $scope.relatedFindings.push({
                        FindingNumber: currentListItem.get_item('FindingNumber'),
                        NonConfDescription: currentListItem.get_item('NonConfDescription')
                    });
                }
            }
            for (var i = 0; i < $scope.relatedFindings.length; i++) {
                if ($scope.relatedFindings[i].NonConfDescription) {
                    desc = $scope.relatedFindings[i].NonConfDescription;
                }
                if ($scope.finding.RelatedNonConf.indexOf($scope.relatedFindings[i].FindingNumber) > -1) {
                    alreadyRelated.push(i);
                }
                searchRelatedResults += '<tr><td>' + $scope.relatedFindings[i].FindingNumber + '</td><td>' + desc + '</td></tr>';
                desc = "";
            }
            $('#related').html('<table id="addRelatedTable" class="table table-striped">' +
                '<thead><tr>' +
                '   <th class="col-md-1" data-sortable="true">Finding</th>' +
                '   <th class="col-md-11" data-sortable="true">Description</th>' +
                '</tr></thead><tbody>' + searchRelatedResults + '</tbody></table>');
            $('#addRelatedTable').DataTable({
                "iDisplayLength": 4,
                "searching": false,
                "lengthChange": false,
                "order": [[0, "desc"]],
                "pagingType": "full",
                "select": { style: 'multi' }
            });

            for (i = 0; i < alreadyRelated.length; i++) {
                $('#addRelatedTable').DataTable().row(alreadyRelated[i]).select();
            }
        }, function (err) {
            $scope.showDlgBox = "error";
            $scope.dlgContent = "An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.";
            console.log("Error getting findings list: " + err);
        });
    }

    // add the finding number entered by the user to the list of related findings
    $scope.addRelatedFinding = function addRelatedFinding() {
        $scope.showDlgBox = "";
        var adding = [];
        var table = $('#addRelatedTable').DataTable();

        var data = table.rows({ selected: true }).data();
        for (var i = 0; i < data.length; i++) {
            adding.push(data[i][0]);
        }

        $scope.finding.RelatedNonConf = adding.join(";")
        relatedFindings();
        $scope.addRelated = '';
    }

    // remove a related finding
    $scope.removeRelatedFinding = function removeRelatedFinding(toRemove) {
        if ($scope.finding.RelatedNonConf.indexOf(toRemove) > 1) {
            $scope.finding.RelatedNonConf = $scope.finding.RelatedNonConf.replace(';' + toRemove, '');
        } else {
            $scope.finding.RelatedNonConf = $scope.finding.RelatedNonConf.replace(toRemove + ';', '');
        }
        relatedFindings();
    }

    // list all associated action records
    function actions() {
        var actionList = [];
        var parsedDate = '';
        var searchResults = "";
        $('#actionsTable').html = '';

        //build query
        var camlQString = "<View><Query><Where>" +
            "   <Eq><FieldRef Name='ActionFindingNumber' /><Value Type='Text'>" + $scope.finding.FindingNumber + "</Value></Eq>" +
            "</Where></Query></View>"

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerActions', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('ActionDueDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('ActionDueDate').getDate() + '/';
                parsedDate += currentListItem.get_item('ActionDueDate').getFullYear();
                actionList.push({
                    ActionSPID: currentListItem.get_item('ID'),
                    ActionType: currentListItem.get_item('ActionType'),
                    ActionApproved: currentListItem.get_item('ActionApproved'),
                    ActionShortDescription: currentListItem.get_item('ActionShortDescription'),
                    ActionAssignedTo: currentListItem.get_item('ActionAssignedTo'),
                    ActionDueDate: parsedDate,
                    ActionStatus: currentListItem.get_item('ActionStatus')
                });
            }

            for (var i = 0; i < actionList.length; i++) {
                searchResults += '<tr><td><a class="btn btn-primary" href="#/action?AId=' + actionList[i].ActionSPID + '&FId=' + $scope.finding.FindingNumber + '&IEditor=' + !$scope.verifyBtnEnabled + '&dueDate=' + $scope.finding.FindingCompleteDue + '">Edit/View</a></td>' +
                    '<td>' + actionList[i].ActionShortDescription + '</td>' +
                    '<td>' + actionList[i].ActionAssignedTo.get_lookupValue() + '</td>' +
                    '<td>' + actionList[i].ActionDueDate + '</td>' +
                    '<td>' + actionList[i].ActionStatus + '</td></tr>';
            }
            if (searchResults) {
                $('#actionsTableDiv').html('<table id="actionsTable" class="table table-striped" data-toggle="table">' +
                    '<thead><tr>' +
                    '   <th data-sortable="true"></th>' +
                    '   <th data-sortable="true">Action Title</th>' +
                    '   <th data-sortable="true">Assigned To</th>' +
                    '   <th data-sortable="true">Due Date</th>' +
                    '   <th data-sortable="true">Status</th>' +
                    '</tr></thead><tbody>' + searchResults + '</tbody></table>');
                if ($scope.saveBtnEnabled) {
                    $('#actionsTableDiv').removeClass("col-sm-12");
                    $('#actionsTableDiv').addClass("col-sm-10");
                }
                $('#actionsTable').DataTable({
                    "iDisplayLength": 15,
                    "searching": false,
                    "lengthChange": false
                });
            }
            $scope.AssociatedActionCount = actionList.length;
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting actions list: " + err);
        });
    }

    // list all associated report records
    function reports() {
        var reportList = []
        var searchResults = "";
        var parsedDate = '';
        $('#reportsTable').html = '';

        //build query
        var camlQString = "<View><Query><Where>" +
            "   <Eq><FieldRef Name='ReportFindingNumber' /><Value Type='Text'>" + $scope.finding.FindingNumber + "</Value></Eq>" +
            "</Where></Query></View>"

        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.get('actionTrackerReports', camlQString);
        promiseGet.then(function (resp) {
            //parse results of search
            var enumerator = resp.getEnumerator();
            var currentListItem;
            while (enumerator.moveNext()) {
                currentListItem = enumerator.get_current();
                parsedDate = (currentListItem.get_item('ReportDueDate').getMonth() + 1) + '/';
                parsedDate += currentListItem.get_item('ReportDueDate').getDate() + '/';
                parsedDate += currentListItem.get_item('ReportDueDate').getFullYear();
                reportList.push({
                    ReportSPID: currentListItem.get_item('ID'),
                    ReportAudience: currentListItem.get_item('ReportAudience'),
                    ReportStatus: currentListItem.get_item('ReportStatus'),
                    ReportDueDate: parsedDate,
                    ReportAssignedTo: currentListItem.get_item('ReportAssignedTo')
                });
            }

            for (var i = 0; i < reportList.length; i++) {
                searchResults += '<tr><td><a class="btn btn-primary" href="#/report?RId=' + reportList[i].ReportSPID + '&FId=' + $scope.finding.FindingNumber + '&IEditor=' + $scope.saveBtnEnabled + '&dueDate=' + $scope.finding.FindingCompleteDue + '">Edit/View</a></td>' +
                    '<td>' + reportList[i].ReportAudience + '</td>' +
                    '<td>' + reportList[i].ReportAssignedTo.get_lookupValue() + '</td>' +
                    '<td>' + reportList[i].ReportDueDate + '</td>' +
                    '<td>' + reportList[i].ReportStatus + '</td></tr>';
            }
            if (searchResults) {
                $('#reportsTableDiv').html('<table id="reportsTable" class="table table-striped" data-toggle="table">' +
                    '<thead><tr>' +
                    '   <th data-sortable="true"></th>' +
                    '   <th data-sortable="true">Report Audience</th>' +
                    '   <th data-sortable="true">Assigned To</th>' +
                    '   <th data-sortable="true">Due Date</th>' +
                    '   <th data-sortable="true">Status</th>' +
                    '</tr></thead><tbody>' + searchResults + '</tbody></table>');
                if ($scope.saveBtnEnabled) {
                    $('#reportsTableDiv').removeClass("col-sm-12");
                    $('#reportsTableDiv').addClass("col-sm-10");
                }
                $('#reportsTable').DataTable({
                    "iDisplayLength": 15,
                    "searching": false,
                    "lengthChange": false
                });
            }
            $scope.AssociatedReportCount = reportList.length;
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error getting reports list: " + err);
        });
    }

    $scope.removeAttachment = function removeAttachment(fileName) {
        $scope.removeAttachedFileName = fileName;
        $scope.showDlgBox = 'removeAttachment';
        $('#myModal').modal('show');
    }

    $scope.removeAttached = function () {
        var promiseGet = fileUploadSvr.removeAttachment('actionTrackerFindings', $scope.finding.SPID, $scope.removeAttachedFileName);
        promiseGet.then(function () {
            var idx = $scope.AttachedFileNames.indexOf($scope.removeAttachedFileName);
            if (idx > -1) {
                $scope.AttachedFileNames.splice(idx, 1);
            }
            showAttachments();
        });
    }

    $scope.uploadAttachment = function () {
        var alreadyAttached = false;
        var fileInput = $('#attachmentsField');
        var files = fileInput[0].files;
        var fileName = files[0].name;

        for (var i = 0; i < $scope.AttachedFileNames.length; i++) {
            if ($scope.AttachedFileNames[i] == fileName) {
                alreadyAttached = true
            }
        }

        if (alreadyAttached) {
            $scope.removeAttachedFileName = fileName
            $scope.showDlgBox = 'updateAttachment';
            $('#myModal').modal('show');
        } else {
            var promiseGet = fileUploadSvr.addAttachment('attachmentsField', 'attachmentsList', 'actionTrackerFindings', $scope.finding.SPID);
            promiseGet.then(function () {
                showAttachments();
            });
        }
        $('#attachmentsField').val("");
    }

    function showAttachments() {
        var attachmentLink = "";
        var fileIcon = "";
        var docURL = "";
        var promiseGet = fileUploadSvr.listAttachment('actionTrackerFindings', $scope.finding.SPID);
        promiseGet.then(function (attachments) {
            if (attachments.length > 0) {
                $scope.AttachedFileNames = attachments;
                $('#attachmentsList').html("");
                for (var i = 0; i < attachments.length; i++) {
                    switch (true) {
                        case (attachments[i].indexOf(".doc") != -1):
                            fileIcon = "doc.png";
                            docURL = hostUrl + '/Lists/actionTrackerFindings/Attachments/' + $scope.finding.SPID + '/' + attachments[i];
                            break;
                        case (attachments[i].indexOf(".xls") != -1):
                            fileIcon = "xls.png"; break;
                        case (attachments[i].indexOf(".ppt") != -1):
                            fileIcon = "ppt.png"; break;
                        case (attachments[i].indexOf(".pdf") != -1):
                            fileIcon = "pdf.png"; break;
                        case (attachments[i].indexOf(".txt") != -1):
                            fileIcon = "txt.png"; break;
                        case (attachments[i].indexOf(".zip") != -1):
                            fileIcon = "zip.png"; break;
                        default:
                            fileIcon = "unknown.png"; break;
                    }
                    if ((attachments[i].indexOf(".doc") != -1) || (attachments[i].indexOf(".xls") != -1) || (attachments[i].indexOf(".ppt") != -1)) {
                        attachmentLink = '<span class="col-sm-3 text-center"><a href="' + hostUrl + '/_layouts/15/WopiFrame.aspx?sourcedoc=' + docURL + '&action=default" target="_blank">';
                    } else {
                        attachmentLink = '<span class="col-sm-3 text-center"><a href="' + hostUrl + '/Lists/actionTrackerFindings/Attachments/' + $scope.finding.SPID + '/' + attachments[i] + '" target="_blank">';
                    }
                    attachmentLink += '<img src="../Images/fileIcons/' + fileIcon + '" width="75px"><br />' + attachments[i] + '</a>';
                    if ($scope.saveBtnEnabled) {
                        attachmentLink += '<br /><button class="linkButton" onclick="removeAttachment(\'' + attachments[i] + '\');">Remove</button></span>';
                    }
                    $('#attachmentsList').append(attachmentLink);
                }
            } else {
                $('#attachmentsList').html('Finding ' + $scope.finding.FindingNumber + " has no attachments.");
            }
        }, function (err) {
            if (err != 'File Not Found.') {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error getting attachment list: " + err);
            }
        });
    }

    // send a notification email to the assigned to user and everyone on the notify list
    function notify(notice) {
        var sendTo = "";
        var subject = "";
        var body = "";
        // notify message that a new finding has been created
        // test variable is set to blank in prod and **TEST** - in developer environment. see app.js for the code that does this
        var assignedToUserInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.assignedToDiv_TopSpan.GetAllUserInfo();
        if (assignedToUserInfo.length > 0) {
            sendTo = assignedToUserInfo[0]['Description'];
        }

        if (assignedToUserInfo) {
            if (notice == "new") {
                subject = test + "Action Tracker Assignment: Finding " + $scope.finding.FindingNumber;
                body = test + "<p>This notification has been sent to inform you that Action Tracker has a newly created finding that has been assigned to you.</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p>" +
                    "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + $scope.finding.FindingNumber + "</p><p>" +
                    "<b>Finding Details:</b><br>" +
                    "<b> Title:</b> " + $scope.finding.NonConfDescription + "<br>" +
                    "<b> Source:</b> " + $scope.finding.FindingCategory + "<br>" +
                    "<b> Category:</b> " + $scope.finding.FindingType + "</p>";
            }
            // notify message for status updates
            if (notice == "statusUpdate") {
                subject = test + "Action Tracker: Finding Status Change - " + $scope.finding.FindingNumber;
                body = test + "<p>Status for action tracker finding " + $scope.finding.FindingNumber + " has been changed to <b>" + $scope.finding.FindingStatus + "</b><br>" +
                    "You are receiving this notification because this Finding was assigned to you.</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p>" +
                    "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + $scope.finding.FindingNumber + "</p><p>" +
                    "<b>Finding Details:</b><br>" +
                    "<b> Title:</b> " + $scope.finding.NonConfDescription + "<br>" +
                    "<b> Source:</b> " + $scope.finding.FindingCategory + "<br>" +
                    "<b> Category:</b> " + $scope.finding.FindingType + "</p>";
            }

            if (notice == "cancel") {
                subject = test + "Action Tracker: Finding " + $scope.finding.FindingNumber + " has been cancelled";
                body = test + "<p>Action tracker finding " + $scope.finding.FindingNumber + " has been cancelled<br>" +
                    "You are receiving this notification because this Finding was assigned to you.</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p><p>" +
                    "<b>Finding Details:</b><br>" +
                    "<b> Title:</b> " + $scope.finding.NonConfDescription + "<br>" +
                    "<b> Source:</b> " + $scope.finding.FindingCategory + "<br>" +
                    "<b> Category:</b> " + $scope.finding.FindingType + "</p>";
            }

            if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
            }
            sendTo = "";
        }

        var notifyUsersInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.notifyDiv_TopSpan.GetAllUserInfo();
        if (notifyUsersInfo.length > 0) {
            sendTo = notifyUsersInfo[0]['Description'];
            for (var i = 1; i < notifyUsersInfo.length; i++) {
                if (sendTo.indexOf(notifyUsersInfo[i]['Description']) < 0) {
                    sendTo += "," + notifyUsersInfo[i]['Description'];
                }
            }

            if (notice == "new") {
                subject = test + "Action Tracker: New Finding " + $scope.finding.FindingNumber;
                body = test + "<p>This notification has been sent to inform you that Action Tracker has a newly created finding. You have been identified as a person to be notified regarding changes to finding " + $scope.finding.FindingNumber + "</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p>" +
                    "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + $scope.finding.FindingNumber + "</p><p>" +
                    "<b>Finding Details:</b><br>" +
                    "<b> Title:</b> " + $scope.finding.NonConfDescription + "<br>" +
                    "<b> Source:</b> " + $scope.finding.FindingCategory + "<br>" +
                    "<b> Category:</b> " + $scope.finding.FindingType + "</p>";
            }
            // notify message for status updates
            if (notice == "statusUpdate") {
                subject = test + "Action Tracker: Finding Status Change - " + $scope.finding.FindingNumber;
                body = test + "<p>Status for action tracker finding " + $scope.finding.FindingNumber + " has been changed to <b>" + $scope.finding.FindingStatus + "</b>You have been identified as a person to be notified regarding changes this finding</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p>" +
                    "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + $scope.finding.FindingNumber + "</p><p>" +
                    "<b>Finding Details:</b><br>" +
                    "<b> Title:</b> " + $scope.finding.NonConfDescription + "<br>" +
                    "<b> Source:</b> " + $scope.finding.FindingCategory + "<br>" +
                    "<b> Category:</b> " + $scope.finding.FindingType + "</p>";
            }
            if (notice == "cancel") {
                subject = test + "Action Tracker: Finding " + $scope.finding.FindingNumber + " has been cancelled";
                body = test + "<p>Action tracker finding " + $scope.finding.FindingNumber + " has been cancelled. You have been identified as a person to be notified regarding changes this finding<br>" +
                    "You are receiving this notification because this Finding was assigned to you.</p>" +
                    "<p>Please do not reply to this email as this address is not monitored.</p><p>" +
                    "<b>Finding Details:</b><br>" +
                    "<b> Title:</b> " + $scope.finding.NonConfDescription + "<br>" +
                    "<b> Source:</b> " + $scope.finding.FindingCategory + "<br>" +
                    "<b> Category:</b> " + $scope.finding.FindingType + "</p>";
            }
            if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
            }
        }
        // sendmail(from,to,body,subject) is defined in app.js
        //    sendEmail('Action Tracker', sendTo, body, subject);
    }
});