﻿/******************************************************************************
* actionCntrl.js
* Author: Sam Johnson
* 
* The following code defines the controller methods and properties for the
* action page of the The Action Tracking app. This page is used to enter new or 
* edit the details of an action associated with an finding.
* 
* Revisions:
* 
******************************************************************************/
'use strict';

app.controller('action', function ($scope, $location, crudSvr, fileUploadSvr) {
    // properties
    $scope.action = {
        ActionSPID: null,
        ActionFindingNumber: "",
        ActionFindingID: "",
        ActionType: "",
        ActionShortDescription: "",
        ActionLongDescription: "",
        ActionApproved: false,
        ActionApprover: "",
        ActionResult: "",
        ActionDueDate: "",
        ActionCompletionDate: "",
        ActionAssignedTo: "",
        ActionStatus: "New"
    };
    $scope.showDlgBox = '';
    $scope.saveBtnEnabled = true;
    $scope.actionSPID = $location.search().AId;
    $scope.findingNo = $location.search().FId;
    $scope.findingEditor = ($location.search().IEditor == 'true');
    if ($location.search().dueDate) {
        $scope.compDate = $location.search().dueDate;
    } else {
        $scope.compDate = new Date("Jan 1, 2000"); // set default date to past date
    }
    $scope.canApprove = false;
    $scope.canComplete = false;
    $scope.canSeeResult = false;
    $scope.newStatus = false;
    $scope.AttachedFileNames = []
    $scope.removeAttachedFileName = "";
    $scope.updateAttachedFileName = "";

    // type selection options
    $scope.types = ['CAR', 'PAR'];

    // set scroll bar height
    var height = window.innerHeight;
    $('.content').css('height', height - 420 + 'px');
    // load the finding into form
    load();

    // methods
    //Load an Finding
    function load() {
        // set up datepickers
        $("#actionDueDateField").datepicker({
            autoclose: true,
            dateFormat: 'm/d/yyyy'
        });
        // set up peoplepickers
        // Render and initialize the client-side People Picker.
        var schema = {};
        var width = '73%';
        schema['PrincipalAccountType'] = 'User,DL,SecGroup,SPGroup';
        schema['SearchPrincipalSource'] = 15;
        schema['ResolvePrincipalSource'] = 15;
        schema['AllowMultipleValues'] = false;
        schema['MaximumEntitySuggestions'] = 50;

        // Render and initialize the picker. 
        SPClientPeoplePicker_InitStandaloneControlWrapper('actionAssignedToDiv', null, schema);
        $('#actionAssignedToDiv_TopSpan').width(width);

        if ($scope.actionSPID) {
            var camlQString = "<View><Query><Where>"
                            + "      <Eq><FieldRef Name='ID' /><Value Type='Text'>" + $scope.actionSPID + "</Value></Eq>"
                            + "</Where></Query></View>";
        
            var promiseGet = crudSvr.get('actionTrackerActions', camlQString);
            promiseGet.then(function (resp) {
                var enumerator = resp.getEnumerator();

                while (enumerator.moveNext()) {
                  var currentListItem = enumerator.get_current();
                  $scope.action.ActionSPID = currentListItem.get_item('ID');
                  $scope.action.ActionFindingNumber = currentListItem.get_item('ActionFindingNumber');
                  $scope.action.ActionType = currentListItem.get_item('ActionType');
                  $scope.action.ActionShortDescription = currentListItem.get_item('ActionShortDescription');
                  $scope.action.ActionLongDescription = currentListItem.get_item('ActionLongDescription');
                  $scope.action.ActionApproved = currentListItem.get_item('ActionApproved');
                  $scope.action.ActionApprover = currentListItem.get_item('ActionApprover');
                  $scope.action.ActionResult = currentListItem.get_item('ActionResult');
                  var dueDate = currentListItem.get_item('ActionDueDate');
                  if (dueDate) {
                      $scope.action.ActionDueDate = (dueDate.getMonth() + 1) + "/" + dueDate.getDate() + "/" + dueDate.getFullYear();
                  }
                  var compDate = currentListItem.get_item('ActionCompletionDate');
                  if (compDate) {
                      $scope.action.ActionCompletionDate = (compDate.getMonth() + 1) + "/" + compDate.getDate() + "/" + compDate.getFullYear();
                  }
                  $scope.action.ActionAssignedTo = currentListItem.get_item('ActionAssignedTo');
                  $scope.action.ActionStatus = currentListItem.get_item('ActionStatus');
              }

              $scope.findingNo = $scope.action.ActionFindingNumber;
           
              showAttachments();

              // populate AssignedTo field
              if ($scope.action.ActionAssignedTo) {
                  var actionAssignedToPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict.actionAssignedToDiv_TopSpan;
                  var actionAssignedTo = $scope.action.ActionAssignedTo;
                  var actionAssignedToObj = { 'Key': actionAssignedTo.get_email() };
                  actionAssignedToPeoplePicker.AddUnresolvedUser(actionAssignedToObj, true);
                  // only assign to and originator can make changes
                  if (((actionAssignedTo.get_email() == currentUser.get_email()) || ($scope.findingEditor)) && (permissionLevel !== 'Viewer')) {
                      $scope.saveBtnEnabled = true;
                  } else {
                      $scope.saveBtnEnabled = false;
                  }
              }

              // if this action is complete then remove save button
              if ($scope.action.ActionStatus == "Complete") {
                  $scope.saveBtnEnabled = false;
                  $scope.canSeeResult = true;
                  $scope.findingEditor = false;
              }

              if ($scope.saveBtnEnabled) {
                  if ($scope.action.ActionStatus == 'Waiting Approval') {
                      $scope.canApprove = true;
                  }
                  if ($scope.action.ActionStatus == 'In Progress') {
                      $scope.canComplete = true;
                      $scope.canSeeResult = true;
                  }
              }
              $scope.deleteButtonTitle = "Delete";
            }, function (err) {
                $scope.showDlgBox = "error";//$("#errorDlgContent").html(
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error getting this action: " + err);
          });
        } else {
            $scope.action.ActionFindingNumber = $scope.findingNo;
            $scope.deleteButtonTitle = "Cancel";
        }
        getFindingID();
    }

    function getFindingID() {
        var camlQString = "<View><Query><Where>"
                     + "      <Eq><FieldRef Name='FindingNumber' /><Value Type='Text'>" + $scope.findingNo + "</Value></Eq>"
                     + "</Where></Query></View>";
        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            var enumerator = resp.getEnumerator();
            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                $scope.action.ActionFindingID = currentListItem.get_item('ID');
                if (new Date($scope.compDate).getFullYear() == 2000) {
                    if (currentListItem.get_item('FindingCompleteDue')) {
                        $scope.compDate = currentListItem.get_item('FindingCompleteDue');
                    }
                }
            }
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error loading this finding ID: " + err);
        });
    }

    $scope.save = function save() {
        if (invalid("save")) {
            if ($scope.showDlgBox != "error") {
              $scope.showDlgBox = "error";
              $("#errorDlgContent").html('This Action is missing required information. Please correct and resubmit');  
            }
            return;
        }
        if ($scope.action.ActionStatus == "New") {
            $scope.action.ActionStatus = "Waiting Approval";
            $scope.newStatus = true;
        }
        $scope.deleteButtonTitle = "Delete";
        update();
    }

    $scope.complete = function complete() {
        if (invalid()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Action is missing required information. Please correct and resubmit');
            return;
        }
        $scope.action.ActionStatus = 'Complete';
        $scope.action.ActionCompletionDate = new Date();
        $scope.newStatus = true;
        update();
        $scope.findingEditor = false;
        $scope.canComplete = false;
    }

    $scope.approve = function approve() {
        if (invalid()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html('This Action is missing required information. Please correct and resubmit');
            return;
        }

        $scope.action.ActionApproved = true;
        $scope.action.ActionApprover = SP.FieldUserValue.fromUser(currentUser.get_email());
        $scope.action.ActionStatus = 'In Progress';
        $scope.newStatus = true;
        update();
    }

    //  cancel new action
    $scope.cancel = function cancel() {
        if ($scope.action.ActionStatus == "New") {
            $('.modal-backdrop').remove();
            window.location.href = "#/finding?INo=" + $scope.findingNo;
            return;
        }
        // call sharepoint for data through crudSvr
        var promiseGet = crudSvr.remove('actionTrackerActions', $scope.action.ActionSPID);
        promiseGet.then(function () {
            // inform user of successful update
            $scope.showDlgBox = "canceled";
            $("#canceledDlgContent").html('The action has been removed');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error cancelling this action: " + err);
        });
    }

    function update() {
        // call sharepoint for data through crudSvr
        var promiseGet = "";
        if ($scope.action.ActionSPID) {
            promiseGet = crudSvr.update('actionTrackerActions', $scope.action, $scope.action.ActionSPID);
        } else {
            promiseGet = crudSvr.add('actionTrackerActions', $scope.action);
        }
        promiseGet.then(function (resp) {
            $scope.action.ActionSPID = resp.get_item('ID');
            // inform user of successful update
            $scope.showDlgBox = "saved";
            $("#savedDlgContent").html('This action was succesfully saved');
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error updating this action: " + err);
        });
        var aDueDate = new Date($scope.action.ActionDueDate);
        var fDueDate = new Date($scope.compDate);
        if (aDueDate.getTime() > fDueDate.getTime()) {
            promiseGet = crudSvr.updateCompDueDate(aDueDate, $scope.action.ActionFindingID);
            promiseGet.then(function (resp) {
                return;
            }, function (err) {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error updating this finding Complete By: " + err);
            });
        }
    }

    //  close dlgbox
    $scope.close = function close() {
        if ($scope.showDlgBox == "error") {
            $scope.showDlgBox == "";
            return;
        }

        if ($scope.showDlgBox == "canceled") {
            $('.modal-backdrop').remove();
            if ($scope.action.ActionStatus == 'In Progress') {
                notify("cancel");
            }
            window.location.href = "#/finding?INo=" + $scope.findingNo;
            return;
        }

        if ($scope.showDlgBox == "saved") {
          if (($scope.action.ActionAssignedTo.get_email() == currentUser.get_email()) || ($scope.findingEditor)) {
             $scope.saveBtnEnabled = true;
          } else {
             $scope.saveBtnEnabled = false;
          }
          if ($scope.saveBtnEnabled) {
              if ($scope.action.ActionStatus == 'Waiting Approval') {
                  $scope.canApprove = true;
                  $scope.canComplete = false;
                  $scope.canSeeResult = false;
              }
              if ($scope.action.ActionStatus == 'In Progress') {
                  $scope.canApprove = false;
                  $scope.canComplete = true;
                  $scope.canSeeResult = true;
              }
              if ($scope.action.ActionStatus == 'Complete') {
                  $scope.canSeeResult = true;
                  $scope.canApprove = false;
                  $scope.canComplete = false;
                  $scope.saveBtnEnabled = false;
              }
          }
        }
        if ($scope.newStatus) {
            $scope.newStatus = false;
            if ($scope.action.ActionStatus == 'Waiting Approval') {
                notify("new");
            } else {
                notify("statusUpdate");
            }
        }
        $scope.showDlgBox = '';
    }

    function invalid(called) {
        var invalid = false;
        // reset fields
        $('div').removeClass("has-error");
        $('label').removeClass("has-error");

        if (!$scope.action.ActionType) {
            $('#actionTypeFieldLabel').addClass("has-error");
            $('#actionTypeFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.action.ActionShortDescription) {
            $('#actionShortDescriptionFieldLabel').addClass("has-error");
            $('#actionShortDescriptionFieldDiv').addClass("has-error");
            invalid = true;
        }
        if (!$scope.action.ActionDueDate) {
            $('#actionDueDateFieldLabel').addClass("has-error");
            $('#actionDueDateFieldDiv').addClass("has-error");
            invalid = true;
        }
        // invalid if action due date is after finding due date
        var aDueDate = new Date($scope.action.ActionDueDate);
        var fDueDate = new Date($scope.compDate);
        var currentDate = new Date();

        if (aDueDate.getTime() < currentDate.getTime()) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("Action Due Date must be a future date");
            $scope.action.ActionDueDate = "";
            $('#actionDueDateFieldLabel').addClass("has-error");
            $('#actionDueDateFieldDiv').addClass("has-error");
            invalid = true;
        }

        if (called != "save") {
            if ($scope.canComplete) {
                if (!$scope.action.ActionResult) {
                    $('#actionResultFieldLabel').addClass("has-error");
                    $('#actionResultFieldDiv').addClass("has-error");
                    invalid = true;
                }
            }
        }

        var assignedToUserInfo = SPClientPeoplePicker.SPClientPeoplePickerDict.actionAssignedToDiv_TopSpan.GetAllUserInfo();
        if (assignedToUserInfo.length > 0) {
          $scope.action.ActionAssignedTo = SP.FieldUserValue.fromUser(assignedToUserInfo[0]['Description']);
        } else {
          $('#actionAssignedToFieldLabel').addClass("has-error");
          invalid = true;
        }
        return invalid;
      }

    $scope.removeAttachment = function removeAttachment(fileName) {
        $scope.removeAttachedFileName = fileName;
        $scope.showDlgBox = 'removeAttachment';
        $('#myModal').modal('show');
    }

    $scope.removeAttached = function () {
        var promiseGet = fileUploadSvr.removeAttachment('actionTrackerActions', $scope.action.ActionSPID, $scope.removeAttachedFileName);
        promiseGet.then(function () {
            var idx = $scope.AttachedFileNames.indexOf($scope.removeAttachedFileName);
            if (idx > -1) {
                $scope.AttachedFileNames.splice(idx, 1);
            }
            showAttachments();
        });
    }

    $scope.uploadAttachment = function () {
        var alreadyAttached = false;
        var fileInput = $('#attachmentsField');
        var files = fileInput[0].files;
        var fileName = files[0].name;

        for (var i = 0; i < $scope.AttachedFileNames.length; i++) {
            if ($scope.AttachedFileNames[i] == fileName) {
                alreadyAttached = true
            }
        }

        if (alreadyAttached) {
            $scope.removeAttachedFileName = fileName
            $scope.showDlgBox = 'updateAttachment';
            $('#myModal').modal('show');
        } else {
            var promiseGet = fileUploadSvr.addAttachment('attachmentsField', 'attachmentsList', 'actionTrackerActions', $scope.action.ActionSPID);
            promiseGet.then(function () {
                showAttachments();
            });
        }
        $('#attachmentsField').val("");
    }

    function showAttachments() {
        var attachmentLink = "";
        var fileIcon = "";
        var promiseGet = fileUploadSvr.listAttachment('actionTrackerActions', $scope.action.ActionSPID);
        promiseGet.then(function (attachments) {
            if (attachments.length > 0) {
                $scope.AttachedFileNames = attachments;
                $('#attachmentsList').html("");
                for (var i = 0; i < attachments.length; i++) {
                    switch (true) {
                        case (attachments[i].indexOf(".doc") != -1):
                            fileIcon = "doc.png"; break;
                        case (attachments[i].indexOf(".xls") != -1):
                            fileIcon = "xls.png"; break;
                        case (attachments[i].indexOf(".ppt") != -1):
                            fileIcon = "ppt.png"; break;
                        case (attachments[i].indexOf(".pdf") != -1):
                            fileIcon = "pdf.png"; break;
                        case (attachments[i].indexOf(".txt") != -1):
                            fileIcon = "txt.png"; break;
                        case (attachments[i].indexOf(".zip") != -1):
                            fileIcon = "zip.png"; break;
                        default:
                            fileIcon = "unknown.png"; break;
                    }
                    attachmentLink = '<span class="col-sm-3 text-center"><a href="' + hostUrl + '/Lists/actionTrackerActions/Attachments/' + $scope.action.ActionSPID + '/' + attachments[i] + '" target="_blank">' +
                        '<img src="../Images/fileIcons/' + fileIcon + '" width="75px"><br />' + attachments[i] + '</a>';
                    if ($scope.saveBtnEnabled) {
                        attachmentLink += '<br /><button class="linkButton" onclick="removeAttachment(\'' + attachments[i] + '\');">Remove</button></span>';
                    }
                    $('#attachmentsList').append(attachmentLink);
                }
            } else {
                $('#attachmentsList').html("This action has no attachments.");
            }
        }, function (err) {
            if (err != 'File Not Found.') {
                $scope.showDlgBox = "error";
                $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
                console.log("Error getting attachment list: " + err);
            }
        });
    }

    // send a notification email to the report assigned to user and the finding assigned to user and everyone on the notify list
    function notify(notice) {
        var sendTo = "";
        var subject = "";
        var body = "";

        var camlQString = "<View><Query><Where>"
                        + "      <Eq><FieldRef Name='FindingNumber' /><Value Type='Text'>" + $scope.action.ActionFindingNumber + "</Value></Eq>"
                        + "</Where></Query></View>";

        var promiseGet = crudSvr.get('actionTrackerFindings', camlQString);
        promiseGet.then(function (resp) {
            var enumerator = resp.getEnumerator();

            while (enumerator.moveNext()) {
                var currentListItem = enumerator.get_current();
                var FindingNumber = currentListItem.get_item('FindingNumber');
                var FindingAssignedTo = currentListItem.get_item('FindingAssignedTo');
                var FindingNotify = currentListItem.get_item('Notify');
                var FindingStatus = currentListItem.get_item('FindingStatus');
            }

            if (FindingStatus !== 'Waiting Approval') {

                var assignedToUserInfo = $scope.action.ActionAssignedTo.get_email();
                if (assignedToUserInfo) {
                    sendTo = assignedToUserInfo;

                    if (notice == "new") {
                        subject = test + "Action Tracker: New Action for Finding " + FindingNumber;
                        body = test + "<p>A new Action has been attached to finding " + FindingNumber + ". This Action has been assigned to you.</p>" +
                            "<b>Action Details:</b><br>" +
                            "<b> Title:</b> " + $scope.action.ActionShortDescription + "<br>" +
                            "<b> Description:</b> " + $scope.action.ActionLongDescription + "<br>" +
                            "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                            "<b> Status:</b> " + $scope.action.ActionStatus + "<br>" +
                            "<p>Please do not reply to this email as this address is not monitored.</p>" +
                            "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                    }

                    // notify message that a new finding has been created
                    if (notice == "statusUpdate") {
                        if ($scope.action.ActionStatus == 'In Progress') {
                            subject = test + "Action Tracker: Action Assignment";
                            body = test + "<p>An Action attached to finding " + FindingNumber + " has been moved to 'In Progress' status. This Action has been assigned to you.</p>" +
                                "<b>Action Details:</b><br>" +
                                "<b> Title:</b> " + $scope.action.ActionShortDescription + "<br>" +
                                "<b> Description:</b> " + $scope.action.ActionLongDescription + "<br>" +
                                "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                                "<b> Status:</b> " + $scope.action.ActionStatus + "<br>" +
                                "<p>Please do not reply to this email as this address is not monitored.</p>" +
                                "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                            //      sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                        }
                        if ($scope.action.ActionStatus == 'Complete') {
                            subject = test + "Action Tracker: Action Assignment";
                            body = test + "<p>An Action attached to finding " + FindingNumber + " has been completed. This Action was assigned to you.</p>" +
                                "<b>Action Details:</b><br>" +
                                "<b> Title:</b> " + $scope.action.ActionShortDescription + "<br>" +
                                "<b> Description:</b> " + $scope.action.ActionLongDescription + "<br>" +
                                "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                                "<b> Status:</b> " + $scope.action.ActionStatus + "<br>" +
                                "<p>Please do not reply to this email as this address is not monitored.</p>" +
                                "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                            //      sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                        }
                    }
                    // notify message for cancelling a report
                    if (notice == "cancel") {
                        subject = test + "Action Tracker: Cancelled Action for Finding " + FindingNumber;
                        body = test + "<p>An Action attached to finding " + FindingNumber + " has been removed. This action had the following desctiption: " +
                            "<b>" + $scope.action.ActionShortDescription + "</b><br>You are receiving this notification because the action was assigned to you.</p>" +
                            "<b>Action Details:</b><br>" +
                            "<b> Title:</b> " + $scope.action.ActionShortDescription + "<br>" +
                            "<b> Description:</b> " + $scope.action.ActionLongDescription + "<br>" +
                            "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                            "<b> Status:</b> " + $scope.action.ActionStatus + "<br>" +
                            "<p>Please do not reply to this email as this address is not monitored.</p>" +
                            "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                    }
                    // sendmail(from,to,body,subject) is defined in app.js
                    if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                        sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                    }
                    sendTo = "";
                }

                if (FindingAssignedTo) {
                    if ($scope.action.ActionAssignedTo.get_lookupValue() != FindingAssignedTo.get_lookupValue()) {
                        sendTo = FindingAssignedTo.get_email();
                    }
                }

                if (FindingNotify) {
                    for (var i = 0; i < FindingNotify.length; i++) {
                        if (sendTo.indexOf(FindingNotify[i].get_email()) < 0) {
                            sendTo += "," + FindingNotify[i].get_email();
                        }
                    }
                }
                /*
                if (notice == "new") {
                    subject = test + "Action Tracker: New Action for Finding " + FindingNumber;
                    body = test + "<p>A new Action has been attached to finding " + FindingNumber + ". You have been identified as a person to be notified regarding changes to this finding.</p>" +
                        "<b>Action Details:</b><br>" +
                        "<b> Title:</b> " + $scope.action.ActionShortDescription + "<br>" +
                        "<b> Description:</b> " + $scope.action.ActionLongDescription + "<br>" +
                        "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                        "<b> Status:</b> " + $scope.action.ActionStatus + "<br>" +
                        "<p>Please do not reply to this email as this address is not monitored.</p>" +
                        "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                }
                */
                // notify message for status updates
                if (notice == "statusUpdate") {
                    subject = test + "Action Tracker: Action Status Change - " + FindingNumber;
                    body = test + "<p>Status for an Action attached to Action Tracker Finding " + FindingNumber + " has been changed to <b>" + $scope.action.ActionStatus + "</b></p>" +
                        "<b>Action Details:</b><br>" +
                        "<b> Title:</b> " + $scope.action.ActionShortDescription + "<br>" +
                        "<b> Description:</b> " + $scope.action.ActionLongDescription + "<br>" +
                        "<b> Finding Number:</b> " + FindingNumber + "<br>" +
                        "<b> Status:</b> " + $scope.action.ActionStatus + "<br>" +
                        "<p>Please do not reply to this email as this address is not monitored.</p>" +
                        "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                }
                // notify message for cancelling a report
                if (notice == "cancel") {
                    subject = test + "Action Tracker: Cancelled Action for Finding " + FindingNumber;
                    body = test + "<p>An Action attached to finding " + FindingNumber + " has been removed. This action had the following title:<br>&nbsp;&nbsp;&nbsp;<b>" +
                        $scope.action.ActionShortDescription + "</b><br>You have been identified as a person to be notified regarding changes to this finding.</p>" +
                        "<p>Please do not reply to this email as this address is not monitored.</p>" +
                        "<p>To view the details of this action request click the link below: <br>" + appUrl + "#/finding?INo=" + FindingNumber + "</p>";
                }
                // sendmail(from,to,body,subject) is defined in app.js
                if ((sendTo !== "") && (body !== "") && (subject !== "")) {
                    sendEmail('no-reply@sharepointonline.com', sendTo, body, subject);
                }
            }
        }, function (err) {
            $scope.showDlgBox = "error";
            $("#errorDlgContent").html("An Error has occurred! Please try for this operation again. If this error persists contact your system administrator. Details on this error can be found in the console log.");
            console.log("Error loading this finding to prepare email notification: " + err);
        });
    }
});