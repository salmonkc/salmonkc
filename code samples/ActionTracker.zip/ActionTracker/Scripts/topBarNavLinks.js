var topBarNavLinks = [];
topBarNavLinks.push({
    name: "Home",
    url: "https://westfraser4.sharepoint.com/"
});
topBarNavLinks.push({
    name: "Safety",
    url: "https://westfraser4.sharepoint.com/safety"
});
topBarNavLinks.push({
    name: "Environmental Systems",
    url: "https://westfraser4.sharepoint.com/EnvironmentalSystems"
});
topBarNavLinks.push({
    name: "Divisions",
    url: "https://westfraser4.sharepoint.com/Divisions"
});
topBarNavLinks.push({
    name: "Applications",
    url: "https://westfraser4.sharepoint.com/Applications"
});
topBarNavLinks.push({
    name: "Tools & Resources",
    url: "https://westfraser4.sharepoint.com/ToolsAndResources"
});
topBarNavLinks.push({
    name: "Employee Centre",
    url: "https://westfraser4.sharepoint.com/EmployeeCentre"
});
topBarNavLinks.push({
    name: "Inside WF",
    url: "https://westfraser4.sharepoint.com/InsideWF"
});