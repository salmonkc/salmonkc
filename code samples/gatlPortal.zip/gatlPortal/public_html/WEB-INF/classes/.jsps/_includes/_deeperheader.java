package _includes;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;


public class _deeperheader extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html;charset=windows-1252");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _deeperheader page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      out.write(__oracle_jsp_text[1]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[2][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "<!-- begin header deeperheader.jsp-->\r\n".toCharArray();
    __oracle_jsp_text[1] = 
    "\r\n<html>\r\n<head>\r\n<META name=\"description\" content=\"The Registrar's Office of Thompson Rivers University in British Columbia / Canada\"> \r\n\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"../../style/style.css\" />\r\n<script src=\"../../javascript/javascript.js\" type=\"text/javascript\"></script>\r\n<title>TRU & TRU-OL Grade and Transcript Lookup Portal</title>\r\n</head>\r\n<body > \r\n<div id=\"contentWrapper\">\r\n\r\n  <!-- logout button floats to the left-->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Exit the System';  return true\" onMouseOut=\"window.status='';\" >\r\n  <span id=\"buttonInnerWrapper\">\r\n  &nbsp;\r\n  <a href=\"../../action/logout.jsp\" ><img src=\"../../images/logout.gif\" Title=\"Exit the System\" Alt=\"Logout\"  />\r\n  <em style=\"color:rgb(0,57,123);\">Logout</em></a></span>\r\n  </div>\r\n  <!-- end logout button -->\r\n  \r\n  <!-- help button floats to the left -->\r\n  <div id=\"buttonOuterWrapper\"  onMouseOver=\"window.status='Get Help'\" onMouseOut=\"window.status='Done'\" onclick=\"window.open('../help.jsp','helpWindow')\">\r\n  <span id=\"buttonInnerWrapper\">\r\n  &nbsp;\r\n   <img src=\"../../images/help.gif\" Title=\"Help for TRU & TRU-OL Grade and Transcript Lookup Portal\" Alt=\"Help for TRU Grade and Transcript Lookup Portal\"/>\r\n   <em style=\"color:rgb(0,57,123);\">&nbsp;Help</em></span>\r\n  </div>\r\n  <!-- end help button -->\r\n   \r\n  <img src=\"../../images/tru_logo.gif\" alt=\"Thompson Rivers University Logo\" height=\"70\" width=\"335\" /> &nbsp; <!--vspace=\"20\"-->\r\n  \r\n  <div style=\"width:100.0%; height:14.0px; padding:0.0px; background-color:rgb(0,57,123);\">\r\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>TRU & TRU-OL Grade and Transcript Lookup Portal</em>\r\n  </div>\r\n \r\n\r\n<!-- end header -->".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
