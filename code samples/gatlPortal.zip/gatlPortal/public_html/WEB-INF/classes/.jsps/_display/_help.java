package _display;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;


public class _help extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html;charset=windows-1252");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _help page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      out.write(__oracle_jsp_text[1]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[2][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "<!-- Help.jsp is the only display file (other than default.jsp) that does not use includes for header and footer --> \r\n".toCharArray();
    __oracle_jsp_text[1] = 
    "\r\n<html>\r\n<head>\r\n<META name=\"description\" content=\"The Registrar's Office of Thompson Rivers University in British Columbia / Canada\"> \r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"../style/style.css\" />\r\n<script src=\"../javascript/javascript.js\" type=\"text/javascript\">\r\n</script>\r\n<script type=\"text/javascript\">\r\nwindow.onload=function() {if(document.getElementById && document.createElement) {initCollapse();}}\r\n</script>\r\n\r\n<title>HELP for TRU & TRU-OL Grade and Transcript Lookup Portal</title>\r\n</head>\r\n\r\n<body>\r\n<div id=\"contentWrapper\">\r\n\r\n  <!-- done button floats to the right -->\r\n  <div id=\"buttonOuterWrapper\" style = \"padding: 0px 45px\" \r\n       onMouseOver=\"window.status='Close this Window';  return true\" onMouseOut=\"window.status='';\" >\r\n  <span id=\"buttonInnerWrapper\">\r\n  &nbsp;\r\n  <button Title=\"Close the Help Window\" onClick=\"window.close();\" \r\n  style=\"cursor:pointer;\" >Close Help</button>\r\n  </span>\r\n  </div>\r\n  <!-- end done button -->\r\n  \r\n  <img src=\"../images/tru_logo.gif\" alt=\"Thompson River University Logo\" height=\"70\" width=\"335\" />\r\n  \r\n  <div style=\"width:100.0%; height:14.0px; padding:0.0px; background-color:rgb(0,57,123);\">\r\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>TRU & TRU-OL Grade and Transcript Lookup Portal</em>\r\n  </div>\r\n <p> This secure on-line system provides a single access point for authorized TRU staff to search for, view and print a student's grade and transcript records from:\r\n           <UL>\r\n           <LI>TRU (formerly <a href=\"http://www.tru.ca\" target=_new>University College of the Cariboo)</a></LI>\r\n            <LI>TRU-Open Learning <a href=\"http://www.bcou.ca\" target=_new>(formerly British Columbia Open University)</a>.</LI>\r\n          </UL></p> \r\n  <p>To use this system, you must receive authorization (user name and password) from The Registrar of\r\n    Thompson Rivers University.\r\n  </p>\r\n  <p>This system retrieves only grade and transcript information for students at TRU and TRU-OL.\r\n  Keep in mind that it is NOT designed to lookup other types of student information nor to change student information.  \r\n  If data retrieved by this system is incorrect, contact the Registrar immediately. \r\n  </P>\r\n  \r\n  <H2 style=\"text-align:center;\">HELP</H2>\r\n <!--start content hide/unhide -->\r\n <dl id=\"content\"> \r\n <div align=\"left\">\r\n     <dt><STRONG>If you require a username and password<a href=\"#\" name=\"Registrar\"> ...contact...</a></STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd></a><PRE>\r\n          Mayberry, Dennis \r\n          Department: Registrar Office: OM1137\r\n          Building: Old Main Building\r\n          Phone: 1-250-828-5043\r\n          E-mail: <a href=\"mailto:dmayberry@tru.ca\">dmayberry@tru.ca</a>\r\n          </PRE>\r\n      </dd>\r\n     \r\n     <dt><STRONG>Search Tips</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd>\r\n      <UL><LI>Keep your search criteria narrow to return accurate and faster results.</LI>\r\n          <LI>If you don't know the student number, search for a specific TRU student or multiple TRU students based on a combination of search criteria.</LI>\r\n          <LI>If your search seems to be taking too long (more than 60 seconds), click the \r\n        <STRONG>Cancel</STRONG> button and start again with more specific search criteria that will search through fewer records and return fewer student records.</LI>\r\n          <LI>Entering the letters SMI will display all records with a last name starting with SMI. For example if you entered SMI and John Smith had a student record at TRU or TRU-OL, it would be displayed.</LI>\r\n          <LI>Entering *JIM will result in all records being displayed which contain the characters JIM. For example if you entered *JIM and Jim Smith had a student record at TRU or TRU-OL, it would be displayed. </LI>\r\n          <LI>A maximum of 200 hits (matches) will be displayed. If your search exceeds this number of hits, the process will be halted and a message will be displayed:  <span id=\"detailsWrapper\">This search will return XXX student records.  This is too many records to process in a timely fashion. </span></LI>\r\n          <LI>The following search criteria are listed from fastest to slowest.&nbsp;&nbsp;The fastest criteria returns fewer records (one student). </LI>   \r\n      </UL>&nbsp;</dd> \r\n      \r\n    <dt><STRONG>Search Criteria: Student Number</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd>\r\n      <UL><LI>This is the quickest and most accurate search criteria to use.</LI>\r\n          <LI>Type the student number into the input box. &nbsp;This will be either\r\n              <UL><LI>&nbsp;&nbsp;&nbsp;7 digit TRU number (formerly University College of the Cariboo)</LI>\r\n                  <LI>&nbsp;&nbsp;&nbsp;9 digit TRU-OL number (formerly BC Open University)</LI>\r\n              </UL>\r\n          </LI>\r\n          <LI>Click the Search Button</LI>\r\n          <LI>The search will&nbsp;result&nbsp;in one student or no results.</LI>\r\n      </UL>&nbsp;</dd>\r\n    \r\n    <dt><STRONG>Search Criteria: Student Name</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd>\r\n      <UL><LI>Type the student names into the first name and last name input boxes. &nbsp;This can be a combination of first and last or first name only or last name only.</LI>\r\n          <LI>Click the Search Button</LI>\r\n          <LI>The search results will result in one or many students. &nbsp;If the name is a common name, the search will take longer and return many more results.</LI>\r\n      </UL>&nbsp;</dd>\r\n      \r\n    <dt><STRONG>Search Criteria: Country/Province</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>Searching by country or country/province may potentially return too many records to be efficient. \r\n      In general, try to use in combination with other search criteria where possible.\r\n      </ul>&nbsp;</dd>\r\n      \r\n    <dt><STRONG>Search Criteria: City</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n     <dd><ul><li>Searching by city with province/country may potentially return too many records to be efficient. </li>\r\n             <li>In general, try to use city in combination with other search criteria where possible.</li></ul>&nbsp;</dd>\r\n    \r\n    <dt><STRONG>Message:  No Student found</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n     <dd><ul><li>The search criteria entered did not match with any of the students registered at TRU or TRU-OL.</li> \r\n             <li>Ensure  you have entered accurate data for the student.</li></ul>&nbsp;</dd>\r\n      \r\n    <dt><STRONG>Message: One Student Found</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>The search criteria resulted in one student match which is what this system is designed to return.</li></ul> &nbsp;</dd>\r\n      \r\n    <dt><STRONG>Message: Possible Student Matches...</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>The search criteria resulted in two or more possible matches for the student. </li>\r\n              <li>This means that there are possible duplicate student records in the system. </li> \r\n              <li>Review the data returned and choose the closest match.  </li>\r\n              <li>If possible, verify data details with the student to ensure the correct match.</li></ul>&nbsp;</dd>\r\n     \r\n    <dt><STRONG>Message:  Too Many Students...</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>The search criteria entered will result in too many student records to be efficient. </li>\r\n              <li>This means the process has been halted to avoid crashing or slowing down the entire system.</li>\r\n              <li>Return to the search criteria window and be more specific. </li></ul>&nbsp;</dd>\r\n\r\n    <dt><STRONG>Message: You have not entered any search criteria.  </STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>You cannot perform a search for students without inputting data into at least one search field.</li>\r\n              <li>A wide open search would result in the return of all student records and the process will be halted automatically.</li></ul>&nbsp;</dd>\r\n\r\n    <dt><STRONG>Change Password </STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>If you are the Registrar of TRU and TRU-OL or an authorized administrator of this system, <a href=\"changePassword.jsp\">click here</a> to change password.  </li>\r\n              <li> Otherwise, contact the <a href=\"#Registrar\">Registrar</a>.</li></ul>&nbsp;</dd>\r\n    <dt><STRONG>User Feedback</STRONG><span id=\"detailsWrapper\">[Details]</span></dt>\r\n      <dd><ul><li>Please provide your feedback on the Grade and Transcript Lookup Portal to \r\n                    <a href=\"mailto:AISInfo@tru.ca\">AISInfo@tru.ca</a> </li>\r\n          </ul>&nbsp;</dd>\r\n\r\n</dl>\r\n</div>\r\n \r\n \r\n <!-- outer div -->\r\n</div>\r\n\r\n<p>Copyright &copy; Thompson Rivers University 2005 <a href=\"http://www.tru.ca/disclaimer.html\">Legal Information & Terms of Use</a>&nbsp;&nbsp;&nbsp;\r\n\r\n</body>\r\n</html>\r\n".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
