package _display;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import ca.tru.gatlPortal.*;


public class _colTrans extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _colTrans page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      
      // check login Status
      // **********************************************************************
      String LoggedIn;
      LoggedIn = "" + (String)session.getAttribute("Login");
      if (!(LoggedIn.equalsIgnoreCase("True")))
          response.sendRedirect("../default.jsp?msg=2");
      // **********************************************************************
      
      out.write(__oracle_jsp_text[1]);
      
        String StudID = new String(request.getParameter("StudID"));
        String Type = new String(request.getParameter("Type"));
      
      out.write(__oracle_jsp_text[2]);
      
               colTran Colleague = new colTran();
               out.print("<PRE>" + Colleague.getTranscript(StudID, Type) + "</PRE>"); 
            
      out.write(__oracle_jsp_text[3]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[4][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "\r\n".toCharArray();
    __oracle_jsp_text[1] = 
    "\r\n\r\n".toCharArray();
    __oracle_jsp_text[2] = 
    "\r\n<html>\r\n<head>\r\n<title></title>\r\n<style type=\"text/css\">\r\n  pre{font-size:9.5;}\r\n</style>\r\n</head>\r\n<body>\r\n<Center><p>&nbsp;</p>\r\n<table width=\"660\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n  <tr>\r\n    <td>\r\n      ".toCharArray();
    __oracle_jsp_text[3] = 
    "\r\n    </td>\r\n  </tr>\r\n</table>\r\n</center>\r\n</body>\r\n</html>".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
