package _display;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;


public class _whichStudent extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html;charset=windows-1252");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _whichStudent page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      out.write("");
      out.write(__oracle_jsp_text[1]);
      out.write(__oracle_jsp_text[2]);
      out.write(__oracle_jsp_text[3]);
      
      // check login Status
      // **********************************************************************
      String LoggedIn;
      LoggedIn = "" + (String)session.getAttribute("Login");
      if (!(LoggedIn.equalsIgnoreCase("True")))
          response.sendRedirect("../default.jsp?msg=2");
      // **********************************************************************
      
      out.write(__oracle_jsp_text[4]);
       String[] Rows, Fields;
           String outString;
           int low_i, high_i;  // index
           int prev_low, prev_high, next_low, next_high, rCount;  // navigation
           
           // initalize vars
           String low = "" + request.getParameter("low_i"); // this convert null to String "null"
           String high = "" + request.getParameter("high_i"); // this convert null to String "null"
           rCount = Integer.parseInt((String)session.getAttribute("RowCount"));
           if (low.equals("null"))     
               low = "0";
           if (high.equals("null"))     
               high = low;    
           low_i = Integer.parseInt(low);  // convert low String to int
           high_i = Integer.parseInt(high);  // convert low String to int
      
      out.write(__oracle_jsp_text[5]);
      out.print( low_i);
      out.write(__oracle_jsp_text[6]);
      out.print(high_i);
      out.write(__oracle_jsp_text[7]);
      out.print(rCount);
      out.write(__oracle_jsp_text[8]);
           
          // navigation
          if (rCount > 10)
          {
            if ((high_i + 10) > rCount)
            {
              next_high = rCount;
              next_low = high_i;
              prev_high = low_i;
              prev_low = low_i - 10;
            }  
            else
            {
              next_high = high_i + 10;
              next_low = high_i;
              prev_high = low_i;
              prev_low = low_i - 10;
            }  
          
      out.write(__oracle_jsp_text[9]);
       if (prev_low >= 0){
      out.write(__oracle_jsp_text[10]);
      out.print( prev_low);
      out.write(__oracle_jsp_text[11]);
      out.print( prev_high - 1);
      out.write(__oracle_jsp_text[12]);
      }
      out.write(__oracle_jsp_text[13]);
       if ((prev_low >= 0) && (!(next_low == next_high))){
      out.write(__oracle_jsp_text[14]);
      }
      out.write(__oracle_jsp_text[15]);
       if (!(next_low == next_high)){
      out.write(__oracle_jsp_text[16]);
      out.print( next_low + 1);
      out.write(__oracle_jsp_text[17]);
      out.print( next_high);
      out.write(__oracle_jsp_text[18]);
      out.print( ((rCount - (rCount % 10)) + 1));
      out.write(__oracle_jsp_text[19]);
      out.print( rCount);
      out.write(__oracle_jsp_text[20]);
      }
      out.write(__oracle_jsp_text[21]);
      }
      out.write(__oracle_jsp_text[22]);
      
          // output list of student  
           outString = "" + (String)session.getAttribute("AllRows");
           Rows = outString.split("\n");
           
           for (int i=low_i; i < high_i + 1; i++)
           {
             Fields = Rows[i].split("\\|"); 
             for (int J = 0; J < Fields.length; J++)
             {
               if (Fields[J].equals("null"))
                 Fields[J] = " ";
             }    
        
      out.write(__oracle_jsp_text[23]);
      out.print( Fields[0]);
      out.write(__oracle_jsp_text[24]);
      out.print( Fields[0]);
      out.write(__oracle_jsp_text[25]);
      out.print( Fields[6] );
      out.write(__oracle_jsp_text[26]);
      out.print( Fields[8] );
      out.write(__oracle_jsp_text[27]);
      out.print( Fields[6]);
      out.write(__oracle_jsp_text[28]);
      out.print( Fields[8]);
      out.write(__oracle_jsp_text[29]);
      
                   if (Fields[2].length()==9)
                      out.println("TRU-OL Student No: " + Fields[2] + "<br>"); 
                   if (Fields[1].length()==7)
                   {
                      out.println("TRU Student No: " + Fields[1]);
                      out.println("<input type=\"hidden\" name=\"id\" value=\"" + Fields[1] +"\"/>");        
                   }
                   else
                      out.println("<input type=\"hidden\" name=\"id\" value=\"" + Fields[2] +"\"/>");
                  
      out.write(__oracle_jsp_text[30]);
      out.print( Fields[11] );
      out.write(__oracle_jsp_text[31]);
      out.print( Fields[11]);
      out.write(__oracle_jsp_text[32]);
      out.print( Fields[13] );
      out.write(__oracle_jsp_text[33]);
      out.print( Fields[13]);
      out.write(__oracle_jsp_text[34]);
      out.print( Fields[14] );
      out.write(__oracle_jsp_text[35]);
      out.print( Fields[14]);
      out.write(__oracle_jsp_text[36]);
      out.print( Fields[15] );
      out.write(__oracle_jsp_text[37]);
      out.print( Fields[15]);
      out.write(__oracle_jsp_text[38]);
      out.print( Fields[16].toUpperCase() );
      out.write(__oracle_jsp_text[39]);
      out.print( Fields[16]);
      out.write(__oracle_jsp_text[40]);
      }
      out.write(__oracle_jsp_text[41]);
      
          // navagation
          if (rCount > 10)
          {
            if ((high_i + 10) > rCount)
            {
              next_high = rCount;
              next_low = high_i;
              prev_high = low_i;
              prev_low = low_i - 10;
            }  
            else
            {
              next_high = high_i + 10;
              next_low = high_i;
              prev_high = low_i;
              prev_low = low_i - 10;
            }  
          
      out.write(__oracle_jsp_text[42]);
      out.print( low_i);
      out.write(__oracle_jsp_text[43]);
      out.print(high_i);
      out.write(__oracle_jsp_text[44]);
      out.print(rCount);
      out.write(__oracle_jsp_text[45]);
       if (prev_low >= 0){
      out.write(__oracle_jsp_text[46]);
      out.print( prev_low);
      out.write(__oracle_jsp_text[47]);
      out.print( prev_high - 1);
      out.write(__oracle_jsp_text[48]);
      }
      out.write(__oracle_jsp_text[49]);
       if ((prev_low >= 0) && (!(next_low == next_high))){
      out.write(__oracle_jsp_text[50]);
      }
      out.write(__oracle_jsp_text[51]);
       if (!(next_low == next_high)){
      out.write(__oracle_jsp_text[52]);
      out.print( next_low + 1);
      out.write(__oracle_jsp_text[53]);
      out.print( next_high);
      out.write(__oracle_jsp_text[54]);
      out.print( ((rCount - (rCount % 10)) + 1));
      out.write(__oracle_jsp_text[55]);
      out.print( rCount);
      out.write(__oracle_jsp_text[56]);
      }
      out.write(__oracle_jsp_text[57]);
      }
      out.write(__oracle_jsp_text[58]);
      out.write("");
      out.write(__oracle_jsp_text[59]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[60][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "  <!-- include header -->\r\n".toCharArray();
    __oracle_jsp_text[1] = 
    "<!-- begin header header.jsp-->\r\n".toCharArray();
    __oracle_jsp_text[2] = 
    "\r\n<html>\r\n<head>\r\n<META name=\"description\" content=\"The Registrar's Office of Thompson Rivers University in British Columbia / Canada\"> \r\n\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"../style/style.css\" />\r\n<script src=\"../javascript/javascript.js\" type=\"text/javascript\"></script>\r\n<title>TRU & TRU-OL Grade and Transcript Lookup Portal</title>\r\n</head>\r\n<body > \r\n<div id=\"contentWrapper\">\r\n\r\n  <!-- logout button floats to the left-->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Exit the System';  return true\" onMouseOut=\"window.status='';\" >\r\n    <span id=\"buttonInnerWrapper\">&nbsp;\r\n      <a href=\"../action/logout.jsp\" target=\"_parent\"><img src=\"../images/logout.gif\" Title=\"Exit the System\" Alt=\"Logout\"/>\r\n      <em style=\"color:rgb(0,57,123);\">Logout</em></a>\r\n    </span>\r\n  </div>\r\n  <!-- end logout button -->\r\n  \r\n  <!-- help button floats to the left -->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Get Help'\" \r\n     onMouseOut=\"window.status='Done'\" onclick=\"window.open('help.jsp','helpWindow')\">\r\n    <span id=\"buttonInnerWrapper\">&nbsp;\r\n      <img src=\"../images/help.gif\" Title=\"Help for TRU & TRU-OL Grade and Transcript Lookup Portal\" \r\n          Alt=\"Help for TRU Grade and Transcript Lookup Portal\" />\r\n      <em style=\"color:rgb(0,57,123);\">&nbsp;Help</em>\r\n    </span>\r\n  </div>\r\n  <!-- end help button -->\r\n   \r\n  <img src=\"../images/tru_logo.gif\" alt=\"Thompson Rivers University Logo\" height=\"70\" width=\"335\" /> &nbsp; <!--vspace=\"20\"-->\r\n  \r\n  <div style=\"width:100.0%; height:14.0px; padding:0.0px; background-color:rgb(0,57,123);\">\r\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>TRU & TRU-OL Grade and Transcript Lookup Portal</em>\r\n  </div>\r\n \r\n\r\n<!-- end header -->".toCharArray();
    __oracle_jsp_text[3] = 
    "\r\n\r\n".toCharArray();
    __oracle_jsp_text[4] = 
    "\r\n\r\n  ".toCharArray();
    __oracle_jsp_text[5] = 
    "     \r\n     <table border=\"0\" cellpadding=\"0\" cellspacing=\"5\" ALIGN=\"CENTER\" WIDTH=\"100%\">\r\n      <tr>\r\n        <td>".toCharArray();
    __oracle_jsp_text[6] = 
    " to ".toCharArray();
    __oracle_jsp_text[7] = 
    " of ".toCharArray();
    __oracle_jsp_text[8] = 
    "</td>\r\n        <td align=\"right\">\r\n".toCharArray();
    __oracle_jsp_text[9] = 
    "\r\n          ".toCharArray();
    __oracle_jsp_text[10] = 
    "\r\n            <a href=\"../display/whichStudent.jsp?low_i=1&high_i=10\">&lt;&lt; First </a>&nbsp;|&nbsp;\r\n            <a href=\"../display/whichStudent.jsp?low_i=".toCharArray();
    __oracle_jsp_text[11] = 
    "&high_i=".toCharArray();
    __oracle_jsp_text[12] = 
    "\">&lt; Previous </a>\r\n          ".toCharArray();
    __oracle_jsp_text[13] = 
    " \r\n          ".toCharArray();
    __oracle_jsp_text[14] = 
    "\r\n            &nbsp;|&nbsp;\r\n          ".toCharArray();
    __oracle_jsp_text[15] = 
    "  \r\n          ".toCharArray();
    __oracle_jsp_text[16] = 
    "  \r\n            <a href=\"../display/whichStudent.jsp?low_i=".toCharArray();
    __oracle_jsp_text[17] = 
    "&high_i=".toCharArray();
    __oracle_jsp_text[18] = 
    "\">Next > </a>&nbsp;|&nbsp;  \r\n            <a href=\"../display/whichStudent.jsp?low_i=".toCharArray();
    __oracle_jsp_text[19] = 
    "&high_i=".toCharArray();
    __oracle_jsp_text[20] = 
    "\">Last >></a>\r\n          ".toCharArray();
    __oracle_jsp_text[21] = 
    "\r\n  ".toCharArray();
    __oracle_jsp_text[22] = 
    "\r\n      <br><br>[ <a href=\"searchCriteria.jsp\">New Search</a> ]\r\n  </td>\r\n      </tr>\r\n    </table>\r\n  <p>&nbsp;</p>\r\n  ".toCharArray();
    __oracle_jsp_text[23] = 
    "\r\n  \r\n  <form name=\"Form_".toCharArray();
    __oracle_jsp_text[24] = 
    "\"  method=\"POST\" action=\"../findStudent\">\r\n  <TABLE border=\"0\" cellpadding=\"0\" cellspacing=\"5\" ALIGN=\"CENTER\" WIDTH=\"550\">\r\n    <TR><TD colspan=\"3\" background=\"../images/dots.gif\" height=\"5\"></TD></TR>\r\n    <TR><TD rowspan=\"3\" width=\"25\"><!-- spacer --></TD></TR>\r\n    <TR>\r\n      <TD width=\"45%\">\r\n          <h2><a href=\"javaScript:document.Form_".toCharArray();
    __oracle_jsp_text[25] = 
    ".submit();\">\r\n              <b>".toCharArray();
    __oracle_jsp_text[26] = 
    "&nbsp;".toCharArray();
    __oracle_jsp_text[27] = 
    "</a>\r\n              <input type=\"hidden\" name=\"FName\" value=\"".toCharArray();
    __oracle_jsp_text[28] = 
    "\"/>\r\n              <input type=\"hidden\" name=\"LName\" value=\"".toCharArray();
    __oracle_jsp_text[29] = 
    "\"/>\r\n          </b></h2>\r\n      </TD>\r\n      <TD><input type=\"submit\" value=\"Details\"></TD>\r\n    </TR>\r\n    <TR>\r\n      <TD colspan=\"2\">\r\n        <b>".toCharArray();
    __oracle_jsp_text[30] = 
    "<br><br>\r\n            ".toCharArray();
    __oracle_jsp_text[31] = 
    "<input type=\"hidden\" name=\"AddressLine1\" value=\"".toCharArray();
    __oracle_jsp_text[32] = 
    "\"/><br>\r\n            ".toCharArray();
    __oracle_jsp_text[33] = 
    "<input type=\"hidden\" name=\"City\" value=\"".toCharArray();
    __oracle_jsp_text[34] = 
    "\"/>,&nbsp;\r\n            ".toCharArray();
    __oracle_jsp_text[35] = 
    "<input type=\"hidden\" name=\"Province\" value=\"".toCharArray();
    __oracle_jsp_text[36] = 
    "\"/>&nbsp;&nbsp;\r\n            ".toCharArray();
    __oracle_jsp_text[37] = 
    "<input type=\"hidden\" name=\"PostalCode\" value=\"".toCharArray();
    __oracle_jsp_text[38] = 
    "\"/><br>\r\n            ".toCharArray();
    __oracle_jsp_text[39] = 
    "<input type=\"hidden\" name=\"Country\" value=\"".toCharArray();
    __oracle_jsp_text[40] = 
    "\"/>\r\n            <input type=\"hidden\" name=\"ProvinceNA\" value=\"\"/>\r\n        </b>\r\n      </TD>\r\n    </TR>  \r\n  </TABLE>\r\n  </form>\r\n  ".toCharArray();
    __oracle_jsp_text[41] = 
    "\r\n  <TABLE border=\"0\" cellpadding=\"0\" cellspacing=\"5\" ALIGN=\"CENTER\" WIDTH=\"550\">\r\n    <TR><TD background=\"../images/dots.gif\" height=\"5\"></TD></TR>\r\n  </TABLE>\r\n  ".toCharArray();
    __oracle_jsp_text[42] = 
    "\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"5\" ALIGN=\"CENTER\" WIDTH=\"100%\">\r\n      <tr>\r\n        <td>".toCharArray();
    __oracle_jsp_text[43] = 
    " to ".toCharArray();
    __oracle_jsp_text[44] = 
    " of ".toCharArray();
    __oracle_jsp_text[45] = 
    "</td>\r\n        <td align=\"right\">\r\n          ".toCharArray();
    __oracle_jsp_text[46] = 
    "\r\n            <a href=\"../display/whichStudent.jsp?low_i=1&high_i=10\">&lt;&lt; First </a>&nbsp;|&nbsp;\r\n            <a href=\"../display/whichStudent.jsp?low_i=".toCharArray();
    __oracle_jsp_text[47] = 
    "&high_i=".toCharArray();
    __oracle_jsp_text[48] = 
    "\">&lt; Previous </a>\r\n          ".toCharArray();
    __oracle_jsp_text[49] = 
    " \r\n          ".toCharArray();
    __oracle_jsp_text[50] = 
    "\r\n            &nbsp;|&nbsp;\r\n          ".toCharArray();
    __oracle_jsp_text[51] = 
    "  \r\n          ".toCharArray();
    __oracle_jsp_text[52] = 
    "  \r\n            <a href=\"../display/whichStudent.jsp?low_i=".toCharArray();
    __oracle_jsp_text[53] = 
    "&high_i=".toCharArray();
    __oracle_jsp_text[54] = 
    "\">Next > </a>&nbsp;|&nbsp;  \r\n            <a href=\"../display/whichStudent.jsp?low_i=".toCharArray();
    __oracle_jsp_text[55] = 
    "&high_i=".toCharArray();
    __oracle_jsp_text[56] = 
    "\">Last >></a>\r\n          ".toCharArray();
    __oracle_jsp_text[57] = 
    "\r\n          <br><br>[ <a href=\"searchCriteria.jsp\">New Search</a> ]\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  ".toCharArray();
    __oracle_jsp_text[58] = 
    " \r\n  <p>&nbsp;</p>\r\n\r\n  <!-- include footer -->\r\n".toCharArray();
    __oracle_jsp_text[59] = 
    "<!-- begin footer -->\r\n</div>\r\n<p>Copyright &copy; Thompson Rivers University 2005 <a href=\"http://www.tru.ca/disclaimer.html\">Legal Information & Terms of Use</a>&nbsp;&nbsp;&nbsp;\r\n</body>\r\n</html>\r\n<!-- end footer -->".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
