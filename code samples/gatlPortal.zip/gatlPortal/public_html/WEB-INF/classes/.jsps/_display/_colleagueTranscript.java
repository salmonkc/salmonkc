package _display;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.tru.connectionserver.server.*;


public class _colleagueTranscript extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _colleagueTranscript page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      
      // check login Status
      // **********************************************************************
      String LoggedIn;
      LoggedIn = "" + (String)session.getAttribute("Login");
      if (!(LoggedIn.equalsIgnoreCase("True")))
          response.sendRedirect("../default.jsp?msg=2");
      // **********************************************************************
      
      out.write(__oracle_jsp_text[1]);
      
        String StudID = new String(request.getParameter("StudID"));
        String Type = new String(request.getParameter("Type"));
      
      out.write(__oracle_jsp_text[2]);
      out.print(StudID);
      out.write(__oracle_jsp_text[3]);
      out.print(Type);
      out.write(__oracle_jsp_text[4]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[5][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "\r\n".toCharArray();
    __oracle_jsp_text[1] = 
    "\r\n\r\n".toCharArray();
    __oracle_jsp_text[2] = 
    "\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n<title>TRU & TRU-OL Grade and Transcript Lookup Portal</title>\r\n<FRAMESET rows=\"225, *\">\r\n      <FRAME src=\"colTop.jsp\" name=\"top\" scrolling=\"no\">\r\n      <FRAME src=\"colTrans.jsp?StudID=".toCharArray();
    __oracle_jsp_text[3] = 
    "&Type=".toCharArray();
    __oracle_jsp_text[4] = 
    "\" name=\"trans\">\r\n</FRAMESET>\r\n</html>".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
