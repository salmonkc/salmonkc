package _display;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;


public class _student extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html;charset=windows-1252");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _student page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      out.write("");
      out.write(__oracle_jsp_text[1]);
      out.write(__oracle_jsp_text[2]);
      out.write(__oracle_jsp_text[3]);
      out.write(__oracle_jsp_text[4]);
      
      // check login Status
      // **********************************************************************
      String LoggedIn;
      LoggedIn = "" + (String)session.getAttribute("Login");
      if (!(LoggedIn.equalsIgnoreCase("True")))
          response.sendRedirect("../default.jsp?msg=2");
      // **********************************************************************
      
      out.write(__oracle_jsp_text[5]);
      
          String[] Rows, Fields;
          String outString;
          
          outString = "" + session.getAttribute("outString");
          Rows = outString.split("\n");
          Fields = Rows[1].split("\\|");
          for (int J = 0; J < Fields.length; J++)
          {
            if (Fields[J].equals("null"))
              Fields[J] = " ";
          } 
        
      out.write(__oracle_jsp_text[6]);
      out.print( Fields[6] );
      out.write(__oracle_jsp_text[7]);
      out.print( Fields[7]);
      out.write(__oracle_jsp_text[8]);
      out.print( Fields[8] );
      out.write(__oracle_jsp_text[9]);
      out.print( Fields[11] );
      out.write(__oracle_jsp_text[10]);
      out.print( Fields[13] );
      out.write(__oracle_jsp_text[11]);
      out.print( Fields[14] );
      out.write(__oracle_jsp_text[12]);
      out.print( Fields[15] );
      out.write(__oracle_jsp_text[13]);
       if (Fields[10].length()> 10)
                 {
                   out.print("<br>Birthdate: " + Fields[10].substring(0,10) + "<br>");
                 }
                 else
                 {
                   out.print("<br>Birthdate: N/A<br>");
                 }
                  
      out.write(__oracle_jsp_text[14]);
      
                if (Fields[2].length()==9)
                  out.println("TRU-OL Student No: " + Fields[2] + "<br>"); 
                if (Fields[1].length()==7)
                {
                  out.println("TRU Student No: " + Fields[1]);
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + Fields[1] +"\"/>");        
                }
                else
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + Fields[2] +"\"/>");
              
      out.write(__oracle_jsp_text[15]);
      
              if (Fields[1].length()==7) //target=\"_BLANK\" 
                 out.print("|&nbsp; <a href =\"colleagueTranscript.jsp?StudID=" + Fields[1] + 
                             "&Type=OT\" onclick=\"javascript:flashing();\">TRU Full Transcript</a>&nbsp; |" +
                          "&nbsp; <a href =\"colleagueTranscript.jsp?StudID=" + Fields[1] + 
                             "&Type=AC\" onclick=\"javascript:flashing();\">TRU Academic Course Transcript</a>&nbsp;");
               if (Fields[2].length()==9)
                 out.print("|&nbsp; <a href =\"bannerGrades.jsp?StudID=" + Fields[2] + 
                              "&Type=" + Fields[5] + "\" onclick=\"javascript:flashing();\">TRU-OL Course & Grade Record</a>&nbsp;");                     
             
      out.write(__oracle_jsp_text[16]);
      
          String[] PossibleMatch;
          String PossibleMatches;
          
          PossibleMatches = "" + (String)session.getAttribute("PossibleMatch");
          PossibleMatch = PossibleMatches.split("\n");
          
          if (PossibleMatch.length > 1) // length of only 4 is 'null'
          {
             out.println("</TD></TR><tr><td><TABLE border='0' Width='550' align='center'>" + 
                  "<h2>The following is a list of possible matching Student Records</h2>");
              out.print( "</TD></TR></TABLE><p>&nbsp;</p>");       
          }
          // output list of possible matching student records       
          for (int I = 1; I < PossibleMatch.length; I++)
          {
             Fields = PossibleMatch[I].split("\\|");
             if (Fields.length > 1)
             {    
             for (int J = 0; J < Fields.length; J++)
             {
               if (Fields[J].equals("null"))
                 Fields[J] = " ";
             } 
             
      out.write(__oracle_jsp_text[17]);
      out.print( Fields[0]);
      out.write(__oracle_jsp_text[18]);
      out.print( Fields[0]);
      out.write(__oracle_jsp_text[19]);
      out.print( Fields[6] );
      out.write(__oracle_jsp_text[20]);
      out.print( Fields[7]);
      out.write(__oracle_jsp_text[21]);
      out.print( Fields[8] );
      out.write(__oracle_jsp_text[22]);
      out.print( Fields[6]);
      out.write(__oracle_jsp_text[23]);
      out.print( Fields[8]);
      out.write(__oracle_jsp_text[24]);
      
                          if (Fields[2].length()==9)
                             out.println("TRU-OL Student ID: " + Fields[2] + "<br>"); 
                          if (Fields[1].length()==7)
                          {
                             out.println("TRU Student ID: " + Fields[1]);
                             out.println("<input type=\"hidden\" name=\"id\" value=\"" + Fields[1] +"\"/>");        
                          }
                          else
                             out.println("<input type=\"hidden\" name=\"id\" value=\"" + Fields[2] +"\"/>");
                         
      out.write(__oracle_jsp_text[25]);
      out.print( Fields[11] );
      out.write(__oracle_jsp_text[26]);
      out.print( Fields[11]);
      out.write(__oracle_jsp_text[27]);
      out.print( Fields[13] );
      out.write(__oracle_jsp_text[28]);
      out.print( Fields[13]);
      out.write(__oracle_jsp_text[29]);
      out.print( Fields[14] );
      out.write(__oracle_jsp_text[30]);
      out.print( Fields[14]);
      out.write(__oracle_jsp_text[31]);
      out.print( Fields[15] );
      out.write(__oracle_jsp_text[32]);
      out.print( Fields[15]);
      out.write(__oracle_jsp_text[33]);
      out.print( Fields[16].toUpperCase() );
      out.write(__oracle_jsp_text[34]);
      out.print( Fields[16]);
      out.write(__oracle_jsp_text[35]);
       if (Fields[10].length()> 10)
                            {
                              out.print("<br>Birthdate: " + Fields[10].substring(0,10) + "<br>");
                            }
                            else
                            {
                              out.print("<br>Birthdate: N/A<br>");
                            }
                         
      out.write(__oracle_jsp_text[36]);
      
                                       if (Fields[21].equals("3")) 
                                         out.print("Low");
                                       else
                                         out.print("Moderate");
                                       
      out.write(__oracle_jsp_text[37]);
      
             }
      out.write(__oracle_jsp_text[38]);
      
          }
        
      out.write(__oracle_jsp_text[39]);
      out.write("");
      out.write(__oracle_jsp_text[40]);
      out.write(__oracle_jsp_text[41]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[42][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "  <!-- include header -->\n".toCharArray();
    __oracle_jsp_text[1] = 
    "<!-- begin header header.jsp-->\r\n".toCharArray();
    __oracle_jsp_text[2] = 
    "\r\n<html>\r\n<head>\r\n<META name=\"description\" content=\"The Registrar's Office of Thompson Rivers University in British Columbia / Canada\"> \r\n\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"../style/style.css\" />\r\n<script src=\"../javascript/javascript.js\" type=\"text/javascript\"></script>\r\n<title>TRU & TRU-OL Grade and Transcript Lookup Portal</title>\r\n</head>\r\n<body > \r\n<div id=\"contentWrapper\">\r\n\r\n  <!-- logout button floats to the left-->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Exit the System';  return true\" onMouseOut=\"window.status='';\" >\r\n    <span id=\"buttonInnerWrapper\">&nbsp;\r\n      <a href=\"../action/logout.jsp\" target=\"_parent\"><img src=\"../images/logout.gif\" Title=\"Exit the System\" Alt=\"Logout\"/>\r\n      <em style=\"color:rgb(0,57,123);\">Logout</em></a>\r\n    </span>\r\n  </div>\r\n  <!-- end logout button -->\r\n  \r\n  <!-- help button floats to the left -->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Get Help'\" \r\n     onMouseOut=\"window.status='Done'\" onclick=\"window.open('help.jsp','helpWindow')\">\r\n    <span id=\"buttonInnerWrapper\">&nbsp;\r\n      <img src=\"../images/help.gif\" Title=\"Help for TRU & TRU-OL Grade and Transcript Lookup Portal\" \r\n          Alt=\"Help for TRU Grade and Transcript Lookup Portal\" />\r\n      <em style=\"color:rgb(0,57,123);\">&nbsp;Help</em>\r\n    </span>\r\n  </div>\r\n  <!-- end help button -->\r\n   \r\n  <img src=\"../images/tru_logo.gif\" alt=\"Thompson Rivers University Logo\" height=\"70\" width=\"335\" /> &nbsp; <!--vspace=\"20\"-->\r\n  \r\n  <div style=\"width:100.0%; height:14.0px; padding:0.0px; background-color:rgb(0,57,123);\">\r\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>TRU & TRU-OL Grade and Transcript Lookup Portal</em>\r\n  </div>\r\n \r\n\r\n<!-- end header -->".toCharArray();
    __oracle_jsp_text[3] = 
    "\n".toCharArray();
    __oracle_jsp_text[4] = 
    "\n\n".toCharArray();
    __oracle_jsp_text[5] = 
    "\n\n  ".toCharArray();
    __oracle_jsp_text[6] = 
    "\n  <table align=\"right\" border=0><tr><td>[ <a href=\"searchCriteria.jsp\">New Search</a> ]</td></tr></table>\n  <p>&nbsp;</p>\n  <TABLE border=\"0\" cellpadding=\"0\" cellspacing=\"0\" ALIGN=\"CENTER\" WIDTH=\"550\">\n    <TR>\n      <TD>\n        <h2>".toCharArray();
    __oracle_jsp_text[7] = 
    "&nbsp;".toCharArray();
    __oracle_jsp_text[8] = 
    "&nbsp;".toCharArray();
    __oracle_jsp_text[9] = 
    "<br>\n        ".toCharArray();
    __oracle_jsp_text[10] = 
    "<br>\n        ".toCharArray();
    __oracle_jsp_text[11] = 
    ",&nbsp;".toCharArray();
    __oracle_jsp_text[12] = 
    "&nbsp;&nbsp;".toCharArray();
    __oracle_jsp_text[13] = 
    "<BR>\n        ".toCharArray();
    __oracle_jsp_text[14] = 
    "<br></h2><h3>\n        ".toCharArray();
    __oracle_jsp_text[15] = 
    "</h3>\n      <TD>\n    </TR>\n    <TR><TD><p>&nbsp;</p>\n      ".toCharArray();
    __oracle_jsp_text[16] = 
    " |  <h3 style=\"text-align: right;\">[ <a href=\"javascript:history.go(-1)\">Back</a> ]</h3>              \n            <h2><div id=\"ProcessingMsg\" align=\"center\" style='color: #FF0000; visibility:hidden'>\n                <b>Processing Request - Please Wait</b>\n            </div></h2>\n    \n  <p>&nbsp;</p>\n  ".toCharArray();
    __oracle_jsp_text[17] = 
    "\n       <form name=\"Form_".toCharArray();
    __oracle_jsp_text[18] = 
    "\"  method=\"POST\" action=\"../findStudent\">\n       <TABLE border=\"0\" cellpadding=\"0\" cellspacing=\"5\" ALIGN=\"CENTER\" WIDTH=\"550\">\n         <TR><TD colspan=\"3\" background=\"../images/dots.gif\" height=\"5\"></TD></TR>\n         <TR><TD rowspan=\"3\" width=\"25\"><!-- spacer --></TD></TR>\n         <TR>\n           <TD width=\"45%\">\n               <h3><a href=\"javaScript:document.Form_".toCharArray();
    __oracle_jsp_text[19] = 
    ".submit();\">\n                   ".toCharArray();
    __oracle_jsp_text[20] = 
    "&nbsp;".toCharArray();
    __oracle_jsp_text[21] = 
    "&nbsp;".toCharArray();
    __oracle_jsp_text[22] = 
    "</a>\n                 <input type=\"hidden\" name=\"FName\" value=\"".toCharArray();
    __oracle_jsp_text[23] = 
    "\"/>\n                 <input type=\"hidden\" name=\"LName\" value=\"".toCharArray();
    __oracle_jsp_text[24] = 
    "\"/>\n               </h3>\n           </TD>\n           <TD align=\"Right\" vAlign=\"Bottom\"><input type=\"submit\" value=\"Details\"></TD>\n         </TR>\n         <TR>\n           <TD colspan=\"2\">\n               ".toCharArray();
    __oracle_jsp_text[25] = 
    "<br><br>\n                   ".toCharArray();
    __oracle_jsp_text[26] = 
    "<input type=\"hidden\" name=\"AddressLine1\" value=\"".toCharArray();
    __oracle_jsp_text[27] = 
    "\"/><br>\n                   ".toCharArray();
    __oracle_jsp_text[28] = 
    "<input type=\"hidden\" name=\"City\" value=\"".toCharArray();
    __oracle_jsp_text[29] = 
    "\"/>,&nbsp;\n                   ".toCharArray();
    __oracle_jsp_text[30] = 
    "<input type=\"hidden\" name=\"Province\" value=\"".toCharArray();
    __oracle_jsp_text[31] = 
    "\"/>&nbsp;&nbsp;\n                   ".toCharArray();
    __oracle_jsp_text[32] = 
    "<input type=\"hidden\" name=\"PostalCode\" value=\"".toCharArray();
    __oracle_jsp_text[33] = 
    "\"/><br>\n                   ".toCharArray();
    __oracle_jsp_text[34] = 
    "<input type=\"hidden\" name=\"Country\" value=\"".toCharArray();
    __oracle_jsp_text[35] = 
    "\"/><br>\n                   <input type=\"hidden\" name=\"ProvinceNA\" value=\"\"/>\n                   ".toCharArray();
    __oracle_jsp_text[36] = 
    "<br>\n                   Confidence: ".toCharArray();
    __oracle_jsp_text[37] = 
    "\n           </TD>\n         </TR>\n       </TABLE>\n       </form>\n     ".toCharArray();
    __oracle_jsp_text[38] = 
    "\n  ".toCharArray();
    __oracle_jsp_text[39] = 
    "\n  </TD></TR>\n  </TABLE><p>&nbsp;</p>\n  <!-- include footer -->\n".toCharArray();
    __oracle_jsp_text[40] = 
    "<!-- begin footer -->\r\n</div>\r\n<p>Copyright &copy; Thompson Rivers University 2005 <a href=\"http://www.tru.ca/disclaimer.html\">Legal Information & Terms of Use</a>&nbsp;&nbsp;&nbsp;\r\n</body>\r\n</html>\r\n<!-- end footer -->".toCharArray();
    __oracle_jsp_text[41] = 
    "\n".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
