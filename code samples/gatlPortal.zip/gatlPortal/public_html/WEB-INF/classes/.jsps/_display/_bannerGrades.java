package _display;

import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import ca.tru.gatlPortal.*;
import com.tru.connectionserver.server.*;


public class _bannerGrades extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html;charset=windows-1252");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _bannerGrades page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      
      // check login Status
      // **********************************************************************
      String LoggedIn;
      LoggedIn = "" + (String)session.getAttribute("Login");
      if (!(LoggedIn.equalsIgnoreCase("True")))
          response.sendRedirect("../default.jsp?msg=2");
      // **********************************************************************
      
      out.write(__oracle_jsp_text[1]);
      out.write("");
      out.write(__oracle_jsp_text[2]);
      out.write(__oracle_jsp_text[3]);
      out.write(__oracle_jsp_text[4]);
      
        String StudID = new String(request.getParameter("StudID"));
        String Type = new String(request.getParameter("Type"));
        String outString;
        String[] Rows, Fields;   
        ConnectionControler  ctrl = new ConnectionControler((String)session.getAttribute("xmlPath") + "connParams.xml");
        
        outString = ctrl.getRecordSet("StudentName|0~0~0~WHERE|0~1~1~'" + StudID + "'|1~2~1~'" + StudID + "'|");
        Rows = outString.split("\n");
        Fields = Rows[1].split("\\|");
      
      out.write(__oracle_jsp_text[5]);
      out.print(Fields[0] + " " + Fields[1]);
      out.write(__oracle_jsp_text[6]);
       
                try
                {
                  outString = ctrl.getRecordSet("BannerTranscript|"   + "0~0~0~\nWHERE|" +
                                 "0~15~1~'" + Type + "'|" + "2~5~1~null|" + "0~15~0~null|" +
                                 "2~20~1~null|" + "0~16~0~null|" + "2~21~1~null|" + "0~17~0~null|" +
                                 "2~19~1~null|" + "0~15~0~null|" + "2~23~1~null|" + "0~16~0~null|" + 
                                 "2~24~1~null|" + "0~17~0~null|" + "2~27~1~null|" + "0~25~0~null|" + 
                                 "2~28~1~null|" + "0~26~0~null|" + 
                                 "2~29~1~(SELECT|" + "0~0~0~MAX(|0~32~0~)|" + "0~0~0~FROM 8|0~0~0~WHERE|" + 
                                 "0~25~1~null|" + "0~30~0~null|" + "2~26~1~null|" + "0~31~0~)|" + 
                                 "2~18~8~('R', 'W')|" + "2~1~1~'00'|" + 
                                 "2~5~1~null|" + "0~2~0~null|" + "2~6~1~null|" + "0~3~0~null|" + 
                                 "2~7~1~null|" + "0~4~0~null|" + "2~5~1~null|" + "0~11~0~null|" + 
                                 "2~6~1~null|" + "0~12~0~null|" + "2~7~1~null|" + "0~13~0~null|" + 
                                 "2~5~1~null|" + "0~15~0~null|" + "2~6~1~null|" + "0~16~0~null|" + 
                                 "2~8~1~null|" + "0~17~0~null|" + 
                                 "2~14~1~(SELECT|" + "0~0~0~MAX(|0~14~0~)|" + "0~0~0~FROM 7|0~0~0~WHERE|" + 
                                 "0~11~1~null|" + "0~5~0~null|" + "2~12~1~null|" + "0~6~0~null|" + 
                                 "2~13~1~null|" + "0~7~0~)|" + "2~19~1~null|" + "0~5~0~null|" + 
                                 "2~20~1~null|" + "0~6~0~null|" + "2~21~1~null|" + "0~8~0~null|" + 
                                 "2~6~1~null|" + "0~23~0~ (+)|" + "2~8~1~null|" + "0~24~0~ (+)|" + 
                                 "2~9~1~null|" + "0~25~0~ (+)|" + "2~10~1~null|" + "0~26~0~ (+)|" +
                                 "2~42~1~null|" + "0~54~0~null|" +
                                 "2~44~1~'A'|" +
                                 "0~0~0~\nUNION\n|" + 
                                 "0~0~0~SELECT|" + 
                                 "0~46~0~,|" + "0~47~0~,|" + "0~48~0~,|" + "0~49~0~,|" + 
                                 "0~50~0~,|" + "0~51~0~,|" + "0~52~0~,|" + "0~53~0~null|" +
                                 "0~0~0~FROM 3 9 4 10|" + "0~0~0~WHERE|" +
                                 "0~33~1~'"  + Type + "'|" + 
                                 "2~34~1~null|" + "0~35~0~null|" +
                                 "2~36~1~null|" + "0~37~0~null|" +
                                 "2~38~1~null|" + "0~39~0~null|" +
                                 "2~40~1~null|" + "0~41~0~null|" +
                                 "2~42~1~null|" + "0~43~0~null|" +
                                 "2~44~1~'A'|");                
                  Rows = outString.split("\n");
                  for (int I = 0; I < Rows.length; I++)
                  {
                    out.println("<TR>");
                    Fields = Rows[I].split("\\|");
                    for (int J = 0; J < Fields.length; J++)
                    {
                      if (I == 0)
                        if ((J == 0) || (J == 1))
                        {
                          out.println("<TD><h3>" + Fields[0] + " " + Fields[1] + "</h3></TD>");
                          J++;
                        }  
                        else
                        {
                         out.println("<TD><h3>" + Fields[J] + "</h3></TD>");
                        } 
                      else
                        if ((J == 0) || (J == 1))
                        {
                          out.println("<TD>" + Fields[0] + "-" + Fields[1] + "</TD>");
                          J++;
                        }  
                        else
                        {
                         out.println("<TD>" + Fields[J] + "</TD>");
                        } 
                    }
                    out.println("</TR><TR><TD colspan=\"" + Fields.length + "\" background=\"../images/dots.gif\" height=\"5\"></TD></TR>");
                  }
                  out.println("</TR><TR><TD colspan=\"" + Fields.length + "\" align=\"right\">" + 
                               "<h3>[ <a href=\"javascript:history.go(-1)\">Back</a> ]</h3>"  + 
                               "</TR></TD></TABLE></center></div>");
                }               
                catch(Exception e)
                {
                   out.println("ConnectionServer Error: " + e);
                }  
               
      out.write(__oracle_jsp_text[7]);
      out.write("");
      out.write(__oracle_jsp_text[8]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[9][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "\r\n".toCharArray();
    __oracle_jsp_text[1] = 
    "\r\n\r\n  <!-- include header -->\r\n".toCharArray();
    __oracle_jsp_text[2] = 
    "<!-- begin header header.jsp-->\r\n".toCharArray();
    __oracle_jsp_text[3] = 
    "\r\n<html>\r\n<head>\r\n<META name=\"description\" content=\"The Registrar's Office of Thompson Rivers University in British Columbia / Canada\"> \r\n\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"../style/style.css\" />\r\n<script src=\"../javascript/javascript.js\" type=\"text/javascript\"></script>\r\n<title>TRU & TRU-OL Grade and Transcript Lookup Portal</title>\r\n</head>\r\n<body > \r\n<div id=\"contentWrapper\">\r\n\r\n  <!-- logout button floats to the left-->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Exit the System';  return true\" onMouseOut=\"window.status='';\" >\r\n    <span id=\"buttonInnerWrapper\">&nbsp;\r\n      <a href=\"../action/logout.jsp\" target=\"_parent\"><img src=\"../images/logout.gif\" Title=\"Exit the System\" Alt=\"Logout\"/>\r\n      <em style=\"color:rgb(0,57,123);\">Logout</em></a>\r\n    </span>\r\n  </div>\r\n  <!-- end logout button -->\r\n  \r\n  <!-- help button floats to the left -->\r\n  <div id=\"buttonOuterWrapper\" onMouseOver=\"window.status='Get Help'\" \r\n     onMouseOut=\"window.status='Done'\" onclick=\"window.open('help.jsp','helpWindow')\">\r\n    <span id=\"buttonInnerWrapper\">&nbsp;\r\n      <img src=\"../images/help.gif\" Title=\"Help for TRU & TRU-OL Grade and Transcript Lookup Portal\" \r\n          Alt=\"Help for TRU Grade and Transcript Lookup Portal\" />\r\n      <em style=\"color:rgb(0,57,123);\">&nbsp;Help</em>\r\n    </span>\r\n  </div>\r\n  <!-- end help button -->\r\n   \r\n  <img src=\"../images/tru_logo.gif\" alt=\"Thompson Rivers University Logo\" height=\"70\" width=\"335\" /> &nbsp; <!--vspace=\"20\"-->\r\n  \r\n  <div style=\"width:100.0%; height:14.0px; padding:0.0px; background-color:rgb(0,57,123);\">\r\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>TRU & TRU-OL Grade and Transcript Lookup Portal</em>\r\n  </div>\r\n \r\n\r\n<!-- end header -->".toCharArray();
    __oracle_jsp_text[4] = 
    "\r\n\r\n".toCharArray();
    __oracle_jsp_text[5] = 
    "\r\n<table align=\"right\" border=0><tr><td>[ <a href=\"searchCriteria.jsp\">New Search</a> ]</td></tr></table>\r\n   <p>&nbsp;</p>\r\n   <em><h2>TRU-OL Course and Grades record for ".toCharArray();
    __oracle_jsp_text[6] = 
    "</h2></em>\r\n   <center><TABLE border=\"0\" cellpadding=\"0\" cellspacing=\"15\">\r\n      ".toCharArray();
    __oracle_jsp_text[7] = 
    "\r\n    </td>\r\n  </tr>\r\n</table>\r\n</center>\r\n  <!-- include footer -->\r\n".toCharArray();
    __oracle_jsp_text[8] = 
    "<!-- begin footer -->\r\n</div>\r\n<p>Copyright &copy; Thompson Rivers University 2005 <a href=\"http://www.tru.ca/disclaimer.html\">Legal Information & Terms of Use</a>&nbsp;&nbsp;&nbsp;\r\n</body>\r\n</html>\r\n<!-- end footer -->".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
