
import oracle.jsp.runtime.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;


public class _default extends com.orionserver.http.OrionHttpJspPage {


  // ** Begin Declarations


  // ** End Declarations

  public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {

    response.setContentType( "text/html;charset=windows-1252");
    /* set up the intrinsic variables using the pageContext goober:
    ** session = HttpSession
    ** application = ServletContext
    ** out = JspWriter
    ** page = this
    ** config = ServletConfig
    ** all session/app beans declared in globals.jsa
    */
    PageContext pageContext = JspFactory.getDefaultFactory().getPageContext( this, request, response, null, true, JspWriter.DEFAULT_BUFFER, true);
    // Note: this is not emitted if the session directive == false
    HttpSession session = pageContext.getSession();
    int __jsp_tag_starteval;
    ServletContext application = pageContext.getServletContext();
    JspWriter out = pageContext.getOut();
    _default page = this;
    ServletConfig config = pageContext.getServletConfig();

    try {


      out.write(__oracle_jsp_text[0]);
      
          String[] msgs;
            msgs = new String[4]; // if adding another message 
                                  // change array length here
            msgs[0] = new String("");
            msgs[1] = new String("Login failed ~ Please retry");
            msgs[2] = new String("You required to Login before viewing student records");
            msgs[3] = new String("You have successfully logged out");
          
          int i;  // index
          String msgNumber = "" + request.getParameter("msg"); // this convert null to String "null"
          
          if (msgNumber.equals("null"))     
              msgNumber = "0";
          
          i = Integer.parseInt(msgNumber);  // convert msgNumber String to int
          
          if (i > (msgs.length - 1))
            i = 1;
        
      out.write(__oracle_jsp_text[1]);
      out.print( msgs[i] );
      out.write(__oracle_jsp_text[2]);
       //=session.getAttribute("outString")
      out.write(__oracle_jsp_text[3]);


    }
    catch( Throwable e) {
      if (!(e instanceof javax.servlet.jsp.SkipPageException)){
        try {
          if (out != null) out.clear();
        }
        catch( Exception clearException) {
        }
        pageContext.handlePageException( e);
      }
    }
    finally {
      OracleJspRuntime.extraHandlePCFinally(pageContext,false);
      JspFactory.getDefaultFactory().releasePageContext(pageContext);
    }

  }
  private static final char __oracle_jsp_text[][]=new char[4][];
  static {
    try {
    __oracle_jsp_text[0] = 
    "\n<!-- default.jsp does not use includes  Carla was here-->\n<html>\n<head>\n<META name=\"description\" content=\"The Registrar's Office of Thompson Rivers University in British Columbia / Canada\"> \n<link rel=\"stylesheet\" type=\"text/css\" href=\"style/style.css\" />\n<title>TRU Grade and Transcript Lookup Portal</title>\n</head>\n<body>\n<div id=\"contentWrapper\">\n\t\n   <!-- help button floats to the left -->\n  <div id=\"buttonOuterWrapper\" onClick=\"window.open('display/help.jsp','helpWindow')\">\n  <span id=\"buttonInnerWrapper\">\n  &nbsp;\n  <img src=\"images/help.gif\" Title=\"Help for TRU & TRU-OL Grade and Transcript Lookup Portal\" \n           Alt=\"Help for TRU Grade and Transcript Lookup Portal\" \n           onMouseOver=\"window.status='Get Help'\"; onMouseOut=\"window.status='Done'\"; />\n   </span>\n   <em style=\"color:rgb(0,57,123);\">&nbsp;Help</em>\n  </div>\n  <!-- end help button -->\n  \n  <img src=\"images/tru_logo.gif\" alt=\"Thompson Rivers Logo\" height=\"70\" width=\"335\"  /> &nbsp; <!--vspace=\"20\"-->\n  \n  <div style=\"width:100.0%; height:14.0px; padding:0.0px; background-color:rgb(0,57,123);\">\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>TRU & TRU-OL Grade and Transcript Lookup Portal</em>\n  </div>\n  <p>&nbsp;</p> \n   \n  <form  name=\"Login\" method=\"POST\" action=\"login\">\n    <TABLE border=\"0\" cellpadding=\"0\" cellspacing=\"10\" ALIGN=\"CENTER\">\n      <TR><TD align=\"RIGHT\">User ID:</TD><TD><input title=\"User ID\" type=\"text\" name=\"UserID\"/></TD></TR>\n      <TR><TD align=\"RIGHT\">Password:</TD><TD><input title=\"Secret Password\" type=\"password\" name=\"pass\"/></TD></TR>\n      <TR><TD colspan=\"2\" align=\"RIGHT\"><input type=\"submit\" value=\"Login\" title=\"Trouble logging in?  Click Help Button\"></TD></TR>\n    </TABLE>\n  </form>\n  ".toCharArray();
    __oracle_jsp_text[1] = 
    "\n  <CENTER><h2><FONT COLOR=RED><b>".toCharArray();
    __oracle_jsp_text[2] = 
    "</b></FONT></h2></CENTER>\n  <p>&nbsp;</p>\n\n  </div>\n  <p>Copyright &copy; Thompson Rivers University 2005 <a href=\"http://www.tru.ca/disclaimer.html\">Legal Information & Terms of Use</a>&nbsp;&nbsp;&nbsp;\n\n<!-- <br>\n<h1>\n".toCharArray();
    __oracle_jsp_text[3] = 
    "\n</h1> -->\n</body>\n</html>".toCharArray();
    }
    catch (Throwable th) {
      System.err.println(th);
    }
}
}
