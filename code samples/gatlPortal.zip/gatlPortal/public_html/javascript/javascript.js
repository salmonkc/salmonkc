/* This script and many more are available free online at
The JavaScript Source!! http://javascript.internet.com
Created by: Fang :: http://tinyurl.com/7v7l8 */

function toggle(obj) {
// Moz. or IE
var sibling=(obj.nextSibling.nodeType==3)? obj.nextSibling.nextSibling : obj.nextSibling;
// hide or show
if(sibling.style.display=='' || sibling.style.display=='block') {
	sibling.style.display='none';
    obj.firstChild.firstChild.data='+';
    }
else {
	sibling.style.display='block';
    obj.firstChild.firstChild.data='-';
    }
}
//
function initCollapse() {
var oDT=document.getElementById('content').getElementsByTagName('dt');
for (var i=0; i < oDT.length; i++) {
	oDT[i].onclick=function() {toggle(this)};
    var oSpan=document.createElement('span');
    var sign=document.createTextNode('+');
    oSpan.appendChild(sign);
    oDT[i].insertBefore(oSpan, oDT[i].firstChild); 
    oSpan.style.fontFamily='monospace';
    oSpan.style.paddingRight='0.5em';
    oDT[i].style.cursor='pointer';
    toggle(oDT[i]);
	}
oDT=null;
}
/* window.onload=function() {if(document.getElementById && document.createElement) {initCollapse();}}
*/

/* for searchCriteria.jsp */
 
  var toggleFlag;
  
  function flashing() 
  {
    if (toggleFlag == 1)
      setTimeout(toggleVisibility,750);  
  }
  
  function toggleVisibility()
  {
    if (ProcessingMsg.style.visibility=="hidden")
    {
      ProcessingMsg.style.visibility="visible";
    }
    else
    {
      ProcessingMsg.style.visibility="hidden";
    } 
    flashing();
  }
 
function validate() 
{
  var ID;
  var AllBlank;
  Colleague_SID = /^[0-9]{7}$/;
  Banner_SID = /^[0-9]{9}$/; 
  AllBlank = true;
  
  ID = StudentSearch.id.value;

  if ((Colleague_SID.test(ID) == false) &&
      (Banner_SID.test(ID)== false) && !(ID==""))
  {
    alert('-- Invalid Student Number --\n' + 
              'Student numbers must be either 7 or 9 digits');
    ProcessingMsg.style.visibility=="hidden"
    toggleflag = 0;
    return false;
  }

  //  StudentSearch.elements.length - 1 because last tlrmnt is submit button
  for (i=0; i<(StudentSearch.elements.length - 1); i++) 
  {
    if (!(StudentSearch.elements[i].value ==""))
    {
      AllBlank = false; 
    }
  }
  if (AllBlank == true)
  {
    alert('You have not entered any search criteria\n' + 
            'You must fill in at least one field in this form');
    ProcessingMsg.style.visibility=="hidden"
    toggleflag = 0;
    
    return false;  
  }

  toggleFlag = 1; 
  flashing();
}

/* end searchCriteria.jsp */

/* student.jsp */

  function flashing() 
  {
    setTimeout(toggleVisibility,750);
  }
  
  function toggleVisibility()
  {
    if (ProcessingMsg.style.visibility=="hidden")
    {
      ProcessingMsg.style.visibility="visible";
    }
    else
    {
      ProcessingMsg.style.visibility="hidden";
    }
    flashing();
  }

/* end student.jsp */