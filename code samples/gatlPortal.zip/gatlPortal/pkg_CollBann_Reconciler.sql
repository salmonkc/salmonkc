CREATE OR REPLACE PACKAGE CollBann_Reconciler AS

/************************************************************************
*
*       SYSTEM: Academic Grade and Transcript Lookup System
*    ProgramID: agtls
*  Description: reconcile student records from Banner and Colleague  
*       Author: Sam Johnson   sjohnson@tru.ca
*      Created: 12-jul-05
*
************************************************************************/

-------------------------------------------------------------------------
  /*  PROCEDURE p_MAIN
      Proceedure to control flow of package execution
  */
  PROCEDURE p_MAIN;

-------------------------------------------------------------------------
  /* PROCEDURE p_Reconcile_New_BannerST
     This procedure loops through all records in the BannerST table
     comparing each record against the records in the Student table
  */
  PROCEDURE p_Reconcile_New_BannerST;
  
-------------------------------------------------------------------------
  /* PROCEDURE p_Add_Unreconciled_New_Bann                       
     After the records that are able to be reconciled have been matched, 
     those records that were not matched from the BannerST table will 
     be added to the Student table by thes proceedure
  */
  PROCEDURE p_Add_Unreconciled_New_Bann;
  
-------------------------------------------------------------------------
  /* p_Reconcile_New_ColleagueST
     This procedure loops through all records in the ColleagueST table
     comparing each record against the records in the Student table
  */
  PROCEDURE p_Reconcile_New_ColleagueST;
-------------------------------------------------------------------------
  /* PROCEDURE p_Add_Unreconciled_New_Coll                       
     After the records that are able to be reconciled have been matched, 
     those records that were not matched from the ColleagueST table will 
     be added to the Student table by thes proceedure
  */
  PROCEDURE p_Add_Unreconciled_New_Coll;
  
-------------------------------------------------------------------------
  /* FUNCTION p_Update_Student                       
     When two student records are found to match this procedure will 
     update the student table to inculde both student numbers, the 
     reconciled type (indicates confidence in match) and the date 
     this record is being updated.  also if data is missing for this 
     record in the student table this procedure will add it from the 
     matching record. Returns true if update was performed else returns false
  */
  FUNCTION f_Update_Student(v_SourceTable VARCHAR2,
                v_ReconciledType NUMBER,
                v_Stud_ID Student.STUDENT_ID%TYPE)
    RETURN BOOLEAN;
                
-------------------------------------------------------------------------
  /* PROCEDURE p_Cleanup
     this Procedure will empty the temporary tables 
  */
  PROCEDURE p_Cleanup;
  
-------------------------------------------------------------------------
  /* FUNCTION f_Compare                       
     This Function returns a numeric value that is used to evaluate 
     whether or not two student records refer to the same student and if 
     the do appear to refer to the same student how confident is that 
     evaluation. 
         return of > 100 is very confident
         return > 75 is moderatly confident 
         return > 50 is low confidence
         return < 50 not the the same student
  */
  PROCEDURE p_Compare(
               v_PEN IN Student.STUDENT_PEN%TYPE,
               v_PrePEN IN Student.STUDENT_PreliminaryPEN%TYPE,
               v_FirstName IN Student.STUDENT_FirstName%TYPE,
               v_MiddleName IN Student.STUDENT_MiddleName%TYPE,
               v_LastName IN Student.STUDENT_LastName%TYPE,
               v_Gender IN Student.STUDENT_Gender%TYPE,
               v_BirthDate IN Student.STUDENT_BirthDate%TYPE,
               v_Address_Line1 IN Student.STUDENT_AddressLine1%TYPE,
               v_Address_Line2 IN Student.STUDENT_AddressLine2%TYPE,
               v_City IN Student.STUDENT_City%TYPE,
               v_Province IN Student.STUDENT_Province%TYPE,
               v_Country IN Student.STUDENT_Country%TYPE,
               v_PostalCode IN Student.STUDENT_PostalCode%TYPE,
               v_SIN IN Student.STUDENT_SIN%TYPE);
-------------------------------------------------------------------------               
END CollBann_Reconciler;
/