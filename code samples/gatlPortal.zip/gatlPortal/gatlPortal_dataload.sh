#!/bin/bash
#
echo remove old XSTUDENT_EXTRACT.CSV
rm -v /home/oracle/gatlPortal/XSTUDENT_EXTRACT.CSV
echo ""
echo FTP the file from merlin.tru.ca
ftp -vnu merlin.tru.ca<<END_SCRIPT
user aisapps select4
cd /datatel/coltest_db/_HOLD_/
get XSTUDENT_EXTRACT.CSV
disconnect
bye
END_SCRIPT
#
#
echo ""
echo set ORACLE_HOME
export ORACLE_HOME='/u01/app/oracle/product/10.2.0/db_1'
echo ORACLE_HOME : $ORACLE_HOME
#
#
echo ""
echo run sqlldr
$ORACLE_HOME/bin/sqlldr gatlPortal/narn1a@truapps control=/oracle/colleague_load.ctl log=/oracle/colleague_load.log
#
#
echo ""
echo copy from banner
# load banner data and run reconciler package
$ORACLE_HOME/bin/sqlplus gatlPortal/narn1a@trudev01 <<ENDOFSQL
COPY FROM aisapps/4select@banpdn_apollo.ola.bc.ca -
     APPEND BannerST -
     USING SELECT SPRIDEN_ID as BannerST_BannerID, -
       SPBPERS_VETC_FILE_NUMBER as BannerST_PEN, -
       SPRIDEN_PIDM as BannerST_PIDM, -
       SPRIDEN_FIRST_NAME as BannerST_FirstName, -
       SPRIDEN_MI as BannerST_MiddleName, -
       SPRIDEN_LAST_NAME as BannerST_LastName, -
       SPBPERS_SEX as BannerST_Gender, -
       SPBPERS_BIRTH_DATE as BannerST_BirthDate, -
       SPRADDR_STREET_LINE1 as BannerST_Address_Line1, -
       SPRADDR_STREET_LINE2 as BannerST_Address_Line2, -
       SPRADDR_CITY as BannerST_City, -
       SPRADDR_STAT_CODE as BannerST_Province, -
       SPRADDR_ZIP as BannerST_PostalCode, -
       SPRADDR_NATN_CODE as BannerST_Country, -
       SPBPERS_SSN as BannerST_SIN -
 FROM  SPRIDEN, -
       SPBPERS, -
       SPRADDR -
 WHERE SPRIDEN_PIDM = SPBPERS_PIDM AND -
       SPRIDEN_PIDM = SPRADDR_PIDM AND -
       SPBPERS_PIDM = SPRADDR_PIDM AND -
       SPRIDEN_CHANGE_IND IS NULL AND SPRADDR_STATUS_IND IS NULL AND -
       SPRADDR_ACTIVITY_DATE BETWEEN (SELECT (SYSDATE - 3) FROM DUAL) AND (SELECT (SYSDATE) FROM DUAL);

--
-- remove duplicates
DELETE FROM BannerST A
WHERE
   A.rowid >
   ANY (SELECT B.rowid
   FROM
      BannerST B
   WHERE
      A.BannerST_BannerID = B.BannerST_BannerID);
--
DELETE FROM ColleagueST A
WHERE
   A.rowid >
   ANY (SELECT B.rowid
   FROM
      ColleagueST B
   WHERE
      A.ColleagueST_ColleagueID = B.ColleagueST_ColleagueID);
--
-- run reconciler pkg
exec collBann_reconciler.p_main();
--
disconnect
exit
ENDOFSQL

