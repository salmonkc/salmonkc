#!/bin/bash
#
echo FTP the file from merlin.tru.ca
ftp -vn merlin.tru.ca<<END_SCRIPT
user aisapps select4
cd /datatel/coltest_db/_HOLD_/
get XSTUDENT_EXTRACT.CSV
disconnect
bye
END_SCRIPT
#
#
echo ""
echo set ORACLE_HOME
export ORACLE_HOME='/u01/app/oracle/product/10.2.0/db_1'
echo ORACLE_HOME : $ORACLE_HOME
#
#
echo ""
echo run sqlldr
$ORACLE_HOME/bin/sqlldr gatlPortal/narn1a@trudevdb control=/u03/gatlportal/colleague_load.ctl log=/u03/gatlportal/colleague_load.log