/u03/gatlportal/gatlPortal_dataload.sh > /tmp/gpd.log
/bin/mail -s "-LOG-trupdn- gatlPortal Dataload" aismaintenancelogs@tru.ca < /tmp/gpd.log
