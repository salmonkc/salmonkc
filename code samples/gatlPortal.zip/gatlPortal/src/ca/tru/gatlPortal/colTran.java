package ca.tru.gatlPortal;

import asjava.uniobjects.*;
import asjava.uniclientlibs.*;


/**
 * connects to colleague and calls the S.UOJ.TRANSCRIPT.WRAPPER colleague 
 * subroutine, which create a text file.  this text file is read into a string
 * and returned to procedure calling this method.
 */
public class colTran 
{
  public colTran()
  {
  }
  
  /**
   * connects to colleague and calls the S.UOJ.TRANSCRIPT.WRAPPER colleague 
   * subroutine, which create a text file.  this text file is read into a string
   * and returned to procedure calling this method.
   * 
   * @return string containing colleague transcript 
   * @param Type  direct subroutine to transcript type requested
   * @param StuID direct subroutine to student number of requested transcript
   */
  public String getTranscript(String StuID, String Type)
  {
    UniString uString = new UniString("");
    String Return = new String("");

    try {
         // every thing runs out of the UniSession instance.
         UniSession uSession = new UniSession();
         
         //Set up connection variables.
         uSession.setHostName("merlin");
         uSession.setUserName("aisapps");
         uSession.setPassword("select4");

        // uSession.setAccountPath("/datatel/coltest_db"); // test db
        uSession.setAccountPath("/datatel/collive_db"); // live db
        
         // lets connect to the database.
         uSession.connect();
         
         UniCommand runCmd;
         runCmd = uSession.command("ENVINIT");
         runCmd.exec();
         runCmd = uSession.command("CORE.JUMPSTART");
         runCmd.exec();
         runCmd = uSession.command("ST.JUMPSTART");
         runCmd.exec();
         
          //  set args for subroutine
         String ret1 = "";
         String ret2 = "";
         String ret3 = "";
         String ret4 = "";
         String ret5 = "";
         UniSubroutine subroutine = uSession.subroutine("S.UOJ.TRANSCRIPT.WRAPPER", 10);
           subroutine.setArg(0, StuID);
           subroutine.setArg(1, StuID);
           subroutine.setArg(2, Type);
           subroutine.setArg(3, "PREFERRED");
           subroutine.setArg(4, ret1);
           subroutine.setArg(5, ret2);
           subroutine.setArg(6, ret3);
           subroutine.setArg(7, ret4);
           subroutine.setArg(8, ret5);
           subroutine.setArg(9, StuID+".TRAN");
        // Call subroutine
      	 subroutine.call(); 
        
       // Reading Trascript with UniSession
       try
       {
         UniSequentialFile uSeq = uSession.openSeq( "HOLD", StuID + ".TRAN", false );
          if ( uSeq.isOpen() )
          {
            int i = 1;
            uString = uSeq.readBlk();
            Return = uString.toString();
            uSeq.close();        
          }
        } 
        catch(UniSequentialFileException e)
          {
            return "uniSeqFile Error: " + e;
          }
  /*    
        // Delete transcript hold file
        try
        {
          UniFile custFile = uSession.open("HOLD");
          custFile.deleteRecord(StuID + ".TRAN");
        }
        catch(UniFileException e)
        {  
          return "uniFile Error: " + e;
        }
  */        
        if (uSession.isActive())
         {
         // lets disconnect from the database.
            uSession.disconnect();
         }   
         
        return Return;
    }
    
    catch (UniCommandException e)
      {
         return "uniCommand Error: " + e;
      }
    catch (UniSubroutineException e) 
      {
         return "uniSubroutine Error: " + e;
      } 
    catch (UniSessionException e) 
      {
         e.printStackTrace();
         return "UniSession Error: " + e;
      }   
  }
}  