package ca.tru.gatlPortal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.io.IOException;
import com.tru.connectionserver.server.*;

public class login extends HttpServlet 
{
  private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
  }
  
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    String redirectURL, id, pass, SQLstmnt, outString;
    String[] Rows;
    
    HttpSession s = request.getSession();
    redirectURL = "";
    id = request.getParameter("UserID").toUpperCase();
    pass = request.getParameter("pass"); 
    SQLstmnt = "0~0~0~WHERE|0~1~1~'" + id + "'|2~2~1~'" + pass + "'";
    try
     {
// use this connection string for trudev01.tru.ca and trupdn01.tru.ca 
      ConnectionControler  ctrl = new ConnectionControler(
                                  "/u02/XML_Connections/connParams.xml");

// use this connection string for testing on localhost 
//      ConnectionControler  ctrl = new ConnectionControler(
//                                   "F:\\jdev\\BCOU\\gatlPortal\\connParams.xml");
                                   
      outString = ctrl.getRecordSet("login|" + SQLstmnt); ;  
      Rows = outString.split("\n");
      if (Rows.length == 2)
      {   
        s.setAttribute("Login","true");
     // path to xml file - do not include xml file name in below assignment
        s.setAttribute("xmlPath","/u02/XML_Connections/"); // trudev01.tru.ca & trupdn01.tru.ca
//        s.setAttribute("xmlPath","F:\\jdev\\BCOU\\gatlPortal\\"); // localhost
        s.setAttribute("outString",outString);
        redirectURL = "display/searchCriteria.jsp?";
      }    
      else
      {
        s.setAttribute("outString",outString);
        s.setAttribute("Login","False");
        redirectURL = "default.jsp?msg=1"; 
      }
      response.sendRedirect(redirectURL);
    }
    catch(Exception e)
   {
      s.setAttribute("outString",e.getMessage());
      s.setAttribute("Login","False");
      redirectURL = "default.jsp?msg=1";
      response.sendRedirect(redirectURL);
    }  
  }  
}