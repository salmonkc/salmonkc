package ca.tru.gatlPortal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.*; 
import java.sql.*;
import com.tru.connectionserver.server.*;

public class findStudent extends HttpServlet 
{
  private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
  }

public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    HttpSession session = request.getSession();
    
   // check login Status
   // **********************************************************************
   String LoggedIn;
   LoggedIn = "" + (String)session.getAttribute("Login");
   if (!(LoggedIn.equalsIgnoreCase("True")))
      response.sendRedirect("default.jsp?msg=2");
   // **********************************************************************
  
  //PrintWriter out = response.getWriter();
  
  String redirectURL, PossibleMatch, outString, 
         id, FName, LName, AddressLine1, City, Province, PostalCode, Country;
  String[] Fields, Rows;
  String SQLstmnt;
  int compound = 0;
  
  //initalize
  redirectURL = "empty";
  outString="empty";
  SQLstmnt = "EMPTY";

  // "" + at beginning of each assignment to avoid null vallues.
  id = "" + request.getParameter("id");
  FName = "" + request.getParameter("FName").toUpperCase();
  LName = "" + request.getParameter("LName").toUpperCase();
  AddressLine1 = "" + request.getParameter("AddressLine1").toUpperCase();
  City = "" + request.getParameter("City").toUpperCase();
  if (("" + request.getParameter("ProvinceNA")).length() == 0)
    Province = "" + request.getParameter("Province").toUpperCase();
  else
    Province = "" + request.getParameter("ProvinceNA").toUpperCase();
  PostalCode = "" + request.getParameter("PostalCode").toUpperCase();
  Country = "" + request.getParameter("Country").toUpperCase();
  
  SQLstmnt = "0~0~0~WHERE|";
  
  if (id.length() == 0)
  {
    if (!(FName.equals("")))
    {
      SQLstmnt = SQLstmnt + compound + "~3~7~'" + FName.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    if (!(LName.equals("")))
    { 
      SQLstmnt = SQLstmnt + compound + "~4~7~'" + LName.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    if (!(AddressLine1.equals("")))
    { 
      SQLstmnt = SQLstmnt + compound + "~5~7~'" + AddressLine1.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    if (!(City.equals("")))
    { 
      SQLstmnt = SQLstmnt + compound + "~6~7~'" + City.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    if (!(Province.equals("")))
    { 
      SQLstmnt = SQLstmnt + compound + "~7~7~'" + Province.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    if (!(PostalCode.equals("")))
    { 
      SQLstmnt = SQLstmnt + compound + "~8~7~'" + PostalCode.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    if (!(Country.equals("")))
    { 
      SQLstmnt = SQLstmnt + compound + "~9~7~'" + Country.replace( '*', '%' ) + "'|";
      compound = 2;
    }
    SQLstmnt = SQLstmnt + "0~0~0~ORDER BY STUDENT_LASTNAME, STUDENT_FIRSTNAME|";
  }    
  else
  {
    if (id.length() == 7) 
      SQLstmnt = SQLstmnt + "0~1~1~'" + id + "'";  // colleague ID
    else
      SQLstmnt = SQLstmnt + "0~2~1~'" + id + "'"; // banner ID
  }
  try
  {
    ConnectionControler  ctrl = new ConnectionControler(session.getAttribute("xmlPath") + "connParams.xml");
    outString = ctrl.getRecordSet("CountReturn|" + SQLstmnt);
    Rows = outString.split("\n");
    if (Integer.parseInt(Rows[1]) < 200)
    {
      outString = ctrl.getRecordSet("FindStudent|" + SQLstmnt);   
      Rows = outString.split("\n");
      if (Rows.length == 1)
      {
        if (outString.indexOf("Execution failed: ")==0)
          session.setAttribute("outString",outString);
        else
         session.setAttribute("outString","This student could not be found in the database");
      
         redirectURL = "display/noStudent.jsp";
      }
      else
      {
        session.setAttribute("AllRows",outString);
        session.setAttribute("RowCount", "" + (Rows.length - 1)); 
                 //at least to rows will be returned the first is for col headers 
        if (Rows.length > 2)
        { 
          if (Rows.length > 10)
            redirectURL = "display/whichStudent.jsp?low_i=1&high_i=10";
          else
            redirectURL = "display/whichStudent.jsp?low_i=1&high_i=" + (Rows.length - 1);
        }  
        else
        {
          session.setAttribute("outString",outString); 
          // remove any previous possible matches             
          session.removeAttribute("PossibleMatch");
          // search for possible matches
          SQLstmnt =  "0~0~0~WHERE|" +
                      "0~5~8~(SELECT|" + 
                      "0~1~0~null|" +
                      "0~0~0~FROM 1|" +
                      "0~0~0~WHERE|" +
                      "0~2~1~'" + id + "'|" + 
                      "1~3~1~'" + id + "')|" +
                      "0~0~0~AND(|" +
                      "0~5~1~null|" +
                      "0~1~0~null|" + 
                      "2~2~1~'" + id + "'|" + 
                      "1~3~1~'" + id + "')|" +
                      "0~0~0~ORDER BY|" + 
                      "0~4~0~ DESC";
/*         "SELECT Student.*, PossibleMatch_CompareFactor CompF FROM PossibleMatch, Student " + 
           "WHERE Student_ID IN (SELECT PossibleMatch_StudentID FROM PossibleMatch " + 
           "WHERE PossibleMatch_ColleagueID = " + id + " OR " + 
           "PossibleMatch_BannerID = " + id + ") AND " +
           "(Student_ID = PossibleMatch_StudentID AND " + 
           " PossibleMatch_ColleagueID = " + id + " OR " + 
           " PossibleMatch_BannerID = " + id + ") " + 
           "ORDER BY PossibleMatch_CompareFactor DESC";
*/
          PossibleMatch = new String(ctrl.getRecordSet("PossibleMatch|" + SQLstmnt));

          if ((PossibleMatch.length() > 0) && 
              (PossibleMatch.indexOf("Execution failed: ") < 0)) 
            session.setAttribute("PossibleMatch",PossibleMatch);
  
          redirectURL = "display/student.jsp";  
          }  
        }
      }
      else
      {
        redirectURL = "display/tooMany.jsp?returnCount=" + Rows[1];
      }
      response.sendRedirect(redirectURL);
    }
    catch(Exception e)
    {
      session.setAttribute("outString","ConnectionServer Error: " + e);
      PrintWriter out = response.getWriter();
      out.println("\n" + outString + "\n" + redirectURL + "\n" + SQLstmnt);
    }
   //   PrintWriter out = response.getWriter();
   //   out.println("\n" + outString + "\n" + redirectURL + "\n" + SQLstmnt);  
  }
}