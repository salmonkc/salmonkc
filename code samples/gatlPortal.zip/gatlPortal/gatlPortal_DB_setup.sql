/*==============================================================*/
/* Database name:  trudev01                                     */
/* DBMS name:      ORACLE Version 8i                            */
/* Created on:     13/07/2005 3:23:00 PM                        */
/*==============================================================*/


drop table Student cascade constraints
/
drop sequence Student_ID_SEQ
/
drop table ReconciledType cascade constraints
/
drop table ColleagueST cascade constraints
/
drop table BannerST cascade constraints
/
drop table possiblematch
/
drop table USERS cascade constraints
/

/*==============================================================*/
/* Table : BannerST                                             */
/*==============================================================*/

create table BannerST (
   BannerST_BannerID        VARCHAR2(9)               not null,
   BannerST_PEN             VARCHAR2(10),
   BannerST_PIDM            NUMBER(8)                 not null,
   BannerST_FirstName       VARCHAR2(15),
   BannerST_MiddleName      VARCHAR2(15),
   BannerST_LastName        VARCHAR2(60),
   BannerST_Gender          VARCHAR2(1),
   BannerST_BirthDate       DATE,
   BannerST_Address_Line1   VARCHAR2(30),
   BannerST_Address_Line2   VARCHAR2(30),
   BannerST_City            VARCHAR2(20)              not null,
   BannerST_Province        VARCHAR2(3),
   BannerST_PostalCode      VARCHAR2(10),
   BannerST_Country         VARCHAR2(5),
   BannerST_SIN             VARCHAR2(9),
   constraint CKT_BANNERST_GENDER check (BannerST_Gender IN ('M', 'F','m','f', 'N', 'n'))
)
/

comment on column BannerST.BannerST_BirthDate is 'YYYY-MM-DD'
/

/*==============================================================*/
/* Table : ColleagueST                                          */
/*==============================================================*/

create table ColleagueST (
   ColleagueST_ColleagueID      VARCHAR2(7)               not null,
   ColleagueST_PEN              VARCHAR2(10),
   ColleagueST_PreLiminaryPEN   VARCHAR2(10),
   ColleagueST_FirstName        VARCHAR2(15),
   ColleagueST_MiddleName       VARCHAR2(15),
   ColleagueST_LastName         VARCHAR2(60)              not null,
   ColleagueST_Gender           VARCHAR(1),
   ColleagueST_BirthDate        DATE,
   ColleagueST_Address_Line1    VARCHAR2(30),
   ColleagueST_Address_Line2    VARCHAR2(30),
   ColleagueST_City             VARCHAR2(20)              not null,
   ColleagueST_Province         VARCHAR2(2),
   ColleagueST_PostalCode       VARCHAR2(8),
   ColleagueST_Country          VARCHAR2(30),
   ColleagueST_SIN              VARCHAR2(9),
   constraint CKT_COLLEAGUEST_GENDER check (ColleagueST_Gender IN ('M', 'F','m','f', 'N', 'n'))
)
/

comment on column ColleagueST.ColleagueST_BirthDate is 'YYYY-MM-DD'
/

/*==============================================================*/
/* Table : ReconciledType                                       */
/*==============================================================*/

create table ReconciledType (
   ReconciledType_Code         NUMBER(1)                 not null,
   ReconciledType_Description  VARCHAR2(60)              not null,
   constraint PK_RECONCILEDTYPE primary key (ReconciledType_Code)
)
/

INSERT INTO ReconciledType VALUES(0, 'unreconciled')
/

INSERT INTO ReconciledType VALUES(1, 'Full Confidence')
/

INSERT INTO ReconciledType VALUES(2, 'Moderate Confidence')
/

INSERT INTO ReconciledType VALUES(3, 'Low Confidence')
/

/*==============================================================*/
/* Table : Student                                              */
/*==============================================================*/

create table Student (
   Student_ID              NUMBER                     not null,
   Student_ColleagueID     VARCHAR2(7),
   Student_BannerID        VARCHAR2(9),
   Student_PEN             VARCHAR2(10),
   Student_PreliminaryPEN  VARCHAR2(10),
   Student_PIDM            NUMBER(8),
   Student_FirstName       VARCHAR2(15),
   Student_MiddleName      VARCHAR2(15),
   Student_LastName        VARCHAR2(60),
   Student_Gender          VARCHAR2(1),
   Student_BirthDate       DATE,
   Student_AddressLine1    VARCHAR2(30),
   Student_AddressLine2    VARCHAR2(30),
   Student_City            VARCHAR2(20)               not null,
   Student_Province        VARCHAR2(3),
   Student_PostalCode      VARCHAR2(10),
   Student_Country         VARCHAR2(30),
   Student_SIN             VARCHAR2(9),
   Student_LastUpdated     DATE                        not null,
   Student_UpdatedBy       VARCHAR2(9)                 not null,
   Student_ReconciledType  NUMBER(1)                   not null,
   constraint PK_STUDENT primary key (Student_ID),
   constraint FK_STUDENT_RECONCILA_RECONCIL foreign key (Student_ReconciledType)
         references ReconciledType (ReconciledType_Code)
         on delete cascade,
   constraint CKT_STUDENT_GENDER check (Student_Gender IN ('M', 'F','m','f', 'N', 'n'))
)
/

comment on table Student is 'Reconciled Students'
/

comment on column Student.Student_LastUpdated is 'YYYY-MM-DD'
/

/*==============================================================*/
/* Table : PossibleMatch                                        */
/*==============================================================*/

create table PossibleMatch (
   PossibleMatch_StudentID     NUMBER                not null,
   PossibleMatch_ColleagueID   VARCHAR2(7),
   PossibleMatch_BannerID      VARCHAR2(9),
   PossibleMatch_CompareFactor NUMBER
)
/

/*==============================================================*/
/* Table : USERS                                                */
/*==============================================================*/

create table USERS (
   UserName  VARCHAR2(10)              not null,
   Password  VARCHAR2(10)              not null,
   Class     VARCHAR2(14)              not null, 
   constraint PK_Users primary key (UserName)
)
/

INSERT INTO USERS VALUES('truuser','!ApRend3R','general')
/

INSERT INTO USERS VALUES('Admin','3stuD1ante','administrator')
/

/*=============================================================*/
/*  Indexes                                                    */
/*=============================================================*/

CREATE INDEX Student_ColleagueID_INDEX on Student(Student_ColleagueID)
/

CREATE INDEX Student_BannerID_INDEX on Student(Student_BannerID)
/

CREATE INDEX Student_PEN_INDEX on Student(Student_PEN)
/

CREATE INDEX Student_FirstName_INDEX on Student(Student_FirstName)
/

CREATE INDEX Student_MiddleName_INDEX on Student(Student_MiddleName)
/

CREATE INDEX Student_LastName_INDEX on Student(Student_LastName)
/

CREATE INDEX Student_Gender_DOB_INDEX on Student(Student_Gender, Student_Birthdate)
/

CREATE INDEX Student_Address_Line1_INDEX on Student(Student_AddressLine1)
/

CREATE INDEX Student_Address_Line2_INDEX on Student(Student_AddressLine2)
/

CREATE INDEX Student_city_Prov_cnty_INDEX on Student(Student_City, 
                 Student_Province, Student_Country, Student_PostalCode)
/

CREATE INDEX Student_SIN_INDEX on Student(Student_SIN)
/

create sequence Student_ID_SEQ
  start with 1 
  increment by 1 
  nomaxvalue
/

PURGE Recyclebin
/