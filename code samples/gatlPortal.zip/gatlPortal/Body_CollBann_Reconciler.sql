CREATE OR REPLACE PACKAGE BODY CollBann_Reconciler AS
     
   r_Bann_ROW      BannerST%ROWTYPE;  -- a single Banner record
   r_Coll_ROW      ColleagueST%ROWTYPE;  -- a single Colleague record
 -- the next variables are used for input to student table fields 
   v_updatedBy     VARCHAR2(9);  -- For setting Student_UpdatedBy
   v_timestamp     TIMESTAMP;  -- For Student_LastUpdated
   
   CURSOR c_BannerST IS 
       SELECT * FROM BannerST ORDER BY BannerST_BannerID;
   
   CURSOR c_ColleagueST IS 
       SELECT * FROM ColleagueST ORDER BY ColleagueST_ColleagueID; 
   
   TYPE Matched_Records IS TABLE OF PossibleMatch%ROWTYPE
     INDEX BY BINARY_INTEGER;

   t_StudIDs       Matched_Records;  -- a single PossibleMatch record  
       
--------------------------------------------------------------------------      

   -- =====================================================================
   -- PROCEDURE p_MAIN
   -- Proceedure to control flow of package execution
   -- =====================================================================
   PROCEDURE p_MAIN IS
     
     v_tempSeq    NUMBER;
     
     BEGIN
      -- initalize variables
       SELECT systimestamp INTO v_timestamp FROM dual;       
       v_UpdatedBy := 'Process';
       SELECT Student_ID_SEQ.NEXTVAL into v_tempSeq from dual;

      -- procedure calls
       p_Reconcile_New_BannerST;  -- compare the new Banner Records with
                                  -- exiting unreconciled Student          
       p_Reconcile_New_ColleagueST;  -- compare the new Colleague Records 
                                     -- with exiting unreconciled Student     
       p_Cleanup; --  empty Temp Tables
       
       DELETE FROM PossibleMatch A
         WHERE A.rowid > ANY (SELECT B.rowid 
                                FROM PossibleMatch B
                                WHERE A.PossibleMatch_StudentID = B.PossibleMatch_StudentID AND
                                     (A.PossibleMatch_ColleagueID = B.PossibleMatch_ColleagueID OR
                                      A.PossibleMatch_BannerID = B.PossibleMatch_BannerID));
       commit;                               
     END p_MAIN;


   -- =====================================================================   
   -- PROCEDURE p_Reconcile_New_BannerST
   -- This procedure loops through all records in the BannerST table
   -- comparing each record against the records in the Student table 
   -- =====================================================================     
   PROCEDURE p_Reconcile_New_BannerST IS
   
     v_Match_Found             BOOLEAN;
     v_MatchingColl            Student.Student_ColleagueID%TYPE;
     v_StudentExists           NUMBER;
     v_StudentExistsID         VARCHAR2(12);
     v_student_ID              NUMBER;
     v_Student_ReconciledType  Student.Student_ReconciledType%TYPE;
     
     BEGIN
       OPEN c_BannerST;
         LOOP
         FETCH c_BannerST INTO r_Bann_ROW; 
         EXIT WHEN c_BannerST%NOTFOUND;
     -- initalize variables    
         v_Match_Found := FALSE;
         t_studIDs.DELETE;

         DECLARE
           RECONCILED_ALREADY  EXCEPTION;
         BEGIN
           SELECT count(Student_BannerID), max(Student_ID), max(Student_ReconciledType)
              INTO v_StudentExists, v_StudentExistsID, v_Student_ReconciledType 
              FROM Student 
              WHERE Student_BannerID = r_Bann_ROW.BannerST_BannerID;            
           IF v_StudentExists > 0 THEN
             IF v_Student_ReconciledType = 0 THEN
              DELETE FROM Student  -- remove record so it can try to reconcile
                  WHERE Student_ID = v_StudentExistsID;
               DELETE FROM PossibleMatch
                  WHERE PossibleMatch_StudentID = v_StudentExistsID OR 
                        PossibleMatch_BannerID = r_Bann_ROW.BannerST_BannerID;   
             ELSE --  else for v_Student_ReconciledType = 0
               RAISE RECONCILED_ALREADY;
             END IF; -- end v_Student_ReconciledType = 0
           END IF;  -- end of v_StudentExists > 0 
         EXCEPTION
           WHEN RECONCILED_ALREADY THEN
             UPDATE Student 
             SET
               Student_PEN = r_Bann_ROW.BannerST_PEN,
               Student_FirstName = r_Bann_ROW.BannerST_FirstName,
               Student_MiddleName = r_Bann_ROW.BannerST_MiddleName,
               Student_LastName = r_Bann_ROW.BannerST_LastName,
               Student_Gender = r_Bann_ROW.BannerST_Gender,
               Student_BirthDate = r_Bann_ROW.BannerST_BirthDate,
               Student_AddressLine1 = r_Bann_ROW.BannerST_Address_line1,
               Student_AddressLine2 = r_Bann_ROW.BannerST_Address_line2,
               Student_City = r_Bann_ROW.BannerST_City,
               Student_Province = r_Bann_ROW.BannerST_Province,
               Student_PostalCode = r_Bann_ROW.BannerST_PostalCode,
               Student_Country = r_Bann_ROW.BannerST_Country,
               Student_SIN = r_Bann_ROW.BannerST_SIN,
               Student_LastUpdated = v_timestamp
             WHERE Student_ID=v_StudentExistsID;
           
             DELETE FROM BannerST  -- This record is already in the Student table
               WHERE BannerST_BannerID = r_Bann_ROW.BannerST_BannerID;
     
             GOTO get_next_Bann_record; -- jump to next Banner record and 
                                        -- avoid processing this record
         END; -- end embeded block

         p_Compare(r_Bann_ROW.BannerST_PEN,
                   NULL,
                   UPPER(r_Bann_ROW.BannerST_FirstName),
                   UPPER(r_Bann_ROW.BannerST_MiddleName),
                   UPPER(r_Bann_ROW.BannerST_LastName),
                   UPPER(r_Bann_ROW.BannerST_Gender),
                   r_Bann_ROW.BannerST_BirthDate,
                   UPPER(r_Bann_ROW.BannerST_Address_Line1),
                   UPPER(r_Bann_ROW.BannerST_Address_Line2),
                   UPPER(r_Bann_ROW.BannerST_City),
                   UPPER(r_Bann_ROW.BannerST_Province),
                   UPPER(r_Bann_ROW.BannerST_Country),
                   UPPER(r_Bann_ROW.BannerST_PostalCode),
                   r_Bann_ROW.BannerST_SIN);
         IF t_StudIDs.count > 0 THEN
           FOR i IN 1..t_StudIDs.LAST LOOP
             IF t_StudIDs.EXISTS(i) THEN
               IF (t_StudIDs(I).POSSIBLEMATCH_CompareFactor >= 100) THEN
                 SELECT Student_ColleagueID into v_StudentExistsID FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID; 
                 IF (v_StudentExistsID IS NOT NULL) THEN
                   v_Match_Found := f_Update_Student('Bann',1,t_StudIDs(i).POSSIBLEMATCH_STUDENTID);
                   DELETE FROM BannerST  -- This record has an exact match and is no longer needed
                     WHERE BannerST_BannerID = r_Bann_ROW.BannerST_BannerID;
          --         DELETE FROM POSSIBLEMATCH  -- eliminate any possible match becasue we found an sure match
          --           WHERE POSSIBLEMATCH_BannerID = t_StudIDs(i).POSSIBLEMATCH_BannerID;
                   EXIT;    -- get on to next one
                 ELSE -- two matching banner records
                   INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                            POSSIBLEMATCH_BannerID,
                                            POSSIBLEMATCH_CompareFactor)
                     VALUES (t_StudIDs(i).POSSIBLEMATCH_StudentID, 
                              r_Bann_ROW.BannerST_BannerID,1); 
                   -- find match from other side                
                   SELECT Student_ID_SEQ.CURRVAL into v_student_ID from dual;
                   SELECT Student_BannerID into v_StudentExistsID FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                   INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                             POSSIBLEMATCH_bannerID,
                                             POSSIBLEMATCH_CompareFactor)
                     VALUES (v_student_ID + 1, v_StudentExistsID, 1);
                 END IF;
               ELSIF (t_StudIDs(I).POSSIBLEMATCH_CompareFactor >= 75) THEN
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_BannerID,
                                           POSSIBLEMATCH_CompareFactor)
                    VALUES (t_StudIDs(i).POSSIBLEMATCH_StudentID, 
                            r_Bann_ROW.BannerST_BannerID,2); 
                 -- find match from other side                
                 SELECT Student_ColleagueID into v_MatchingColl FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 SELECT Student_ID_SEQ.CURRVAL into v_student_ID from dual;
                 IF (v_MatchingColl IS NULL) THEN -- two matching colleague records
                   SELECT Student_ColleagueID into v_MatchingColl FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 END IF; 
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_ColleagueID,
                                           POSSIBLEMATCH_CompareFactor)
                    VALUES (v_student_ID + 1, v_MatchingColl, 2);
               ELSIF (t_StudIDs(I).POSSIBLEMATCH_CompareFactor >= 50) THEN
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_BannerID,
                                           POSSIBLEMATCH_CompareFactor) 
                    VALUES (t_StudIDs(i).POSSIBLEMATCH_StudentID, 
                            r_Bann_ROW.BannerST_BannerID,3);
                 -- find match from other side                
                 SELECT Student_ColleagueID into v_MatchingColl FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 SELECT Student_ID_SEQ.CURRVAL into v_student_ID from dual;
                 IF (v_MatchingColl IS NULL) THEN -- two matching colleague records
                   SELECT Student_ColleagueID into v_MatchingColl FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 END IF; 
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_ColleagueID,
                                           POSSIBLEMATCH_CompareFactor)
                    VALUES (v_student_ID + 1, v_MatchingColl, 3);
               END IF; -- closes Comparefactor tests
             END IF;  -- closes t_StudIDs.exists(i)
           END LOOP; -- ends t_StudID for loop 
         END IF; -- closes t_studIDs.count > 0 
         IF v_Match_Found = FALSE THEN
           p_Add_Unreconciled_New_Bann;
         END IF;  
         COMMIT;

       << get_next_Bann_record >>
           NULL;  

       END LOOP;  -- ends loop through banner cursor
       CLOSE c_BannerST;

     END p_Reconcile_New_BannerST;


   -- =====================================================================   
   -- PROCEDURE p_Add_Unreconciled_New_Bann                       
   -- After the records that are able to be reconciled have been matched, 
   -- those records that were not matched from the BannerST table will 
   -- be added to the Student table by thes proceedure 
   -- =====================================================================
   PROCEDURE p_Add_Unreconciled_New_Bann IS
     BEGIN
         INSERT INTO Student
         (
            Student_ID,
            Student_BannerID,
            Student_PEN,
            Student_PIDM,
            Student_FirstName,
            Student_MiddleName,
            Student_LastName,
            Student_Gender,
            Student_BirthDate,
            Student_AddressLine1,
            Student_AddressLine2,
            Student_City,
            Student_Province,
            Student_PostalCode,
            Student_Country,
            Student_SIN,
            Student_LastUpdated,
            Student_UpdatedBy,
            Student_ReconciledType
         )
         VALUES
         ( 
            Student_ID_SEQ.NEXTVAL,
            r_Bann_ROW.BannerST_BannerID,
            r_Bann_ROW.BannerST_PEN,
            r_Bann_ROW.BannerST_PIDM,
            r_Bann_ROW.BannerST_FirstName,
            r_Bann_ROW.BannerST_MiddleName,
            r_Bann_ROW.BannerST_LastName,
            r_Bann_ROW.BannerST_Gender,
            r_Bann_ROW.BannerST_BirthDate,
            r_Bann_ROW.BannerST_Address_Line1,
            r_Bann_ROW.BannerST_Address_Line2,
            r_Bann_ROW.BannerST_City,
            r_Bann_ROW.BannerST_Province,
            r_Bann_ROW.BannerST_PostalCode,
            r_Bann_ROW.BannerST_Country,
            r_Bann_ROW.BannerST_SIN,
            v_timestamp,v_UpdatedBy,0
         );
     END p_Add_Unreconciled_New_Bann; 


   -- =====================================================================   
   -- p_Reconcile_New_ColleagueST
   -- This procedure loops through all records in the ColleagueST table
   -- comparing each record against the records in the Student table
   -- =====================================================================
   PROCEDURE p_Reconcile_New_ColleagueST IS
   
     v_Match_Found              BOOLEAN;
     v_MatchingBann             Student.Student_BannerID%TYPE;
     v_StudentExists            NUMBER;
     v_StudentExistsID          VARCHAR2(12);
     v_student_ID               NUMBER;
     v_Student_ReconciledType   Student.STUDENT_ReconciledType%TYPE;
              
     BEGIN
       OPEN c_ColleagueST;
       LOOP
         FETCH c_ColleagueST INTO r_Coll_ROW; 
         EXIT WHEN c_ColleagueST%NOTFOUND;
       -- initalize variables    
         v_Match_Found := FALSE;
         t_studIDs.DELETE;

         DECLARE
           RECONCILED_ALREADY  EXCEPTION;
         BEGIN
           SELECT count(Student_ColleagueID), max(Student_ID), max(Student_ReconciledType)
              INTO v_StudentExists, v_StudentExistsID, v_Student_ReconciledType 
              FROM Student 
              WHERE Student_ColleagueID = r_Coll_ROW.ColleagueST_ColleagueID;            
           IF v_StudentExists > 0 THEN
             IF v_Student_ReconciledType = 0 THEN
              DELETE FROM Student  -- remove record so it can try to reconcile
                  WHERE Student_ID = v_StudentExistsID;
               DELETE FROM PossibleMatch
                  WHERE PossibleMatch_StudentID = v_StudentExistsID OR 
                        PossibleMatch_ColleagueID = r_Coll_ROW.ColleagueST_ColleagueID;   
             ELSE --  else for v_Student_ReconciledType = 0
               RAISE RECONCILED_ALREADY;
             END IF; -- end v_Student_ReconciledType = 0
           END IF;  -- end of v_StudentExists > 0 
         EXCEPTION
           WHEN RECONCILED_ALREADY THEN
           UPDATE Student 
             SET
               Student_PEN = r_Coll_ROW.ColleagueST_PEN,
               Student_FirstName = r_Coll_ROW.ColleagueST_FirstName,
               Student_MiddleName = r_Coll_ROW.ColleagueST_MiddleName,
               Student_LastName = r_Coll_ROW.ColleagueST_LastName,
               Student_Gender = r_Coll_ROW.ColleagueST_Gender,
               Student_BirthDate = r_Coll_ROW.ColleagueST_BirthDate,
               Student_AddressLine1 = r_Coll_ROW.ColleagueST_Address_line1,
               Student_AddressLine2 = r_Coll_ROW.ColleagueST_Address_line2,
               Student_City = r_Coll_ROW.ColleagueST_City,
               Student_Province = r_Coll_ROW.ColleagueST_Province,
               Student_PostalCode = r_Coll_ROW.ColleagueST_PostalCode,
               Student_Country = r_Coll_ROW.ColleagueST_Country,
               Student_SIN = r_Coll_ROW.ColleagueST_SIN,
               Student_LastUpdated = v_timestamp
             WHERE Student_ID=v_StudentExistsID;
           
           DELETE FROM ColleagueST  -- This record is already in the Student table
              WHERE ColleagueST_ColleagueID = r_Coll_ROW.ColleagueST_ColleagueID;
             GOTO get_next_Coll_record; -- jump to next colleague record and 
                                        -- avoid processing this record
         END;  -- end embeded block

         p_Compare(r_Coll_ROW.ColleagueST_PEN,
                   r_Coll_ROW.ColleagueST_PreliminaryPEN,
                   UPPER(r_Coll_ROW.ColleagueST_FirstName),
                   UPPER(r_Coll_ROW.ColleagueST_MiddleName),
                   UPPER(r_Coll_ROW.ColleagueST_LastName),
                   UPPER(r_Coll_ROW.ColleagueST_Gender),
                   r_Coll_ROW.ColleagueST_BirthDate,
                   UPPER(r_Coll_ROW.ColleagueST_Address_Line1),
                   UPPER(r_Coll_ROW.ColleagueST_Address_Line2),
                   UPPER(r_Coll_ROW.ColleagueST_City),
                   UPPER(r_Coll_ROW.ColleagueST_Province),
                   UPPER(r_Coll_ROW.ColleagueST_Country),
                   UPPER(r_Coll_ROW.ColleagueST_PostalCode),
                   r_Coll_ROW.ColleagueST_SIN);                
         IF t_StudIDs.count > 0 THEN         
           FOR i IN 1..t_StudIDs.LAST LOOP
             IF t_StudIDs.EXISTS(i) THEN              
               IF (t_StudIDs(i).POSSIBLEMATCH_CompareFactor >= 100) THEN
                 SELECT Student_BannerID into v_StudentExistsID FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID; 
                 IF (v_StudentExistsID IS NOT NULL) THEN
                   v_Match_Found := f_Update_Student('Coll',1,t_StudIDs(i).POSSIBLEMATCH_STUDENTID);
                   DELETE FROM ColleagueST  -- This record has an exact match and is no longer needed
                     WHERE ColleagueST_ColleagueID = r_Coll_ROW.ColleagueST_ColleagueID;
           --        DELETE FROM POSSIBLEMATCH  -- eliminate any possible match becasue we found an sure match
           --          WHERE POSSIBLEMATCH_ColleagueID = t_StudIDs(i).POSSIBLEMATCH_ColleagueID;
                   EXIT;    -- get on to next one
                 ELSE -- two matching colleague records
                   INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                            POSSIBLEMATCH_ColleagueID,
                                            POSSIBLEMATCH_CompareFactor)
                     VALUES (t_StudIDs(i).POSSIBLEMATCH_StudentID, 
                              r_Coll_ROW.ColleagueST_ColleagueID,1); 
                   -- find match from other side                
                   SELECT Student_ID_SEQ.CURRVAL into v_student_ID from dual;
                   SELECT Student_ColleagueID into v_StudentExistsID FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;                   
                   INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                             POSSIBLEMATCH_ColleagueID,
                                             POSSIBLEMATCH_CompareFactor)
                     VALUES (v_student_ID + 1, v_StudentExistsID, 1);
                 END IF;
               ELSIF (t_StudIDs(i).POSSIBLEMATCH_CompareFactor >= 75) THEN
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_ColleagueID,
                                           POSSIBLEMATCH_CompareFactor) 
                    VALUES (t_StudIDs(i).POSSIBLEMATCH_StudentID,
                            r_Coll_ROW.ColleagueST_ColleagueID,2);
               -- find match from other side                
                 SELECT Student_BannerID into v_MatchingBann FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 IF (v_MatchingBann IS NULL) THEN -- two matching banner records
                   SELECT Student_ColleagueID into v_MatchingBann FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 END IF; 
                 SELECT Student_ID_SEQ.CURRVAL into v_student_ID from dual;
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_BannerID,
                                           POSSIBLEMATCH_CompareFactor)
                    VALUES (v_student_ID + 1, v_MatchingBann, 2);         
               ELSIF (t_StudIDs(i).POSSIBLEMATCH_CompareFactor >= 50) THEN
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_ColleagueID,
                                           POSSIBLEMATCH_CompareFactor)
                    VALUES (t_StudIDs(i).POSSIBLEMATCH_StudentID,
                            r_Coll_ROW.ColleagueST_ColleagueID,3);
          -- find match from other side                
                 SELECT Student_BannerID into v_MatchingBann FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 IF (v_MatchingBann IS NULL) THEN -- two matching banner records
                   SELECT Student_ColleagueID into v_MatchingBann FROM Student WHERE Student_ID = t_StudIDs(i).POSSIBLEMATCH_StudentID;
                 END IF; 
                 SELECT Student_ID_SEQ.CURRVAL into v_student_ID from dual;
                 INSERT INTO POSSIBLEMATCH(POSSIBLEMATCH_StudentID,
                                           POSSIBLEMATCH_BannerID,
                                           POSSIBLEMATCH_CompareFactor)
                    VALUES (v_student_ID + 1, v_MatchingBann, 3);
               END IF; -- end t_StudIDs(i).POSSIBLEMATCH_CompareFactor
             END IF; -- end t_StudIDs.EXISTS(i)            
           END LOOP; -- end FOR i IN 1..t_StudIDs.LAST LOOP
         END IF; -- end t_StudIDs.count > 0
         IF v_Match_Found = FALSE THEN
           p_Add_Unreconciled_New_Coll;
         END IF; -- end v_Match_Found = false  
         COMMIT;

         << get_next_Coll_record >>
           NULL;
       END LOOP;
       CLOSE c_ColleagueST;

     END p_Reconcile_New_ColleagueST;


   -- =====================================================================   
   -- PROCEDURE p_Add_Unreconciled_New_Coll                       
   -- After the records that are able to be reconciled have been matched, 
   -- those records that were not matched from the ColleagueST table will 
   -- be added to the Student table by thes proceedure
   -- =====================================================================
   PROCEDURE p_Add_Unreconciled_New_Coll IS
     BEGIN
         INSERT INTO Student
         (
            Student_ID,
            Student_ColleagueID,
            Student_PEN,
            Student_PreliminaryPEN,
            Student_FirstName,
            Student_MiddleName,
            Student_LastName,
            Student_Gender,
            Student_BirthDate,
            Student_AddressLine1,
            Student_AddressLine2,
            Student_City,
            Student_Province,
            Student_PostalCode,
            Student_Country,
            Student_SIN,
            Student_LastUpdated,
            Student_UpdatedBy,
            Student_ReconciledType
           )
           VALUES
           ( 
             Student_ID_SEQ.NEXTVAL,
             r_Coll_ROW.ColleagueST_ColleagueID,
             r_Coll_ROW.ColleagueST_PEN,
             r_Coll_ROW.ColleagueST_PreliminaryPEN,
             r_Coll_ROW.ColleagueST_FirstName,
             r_Coll_ROW.ColleagueST_MiddleName,
             r_Coll_ROW.ColleagueST_LastName,
             r_Coll_ROW.ColleagueST_Gender,
             r_Coll_ROW.ColleagueST_BirthDate,
             r_Coll_ROW.ColleagueST_Address_Line1,
             r_Coll_ROW.ColleagueST_Address_Line2,
             r_Coll_ROW.ColleagueST_City,
             r_Coll_ROW.ColleagueST_Province,
             r_Coll_ROW.ColleagueST_PostalCode,
             r_Coll_ROW.ColleagueST_Country,
             r_Coll_ROW.ColleagueST_SIN,
             v_timestamp,v_UpdatedBy,0
           );
     END p_Add_Unreconciled_New_Coll;


   -- =====================================================================   
   -- FUNCTION p_Update_Student                       
   -- When two student records are found to match this procedure will 
   -- update the student table to inculde both student numbers, the 
   -- reconciled type (indicates confidence in match) and the date 
   -- this record is being updated.  also if data is missing for this 
   -- record in the student table this procedure will add it from the 
   -- matching record. Returns true if update was performed else returns false
   -- =====================================================================     
   FUNCTION f_Update_Student(v_SourceTable VARCHAR2,
                              v_ReconciledType NUMBER,
                              v_Stud_ID Student.STUDENT_ID%TYPE) 
     RETURN BOOLEAN
       IS

     v_BanID             Student.Student_BannerID%TYPE;
     v_ColID             Student.Student_ColleagueID%TYPE;

     BEGIN
     
       IF (v_SourceTable = 'Bann') THEN  --  Banner Cursor Open
         SELECT Student_BannerID INTO v_BanID FROM Student WHERE Student_ID = v_Stud_ID;
         IF (v_BanID IS NULL) THEN -- null when not reconlied
           UPDATE Student 
             SET
               Student_ReconciledType = v_ReconciledType,
               Student_BannerID = r_Bann_ROW.BannerST_BannerID,
               Student_PIDM = r_Bann_ROW.BannerST_PIDM,
               Student_LastUpdated = v_timestamp
             WHERE Student_ID=v_Stud_ID AND
                   Student_BannerID IS NULL;
         ELSE -- else for v_BanID IS NULL
           p_Add_Unreconciled_New_Bann;
           INSERT INTO POSSIBLEMATCH(PossibleMatch_StudentID,PossibleMatch_BannerID,
                                           PossibleMatch_CompareFactor)
              VALUES (v_Stud_ID,r_Bann_ROW.BannerST_BannerID,1);           
         END IF; -- end of v_BanID IS NULL        

       ELSE  --  Colleague cursor open

         SELECT Student_ColleagueID INTO v_ColID FROM Student WHERE Student_ID = v_Stud_ID;
         IF (v_colID IS NULL) THEN   -- null when not reconlied
           UPDATE Student 
           SET
             Student_ReconciledType = v_ReconciledType,
             Student_ColleagueID = r_Coll_ROW.ColleagueST_ColleagueID,
             Student_PreliminaryPEN = r_Coll_ROW.ColleagueST_PreLiminaryPEN,
             Student_LastUpdated = v_timestamp
           WHERE Student_ID=v_Stud_ID AND
                 Student_ColleagueID IS NULL;
         ELSE -- else for v_colID IS NULL
           p_Add_Unreconciled_New_Coll;
           INSERT INTO POSSIBLEMATCH(PossibleMatch_StudentID,PossibleMatch_ColleagueID,
                                           PossibleMatch_CompareFactor)
              VALUES (v_Stud_ID,r_Coll_ROW.ColleagueST_ColleagueID,1);           
         END IF; -- end of v_ColID IS NULL

       END IF; -- end of v_sourceTable = 'Bann'

       RETURN SQL%FOUND;

     END f_Update_Student;


   -- =====================================================================   
   -- FUNCTION f_Compare                       
   --   This Function returns a numeric value that is used to evaluate 
   --   whether or not two student records refer to the same student and if 
   --   the do appear to refer to the same student how confident is that 
   --   evaluation. 
   --       return of > 100 is very confident
   --       return > 75 is moderatly confident 
   --       return > 50 is low confidence
   --       return < 50 not the the same student
   -- =====================================================================        
   PROCEDURE p_Compare
     (
       v_PEN            IN Student.STUDENT_PEN%TYPE,
       v_PrePEN         IN Student.STUDENT_PreliminaryPEN%TYPE,
       v_FirstName      IN Student.STUDENT_FirstName%TYPE,
       v_MiddleName     IN Student.STUDENT_MiddleName%TYPE,
       v_LastName       IN Student.STUDENT_LastName%TYPE,
       v_Gender         IN Student.STUDENT_Gender%TYPE,
       v_BirthDate      IN Student.STUDENT_BirthDate%TYPE,
       v_Address_Line1  IN Student.STUDENT_AddressLine1%TYPE,
       v_Address_Line2  IN Student.STUDENT_AddressLine2%TYPE,
       v_City           IN Student.STUDENT_City%TYPE,
       v_Province       IN Student.STUDENT_Province%TYPE,
       v_Country        IN Student.STUDENT_Country%TYPE,
       v_PostalCode     IN Student.STUDENT_PostalCode%TYPE,
       v_SIN            IN Student.STUDENT_SIN%TYPE
     )
     IS

       v_Stud_ID            NUMBER;
       v_RecordCount        NUMBER;
       v_Adjustment_Amount  NUMBER;
       v_First_Last         NUMBER;  -- used to flag equality of first in last names

 -- cursors     
      CURSOR c_PEN IS
             SELECT Student_ID FROM Student 
               WHERE Student_PEN = v_PEN;
            
      CURSOR c_PrePEN IS
             SELECT Student_ID FROM Student 
               WHERE Student_PEN = v_PrePEN;         
      
      CURSOR c_FirstName IS
             SELECT Student_ID FROM Student 
               WHERE UPPER(Student_FirstName) = v_FirstName;
            
      CURSOR c_MiddleName IS
             SELECT Student_ID FROM Student
               WHERE UPPER(Student_MiddleName) = v_MiddleName;
               
      CURSOR c_LastName IS
             SELECT Student_ID FROM Student 
               WHERE UPPER(Student_LastName) = v_LastName;
       
      CURSOR c_Gender_DOB IS
             SELECT Student_ID FROM Student 
               WHERE UPPER(STUDENT_Gender) = v_Gender AND
                   Student_BirthDate = v_BirthDate;
                   
      CURSOR c_Address_Line1 IS
             SELECT Student_ID FROM Student           
               WHERE UPPER(STUDENT_AddressLine1) = v_Address_Line1;
             
      CURSOR c_Address_Line2 IS
             SELECT Student_ID FROM Student           
               WHERE UPPER(STUDENT_AddressLine2) = v_Address_Line2;
             
      CURSOR c_City_PC IS
             SELECT Student_ID FROM Student    
               WHERE UPPER(STUDENT_City) = v_City AND
                     UPPER(STUDENT_Province) = v_Province AND
                     UPPER(STUDENT_Country) = v_Country AND
                     UPPER(STUDENT_PostalCode) = v_PostalCode;
         
      CURSOR c_SIN IS
             SELECT Student_ID FROM Student          
               WHERE STUDENT_SIN = v_SIN;      
      
     BEGIN       
       -- PEN test
       v_First_Last := 0;
       BEGIN
         IF(v_PEN IS NOT NULL) THEN
           OPEN c_PEN;
           LOOP
             FETCH c_PEN INTO v_Stud_ID; 
             EXIT WHEN c_PEN%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 100;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 100;
               END IF; -- end of v_studID(v_Stud_ID).exists
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_PEN;
                 RETURN;
               END IF; -- end CompareFactor >= 100   
            END LOOP;
            CLOSE c_PEN;
         END IF; -- end of v_PEN IS NULL 
       END;
       
       -- PreliminaryPEN test
       BEGIN
         IF(v_PrePEN IS NOT NULL) THEN
           OPEN c_PrePEN;
           LOOP
             FETCH c_PrePEN INTO v_Stud_ID; 
             EXIT WHEN c_PrePEN%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 35;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 35;
               END IF;  -- end of v_studID(v_Stud_ID).exists
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_PrePEN;
                 RETURN;
               END IF;  
            END LOOP;
            CLOSE c_PrePEN;
         END IF;
       END;
     
       -- FirstName test
       BEGIN
         IF(v_FirstName IS NOT NULL) THEN       
           IF (LENGTH(v_FirstName) > 2) THEN -- > 2 is only initals
           
             SELECT count(Student_ID) INTO v_RecordCount FROM Student 
               WHERE UPPER(Student_FirstName) = v_FirstName;
             IF v_RecordCount > 20 THEN
               v_Adjustment_Amount := 5;
               v_First_Last := v_First_Last + 1;
             ELSIF v_RecordCount > 0 THEN -- else of v_recordCount > 20
               v_Adjustment_Amount := 10;
               v_First_Last := v_First_Last + 1;
             ELSIF v_RecordCount = 0 THEN
               v_Adjustment_Amount := 0;
             END IF;  -- end of v_recordCount > 20           
             OPEN c_FirstName;
             LOOP
               FETCH c_FirstName INTO v_Stud_ID; 
               EXIT WHEN c_FirstName%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + v_Adjustment_Amount;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := v_Adjustment_Amount;
               END IF; -- end of v_studID(v_Stud_ID).exists
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_FirstName;
                 RETURN;
               END IF; -- end CompareFactor >= 100
           
             END LOOP;
             CLOSE c_FirstName;
           END IF; -- end of length(v_FirstName) > 2   
         END IF; -- end of v_FirstName IS NULL          
       END;

       -- MiddleName test
       BEGIN
         IF(v_MiddleName IS NOT NULL) THEN       
           IF (LENGTH(v_MiddleName) > 2) THEN -- > 2 is only initals
           
             SELECT count(Student_ID) INTO v_RecordCount FROM Student 
               WHERE UPPER(Student_MiddleName) = v_MiddleName;
             IF v_RecordCount > 20 THEN
               v_Adjustment_Amount := 5;
             ELSIF v_RecordCount > 0 THEN -- else of v_recordCount > 20
               v_Adjustment_Amount := 10;
             ELSIF v_RecordCount = 0 THEN
               v_Adjustment_Amount := 0;
             END IF;  -- end of v_recordCount > 20            
             OPEN c_MiddleName;
             LOOP
               FETCH c_MiddleName INTO v_Stud_ID; 
               EXIT WHEN c_MiddleName%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + v_Adjustment_Amount;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := v_Adjustment_Amount;
               END IF; -- end of v_studID(v_Stud_ID).exists
           
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_MiddleName;
                 RETURN;
               END IF; -- end CompareFactor >= 100
           
             END LOOP;
             CLOSE c_MiddleName;
           END IF; -- end of length(v_MiddleName) > 2   
         END IF; -- end of v_MiddletName IS NULL 
       END;
       
       -- LastName test
       BEGIN
         IF(v_LastName IS NOT NULL) THEN       
           IF (LENGTH(v_LastName) > 2) THEN -- > 2 is only initals
             SELECT count(Student_ID) INTO v_RecordCount FROM Student 
               WHERE UPPER(Student_LastName) = v_LastName;
             IF v_RecordCount > 20 THEN
               v_Adjustment_Amount := 5;
               v_First_Last := v_First_Last + 1;
             ELSIF v_RecordCount > 0 THEN -- else of v_recordCount > 20
               v_Adjustment_Amount := 10;
               v_First_Last := v_First_Last + 1;
             ELSIF v_RecordCount = 0 THEN
               v_Adjustment_Amount := 0;
             END IF;  -- end of v_recordCount > 20           
             OPEN c_LastName;
             LOOP
               FETCH c_LastName INTO v_Stud_ID; 
               EXIT WHEN c_LastName%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + v_Adjustment_Amount;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := v_Adjustment_Amount;
               END IF; -- end of v_studID(v_Stud_ID).exists
           
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_LastName;
                 RETURN;
               END IF; -- end CompareFactor >= 100
           
             END LOOP;
             CLOSE c_LastName;
           END IF; -- end of length(v_LastName) > 2   
         END IF; -- end of v_LastName IS NULL 
       END;     
      
       -- Gender_Birthdate test
       BEGIN
         OPEN c_Gender_DOB;
         LOOP
           FETCH c_Gender_DOB INTO v_Stud_ID; 
           EXIT WHEN c_Gender_DOB%NOTFOUND;
             IF t_StudIDs.Exists(v_Stud_ID) THEN
               t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                    t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 10;
               IF v_First_Last = 2 THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                    t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 30;
               END IF;
             ELSE -- else of v_studID(v_Stud_ID).exists
               t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
               t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 10;
               IF v_First_Last = 2 THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                    t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 30;
               END IF;
             END IF; -- end of v_studID(v_Stud_ID).exists 
             IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
               CLOSE c_Gender_DOB;
               RETURN;
             END IF; -- end CompareFactor >= 100 
          END LOOP;
          CLOSE c_Gender_DOB;            
       END;
       
       -- Address Line 1 test
       BEGIN
         OPEN c_Address_Line1;
         LOOP
           FETCH c_Address_Line1 INTO v_Stud_ID; 
           EXIT WHEN c_Address_Line1%NOTFOUND;
             IF t_StudIDs.Exists(v_Stud_ID) THEN
               t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                    t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 20;
             ELSE -- else of v_studID(v_Stud_ID).exists
               t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
               t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 20;
             END IF; -- end of v_studID(v_Stud_ID).exists
             IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
               CLOSE c_Address_Line1;
               RETURN;
             END IF; -- end CompareFactor >= 100 
          END LOOP;
          CLOSE c_Address_Line1;             
       END;
     
       -- Address Line 2 test
       BEGIN
         IF(v_Address_line2 IS NOT NULL) THEN
           OPEN c_Address_Line2;
           LOOP
             FETCH c_Address_Line2 INTO v_Stud_ID; 
             EXIT WHEN c_Address_Line2%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 20;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 20;
               END IF; -- end of v_studID(v_Stud_ID).exists

               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_Address_Line2;
                 RETURN;
               END IF; -- end CompareFactor >= 100   
            END LOOP;
            CLOSE c_Address_Line2;
         END IF; -- end of v_Address_line2 IS NULL                
       END;
       
       -- City Postal Code test
       BEGIN
         IF ((v_Country IS NOT NULL) OR (v_PostalCode IS NOT NULL)) THEN
           OPEN c_City_PC;
           LOOP
             FETCH c_City_PC INTO v_Stud_ID; 
             EXIT WHEN c_City_PC%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 10;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 10;
               END IF; -- end of v_studID(v_Stud_ID).exists
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_City_PC;
                 RETURN;
               END IF; -- end CompareFactor >= 100   
            END LOOP;
            CLOSE c_City_PC;
         END IF; -- end of ((v_Country IS NOT NULL) OR (v_PostalCode IS NOT NULL))             
       END;
       
       -- SIN test
       BEGIN
         IF (v_SIN IS NOT NULL) THEN
           OPEN c_SIN;
           LOOP
             FETCH c_SIN INTO v_Stud_ID; 
             EXIT WHEN c_SIN%NOTFOUND;
               IF t_StudIDs.Exists(v_Stud_ID) THEN
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 
                      t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor + 45;
               ELSE -- else of v_studID(v_Stud_ID).exists
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_StudentID := v_Stud_ID;
                 t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor := 45;
               END IF; -- end of v_studID(v_Stud_ID).exist
               IF t_StudIDs(v_stud_ID).POSSIBLEMATCH_CompareFactor >= 100 THEN
                 CLOSE c_SIN;
                 RETURN;
               END IF; -- end CompareFactor >= 100   
            END LOOP;
            CLOSE c_SIN;
         END IF; -- end of v_SIN IS NOT NULL                
       END;
     END p_Compare;

     
   -- =====================================================================   
   -- PROCEDURE p_Cleanup
   -- this Procedure will empty the temporary tables
   -- =====================================================================
   PROCEDURE p_Cleanup IS
     BEGIN
        DELETE FROM BannerST;
        DELETE FROM ColleagueST;
        commit;
     END p_Cleanup;

END CollBann_reconciler;
/